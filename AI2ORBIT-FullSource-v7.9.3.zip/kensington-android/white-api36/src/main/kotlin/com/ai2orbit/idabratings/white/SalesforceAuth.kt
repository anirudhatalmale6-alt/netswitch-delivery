package com.ai2orbit.idabratings.white

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Handles Salesforce OAuth2 Web Server flow:
 *   authorize -> callback with code -> exchange for tokens -> refresh
 *
 * Tokens are stored in EncryptedSharedPreferences for security.
 */
class SalesforceAuth(private val context: Context) {

    companion object {
        private const val TAG = "SalesforceAuth"

        @Volatile
        private var instance: SalesforceAuth? = null

        fun getInstance(context: Context): SalesforceAuth {
            return instance ?: synchronized(this) {
                instance ?: SalesforceAuth(context.applicationContext).also { instance = it }
            }
        }
    }

    // ── HTTP client ────────────────────────────────────────────────────

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(SalesforceConfig.CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(SalesforceConfig.READ_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .writeTimeout(SalesforceConfig.WRITE_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .build()

    private val gson = Gson()

    // ── Encrypted token storage ────────────────────────────────────────

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            SalesforceConfig.PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ── Public API ─────────────────────────────────────────────────────

    /** Build the authorization URL to load in a WebView. */
    fun buildAuthUrl(): String {
        return Uri.parse(SalesforceConfig.AUTH_URL).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", SalesforceConfig.CLIENT_ID)
            .appendQueryParameter("redirect_uri", SalesforceConfig.REDIRECT_URI)
            .appendQueryParameter("scope", SalesforceConfig.SCOPES)
            .appendQueryParameter("display", "touch")
            .appendQueryParameter("prompt", "login consent")
            .build()
            .toString()
    }

    /** Check if we have a valid session (access token stored). */
    fun isLoggedIn(): Boolean {
        return getAccessToken() != null && getInstanceUrl() != null
    }

    /** Get the stored access token, or null. */
    fun getAccessToken(): String? {
        return prefs.getString(SalesforceConfig.PREF_ACCESS_TOKEN, null)
    }

    /** Get the stored instance URL (e.g., https://na1.salesforce.com). */
    fun getInstanceUrl(): String? {
        return prefs.getString(SalesforceConfig.PREF_INSTANCE_URL, null)
    }

    /** Get the stored user display name. */
    fun getUserName(): String? {
        return prefs.getString(SalesforceConfig.PREF_USER_NAME, null)
    }

    /** Get the stored user ID. */
    fun getUserId(): String? {
        return prefs.getString(SalesforceConfig.PREF_USER_ID, null)
    }

    /**
     * Exchange the authorization code for access + refresh tokens.
     * Call this from a background thread.
     *
     * @param code The authorization code from the OAuth callback
     * @return TokenResponse on success
     * @throws IOException on network error
     * @throws SalesforceAuthException on Salesforce error
     */
    @Throws(IOException::class, SalesforceAuthException::class)
    fun exchangeCodeForTokens(code: String): TokenResponse {
        val body = FormBody.Builder()
            .add("grant_type", "authorization_code")
            .add("code", code)
            .add("client_id", SalesforceConfig.CLIENT_ID)
            .add("client_secret", SalesforceConfig.CLIENT_SECRET)
            .add("redirect_uri", SalesforceConfig.REDIRECT_URI)
            .build()

        val request = Request.Builder()
            .url(SalesforceConfig.TOKEN_URL)
            .post(body)
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string()
            ?: throw SalesforceAuthException("Empty response from token endpoint")

        if (!response.isSuccessful) {
            Log.e(TAG, "Token exchange failed: ${response.code} - $responseBody")
            val error = try {
                gson.fromJson(responseBody, TokenErrorResponse::class.java)
            } catch (e: Exception) {
                null
            }
            throw SalesforceAuthException(
                error?.errorDescription ?: "Token exchange failed (${response.code})"
            )
        }

        val tokenResponse = gson.fromJson(responseBody, TokenResponse::class.java)
        saveTokens(tokenResponse)

        // Fetch user info after successful auth
        fetchAndSaveUserInfo(tokenResponse.accessToken, tokenResponse.instanceUrl)

        return tokenResponse
    }

    /**
     * Refresh the access token using the stored refresh token.
     * Call this from a background thread.
     *
     * @return New TokenResponse on success
     * @throws IOException on network error
     * @throws SalesforceAuthException if refresh fails (user needs to re-login)
     */
    @Throws(IOException::class, SalesforceAuthException::class)
    fun refreshAccessToken(): TokenResponse {
        val refreshToken = prefs.getString(SalesforceConfig.PREF_REFRESH_TOKEN, null)
            ?: throw SalesforceAuthException("No refresh token available — please log in again")

        val body = FormBody.Builder()
            .add("grant_type", "refresh_token")
            .add("refresh_token", refreshToken)
            .add("client_id", SalesforceConfig.CLIENT_ID)
            .add("client_secret", SalesforceConfig.CLIENT_SECRET)
            .build()

        val request = Request.Builder()
            .url(SalesforceConfig.TOKEN_URL)
            .post(body)
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string()
            ?: throw SalesforceAuthException("Empty response from token refresh")

        if (!response.isSuccessful) {
            Log.e(TAG, "Token refresh failed: ${response.code} - $responseBody")
            // If refresh fails, clear stored tokens so user can re-login
            if (response.code == 400 || response.code == 401) {
                clearTokens()
            }
            throw SalesforceAuthException("Session expired — please log in again")
        }

        val tokenResponse = gson.fromJson(responseBody, TokenResponse::class.java)
        // Refresh response doesn't include a new refresh_token; keep the existing one
        saveTokens(tokenResponse, keepExistingRefreshToken = true)

        return tokenResponse
    }

    /**
     * Execute an authenticated API request. Automatically retries once with
     * a refreshed token if the first attempt returns 401.
     *
     * @param requestBuilder A pre-built Request.Builder (URL, method set). Auth header will be added.
     * @return The OkHttp Response (caller must close it)
     */
    @Throws(IOException::class, SalesforceAuthException::class)
    fun executeAuthenticatedRequest(requestBuilder: Request.Builder): okhttp3.Response {
        val token = getAccessToken()
            ?: throw SalesforceAuthException("Not logged in")

        // First attempt
        val request = requestBuilder
            .header("Authorization", "Bearer $token")
            .build()

        var response = httpClient.newCall(request).execute()

        // If 401, try refreshing the token and retry once
        if (response.code == 401) {
            response.close()
            Log.d(TAG, "Got 401, attempting token refresh...")

            try {
                val refreshed = refreshAccessToken()
                val retryRequest = requestBuilder
                    .header("Authorization", "Bearer ${refreshed.accessToken}")
                    .build()
                response = httpClient.newCall(retryRequest).execute()
            } catch (e: SalesforceAuthException) {
                throw SalesforceAuthException("Session expired — please log in again")
            }
        }

        return response
    }

    /** Log out: clear all stored tokens. */
    fun logout() {
        // Attempt to revoke the token server-side (best effort)
        val token = getAccessToken()
        if (token != null) {
            Thread {
                try {
                    val body = FormBody.Builder()
                        .add("token", token)
                        .build()
                    val request = Request.Builder()
                        .url(SalesforceConfig.REVOKE_URL)
                        .post(body)
                        .build()
                    httpClient.newCall(request).execute().close()
                } catch (e: Exception) {
                    Log.w(TAG, "Token revocation failed (non-critical)", e)
                }
            }.start()
        }

        clearTokens()

        // Also clear sync tracking
        context.getSharedPreferences(SalesforceConfig.SYNC_PREFS_NAME, Context.MODE_PRIVATE)
            .edit().clear().apply()
    }

    // ── Private helpers ────────────────────────────────────────────────

    private fun saveTokens(tokenResponse: TokenResponse, keepExistingRefreshToken: Boolean = false) {
        prefs.edit().apply {
            putString(SalesforceConfig.PREF_ACCESS_TOKEN, tokenResponse.accessToken)
            if (!keepExistingRefreshToken && tokenResponse.refreshToken != null) {
                putString(SalesforceConfig.PREF_REFRESH_TOKEN, tokenResponse.refreshToken)
            }
            if (tokenResponse.instanceUrl != null) {
                putString(SalesforceConfig.PREF_INSTANCE_URL, tokenResponse.instanceUrl)
            }
            if (tokenResponse.id != null) {
                putString(SalesforceConfig.PREF_USER_ID, tokenResponse.id)
            }
            putLong(SalesforceConfig.PREF_TOKEN_TIMESTAMP, System.currentTimeMillis())
            apply()
        }
    }

    private fun fetchAndSaveUserInfo(accessToken: String, instanceUrl: String?) {
        try {
            val url = (instanceUrl ?: SalesforceConfig.BASE_URL) + SalesforceConfig.USER_INFO_PATH
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && body != null) {
                val userInfo = gson.fromJson(body, UserInfoResponse::class.java)
                prefs.edit()
                    .putString(SalesforceConfig.PREF_USER_NAME, userInfo.name ?: userInfo.preferredUsername)
                    .apply()
            }
            response.close()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch user info (non-critical)", e)
        }
    }

    private fun clearTokens() {
        prefs.edit().clear().apply()
    }

    // ── Data classes ───────────────────────────────────────────────────

    data class TokenResponse(
        @SerializedName("access_token") val accessToken: String,
        @SerializedName("refresh_token") val refreshToken: String?,
        @SerializedName("instance_url") val instanceUrl: String?,
        @SerializedName("id") val id: String?,
        @SerializedName("token_type") val tokenType: String?,
        @SerializedName("issued_at") val issuedAt: String?,
        @SerializedName("signature") val signature: String?,
        @SerializedName("scope") val scope: String?
    )

    data class TokenErrorResponse(
        @SerializedName("error") val error: String?,
        @SerializedName("error_description") val errorDescription: String?
    )

    data class UserInfoResponse(
        @SerializedName("name") val name: String?,
        @SerializedName("preferred_username") val preferredUsername: String?,
        @SerializedName("email") val email: String?,
        @SerializedName("user_id") val userId: String?,
        @SerializedName("organization_id") val organizationId: String?
    )

    class SalesforceAuthException(message: String) : Exception(message)
}
