package com.ai2orbit.idabratings.white

/**
 * Salesforce OAuth2 configuration constants.
 *
 * To test with a free Salesforce Developer Edition:
 * 1. Sign up at https://developer.salesforce.com/signup
 * 2. Setup -> App Manager -> New Connected App
 * 3. Enable OAuth Settings, set callback URL to the REDIRECT_URI below
 * 4. Select scopes: full, refresh_token, api
 * 5. Copy Consumer Key -> paste as CLIENT_ID
 * 6. Copy Consumer Secret -> paste as CLIENT_SECRET
 *
 * For production orgs, change BASE_URL to "https://login.salesforce.com"
 * For sandbox orgs, use "https://test.salesforce.com"
 */
object SalesforceConfig {

    // ── Connected App credentials ──────────────────────────────────────
    // Replace these with your Connected App values
    const val CLIENT_ID = "YOUR_CONNECTED_APP_CONSUMER_KEY"
    const val CLIENT_SECRET = "YOUR_CONNECTED_APP_CONSUMER_SECRET"

    // ── OAuth2 endpoints ───────────────────────────────────────────────
    // Production / Developer Edition
    const val BASE_URL = "https://login.salesforce.com"
    // Sandbox: const val BASE_URL = "https://test.salesforce.com"

    const val AUTH_URL = "$BASE_URL/services/oauth2/authorize"
    const val TOKEN_URL = "$BASE_URL/services/oauth2/token"
    const val REVOKE_URL = "$BASE_URL/services/oauth2/revoke"

    // ── Redirect URI ───────────────────────────────────────────────────
    // Must match exactly what is configured in your Connected App
    const val REDIRECT_URI = "idabratings://salesforce/callback"

    // ── OAuth2 scopes ──────────────────────────────────────────────────
    const val SCOPES = "full refresh_token api"

    // ── REST API paths (appended to instance_url) ──────────────────────
    const val API_VERSION = "v60.0"
    const val SOBJECTS_PATH = "/services/data/$API_VERSION/sobjects"
    const val CONTENT_VERSION_PATH = "$SOBJECTS_PATH/ContentVersion"
    const val QUERY_PATH = "/services/data/$API_VERSION/query"
    const val USER_INFO_PATH = "/services/oauth2/userinfo"

    // ── SharedPreferences ──────────────────────────────────────────────
    const val PREFS_NAME = "salesforce_auth"
    const val PREF_ACCESS_TOKEN = "access_token"
    const val PREF_REFRESH_TOKEN = "refresh_token"
    const val PREF_INSTANCE_URL = "instance_url"
    const val PREF_USER_ID = "user_id"
    const val PREF_USER_NAME = "user_name"
    const val PREF_TOKEN_TIMESTAMP = "token_timestamp"

    // ── Photo sync preferences ─────────────────────────────────────────
    const val SYNC_PREFS_NAME = "salesforce_photo_sync"
    const val PREF_SYNCED_PHOTOS = "synced_photo_ids"

    // ── Timeouts (milliseconds) ────────────────────────────────────────
    const val CONNECT_TIMEOUT_MS = 30_000L
    const val READ_TIMEOUT_MS = 60_000L
    const val WRITE_TIMEOUT_MS = 120_000L

    // ── Upload limits ──────────────────────────────────────────────────
    // Salesforce ContentVersion max file size is ~2 GB, but we limit for mobile
    const val MAX_UPLOAD_SIZE_BYTES = 25L * 1024 * 1024 // 25 MB per file
}
