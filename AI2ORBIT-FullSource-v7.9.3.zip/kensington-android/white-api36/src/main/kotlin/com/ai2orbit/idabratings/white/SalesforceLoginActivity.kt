package com.ai2orbit.idabratings.white

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsetsController
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/**
 * Salesforce OAuth2 login activity.
 *
 * Flow:
 * 1. If already logged in, shows account info + logout/continue buttons
 * 2. If not logged in, loads the Salesforce authorization URL in a WebView
 * 3. Intercepts the redirect URI callback to capture the authorization code
 * 4. Exchanges the code for tokens in a background thread
 * 5. On success, proceeds to SalesforcePhotoActivity
 */
class SalesforceLoginActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "SalesforceLogin"
    }

    private lateinit var auth: SalesforceAuth

    // UI elements
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var loggedInLayout: LinearLayout
    private lateinit var loggedInUser: TextView
    private lateinit var loggedInInstance: TextView
    private lateinit var btnContinue: Button
    private lateinit var btnLogout: Button
    private lateinit var btnLogin: Button
    private lateinit var loginContainer: LinearLayout

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Dark status/nav bars matching app theme
        window.statusBarColor = Color.parseColor("#0a0e17")
        window.navigationBarColor = Color.parseColor("#0a0e17")
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        setContentView(R.layout.activity_salesforce_login)

        auth = SalesforceAuth.getInstance(this)

        bindViews()
        setupListeners()

        if (auth.isLoggedIn()) {
            showLoggedInState()
        } else {
            showLoginState()
        }
    }

    private fun bindViews() {
        webView = findViewById(R.id.sfLoginWebView)
        progressBar = findViewById(R.id.sfLoginProgress)
        statusText = findViewById(R.id.sfLoginStatus)
        loggedInLayout = findViewById(R.id.sfLoggedInLayout)
        loggedInUser = findViewById(R.id.sfLoggedInUser)
        loggedInInstance = findViewById(R.id.sfLoggedInInstance)
        btnContinue = findViewById(R.id.sfBtnContinue)
        btnLogout = findViewById(R.id.sfBtnLogout)
        btnLogin = findViewById(R.id.sfBtnLogin)
        loginContainer = findViewById(R.id.sfLoginContainer)
    }

    private fun setupListeners() {
        btnLogin.setOnClickListener {
            startOAuthFlow()
        }

        btnContinue.setOnClickListener {
            navigateToPhotos()
        }

        btnLogout.setOnClickListener {
            auth.logout()
            showLoginState()
            Toast.makeText(this, "Logged out from Salesforce", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Login state management ─────────────────────────────────────────

    private fun showLoggedInState() {
        webView.visibility = View.GONE
        progressBar.visibility = View.GONE
        statusText.visibility = View.GONE
        loginContainer.visibility = View.GONE

        loggedInLayout.visibility = View.VISIBLE
        loggedInUser.text = auth.getUserName() ?: "Salesforce User"
        loggedInInstance.text = auth.getInstanceUrl() ?: ""
    }

    private fun showLoginState() {
        loggedInLayout.visibility = View.GONE
        webView.visibility = View.GONE
        progressBar.visibility = View.GONE
        statusText.visibility = View.GONE

        loginContainer.visibility = View.VISIBLE
    }

    private fun showLoading(message: String) {
        webView.visibility = View.GONE
        loginContainer.visibility = View.GONE
        loggedInLayout.visibility = View.GONE

        progressBar.visibility = View.VISIBLE
        statusText.visibility = View.VISIBLE
        statusText.text = message
    }

    // ── OAuth2 flow ────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun startOAuthFlow() {
        loginContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        statusText.visibility = View.VISIBLE
        statusText.text = "Loading Salesforce login..."

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(false)
            builtInZoomControls = false
            userAgentString = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
        }

        // Clear any previous session cookies/cache for clean login
        android.webkit.CookieManager.getInstance().removeAllCookies(null)
        webView.clearCache(true)

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return handleUrl(url)
            }

            @Deprecated("Deprecated in API level 24, but needed for older devices")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return handleUrl(url ?: return false)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                statusText.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e(TAG, "WebView error: $errorCode - $description - $failingUrl")
                // Don't show error for the redirect URI interception
                if (failingUrl?.startsWith(SalesforceConfig.REDIRECT_URI) != true) {
                    runOnUiThread {
                        statusText.visibility = View.VISIBLE
                        statusText.text = "Error loading page: $description"
                    }
                }
            }
        }

        val authUrl = auth.buildAuthUrl()
        Log.d(TAG, "Loading auth URL: $authUrl")
        webView.loadUrl(authUrl)
    }

    /**
     * Intercept URLs to detect the OAuth callback redirect.
     * Returns true if the URL was handled (callback detected).
     */
    private fun handleUrl(url: String): Boolean {
        if (url.startsWith(SalesforceConfig.REDIRECT_URI)) {
            Log.d(TAG, "OAuth callback intercepted")
            val uri = Uri.parse(url)

            // Check for errors
            val error = uri.getQueryParameter("error")
            if (error != null) {
                val errorDesc = uri.getQueryParameter("error_description") ?: error
                Log.e(TAG, "OAuth error: $error - $errorDesc")
                runOnUiThread {
                    showLoginState()
                    Toast.makeText(
                        this@SalesforceLoginActivity,
                        "Login failed: $errorDesc",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return true
            }

            // Extract authorization code
            val code = uri.getQueryParameter("code")
            if (code != null) {
                exchangeCodeForTokens(code)
            } else {
                runOnUiThread {
                    showLoginState()
                    Toast.makeText(this@SalesforceLoginActivity, "No authorization code received", Toast.LENGTH_LONG).show()
                }
            }
            return true
        }
        return false
    }

    /**
     * Exchange the authorization code for tokens in a background thread.
     */
    private fun exchangeCodeForTokens(code: String) {
        runOnUiThread { showLoading("Completing login...") }

        executor.execute {
            try {
                val tokenResponse = auth.exchangeCodeForTokens(code)
                Log.d(TAG, "Token exchange successful. Instance: ${tokenResponse.instanceUrl}")

                runOnUiThread {
                    Toast.makeText(this, "Salesforce login successful!", Toast.LENGTH_SHORT).show()
                    showLoggedInState()
                }
            } catch (e: SalesforceAuth.SalesforceAuthException) {
                Log.e(TAG, "Token exchange failed", e)
                runOnUiThread {
                    showLoginState()
                    Toast.makeText(this, "Login failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Token exchange error", e)
                runOnUiThread {
                    showLoginState()
                    Toast.makeText(this, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Navigation ─────────────────────────────────────────────────────

    private fun navigateToPhotos() {
        val intent = Intent(this, SalesforcePhotoActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroy() {
        webView.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}
