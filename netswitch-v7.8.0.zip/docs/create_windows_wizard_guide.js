const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
        WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak } = require('docx');

const tb = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cb = { top: tb, bottom: tb, left: tb, right: tb };
const hS = { fill: "1B2A4A", type: ShadingType.CLEAR };
const aS = { fill: "F5F7FA", type: ShadingType.CLEAR };

function h1(t) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun(t)] }); }
function h2(t) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 }, children: [new TextRun(t)] }); }
function p(t) { return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: t, size: 22, font: "Arial" })] }); }
function pb(l, v) { return new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: l, bold: true, size: 22, font: "Arial" }), new TextRun({ text: v, size: 22, font: "Arial" })] }); }
function code(t) { return new Paragraph({ spacing: { after: 60 }, indent: { left: 360 }, shading: { fill: "F0F0F0", type: ShadingType.CLEAR }, children: [new TextRun({ text: t, size: 20, font: "Courier New", color: "333333" })] }); }
function step(n, t) { return new Paragraph({ spacing: { before: 200, after: 100 }, children: [new TextRun({ text: `Step ${n}: `, bold: true, size: 24, font: "Arial", color: "1B2A4A" }), new TextRun({ text: t, size: 22, font: "Arial" })] }); }
function note(t) { return new Paragraph({ spacing: { after: 100 }, indent: { left: 360 }, children: [new TextRun({ text: "Note: ", bold: true, italics: true, size: 20, font: "Arial", color: "CC6600" }), new TextRun({ text: t, italics: true, size: 20, font: "Arial", color: "666666" })] }); }

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", run: { size: 52, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 600, after: 120 }, alignment: AlignmentType.CENTER } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, color: "2D4A7A", font: "Arial" }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
    ]
  },
  numbering: {
    config: [
      { reference: "bl1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "prereq", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "steps", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "AI2ORBIT - Windows Wizard Installation Guide", size: 18, color: "888888", font: "Arial", italics: true })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
      new TextRun({ text: "Copyright (c) AI-2-Orbit Co. 2026  |  Page ", size: 18, color: "888888", font: "Arial" }),
      new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "888888", font: "Arial" }),
      new TextRun({ text: " of ", size: 18, color: "888888", font: "Arial" }),
      new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: "888888", font: "Arial" }),
    ] })] }) },
    children: [
      // TITLE
      new Paragraph({ spacing: { before: 2400 }, children: [] }),
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("AI2ORBIT Network")] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Windows Wizard Installation Guide", size: 32, color: "2D4A7A", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Inno Setup 6 Installer | Version 1.0.0", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "AI-2-Orbit Co. | April 2026", size: 24, color: "666666", font: "Arial" })] }),

      new Paragraph({ children: [new PageBreak()] }),

      // PREREQUISITES
      h1("1. Prerequisites"),
      p("Before building the Windows installer, ensure the following software is installed:"),
      new Paragraph({ numbering: { reference: "prereq", level: 0 }, children: [new TextRun({ text: "Visual Studio 2022 or 2026", size: 22, font: "Arial" }), new TextRun({ text: " with C++ Desktop Development workload", size: 22, font: "Arial", color: "666666" })] }),
      new Paragraph({ numbering: { reference: "prereq", level: 0 }, children: [new TextRun({ text: "CMake 3.14+", size: 22, font: "Arial" }), new TextRun({ text: " (included with Visual Studio)", size: 22, font: "Arial", color: "666666" })] }),
      new Paragraph({ numbering: { reference: "prereq", level: 0 }, children: [new TextRun({ text: "Inno Setup 6.x", size: 22, font: "Arial" }), new TextRun({ text: " from https://jrsoftware.org/isinfo.php", size: 22, font: "Arial", color: "666666" })] }),
      new Paragraph({ numbering: { reference: "prereq", level: 0 }, children: [new TextRun({ text: "ai2orbit.ico", size: 22, font: "Arial" }), new TextRun({ text: " icon file (256x256 multi-resolution ICO)", size: 22, font: "Arial", color: "666666" })] }),

      // BUILD PROCESS
      h1("2. Building the C++ Project"),
      step(1, "Open Developer Command Prompt for Visual Studio"),
      step(2, "Navigate to the project directory"),
      code("cd C:\\path\\to\\test_cpp"),
      step(3, "Create build directory and configure CMake"),
      code("mkdir build"),
      code("cd build"),
      code("cmake .. -DCMAKE_BUILD_TYPE=Release -G \"Visual Studio 17 2022\" -A x64"),
      note("Use 'Visual Studio 17 2022' for VS2022 or 'Visual Studio 18 2026' for VS2026"),
      step(4, "Build the project in Release mode"),
      code("cmake --build . --config Release"),
      step(5, "Verify the built executables"),
      code("dir Release\\AI2ORBIT-*.exe"),
      p("You should see:"),
      code("AI2ORBIT-Benchmark.exe"),
      code("AI2ORBIT-NetMon.exe"),
      code("AI2ORBIT-Checker.exe"),

      new Paragraph({ children: [new PageBreak()] }),

      // INSTALLER CREATION
      h1("3. Creating the Installer with Inno Setup"),
      step(1, "Open Inno Setup Compiler (ISCC)"),
      p("Launch Inno Setup 6 from the Start Menu."),
      step(2, "Open the installer script"),
      p("File > Open > Navigate to:"),
      code("installers\\windows\\AI2ORBIT_Network_Setup.iss"),
      step(3, "Review the configuration"),
      p("Key settings in the .iss file:"),
      pb("AppName: ", "AI2ORBIT Network"),
      pb("AppVersion: ", "1.0.0"),
      pb("Publisher: ", "AI-2-Orbit Co."),
      pb("Install Dir: ", "{autopf}\\AI2ORBIT\\Network"),
      pb("Architecture: ", "x64 only (64-bit)"),
      pb("Min Windows: ", "10.0 (Windows 10/11)"),
      pb("Compression: ", "LZMA2/ultra64 (solid)"),

      step(4, "Compile the installer"),
      p("Build > Compile (or press Ctrl+F9)"),
      note("Alternatively, use the command line:"),
      code("\"C:\\Program Files (x86)\\Inno Setup 6\\ISCC.exe\" AI2ORBIT_Network_Setup.iss"),

      step(5, "Find the output"),
      p("The installer is created at:"),
      code("installers\\windows\\output\\AI2ORBIT_Network_Setup_v1.0.0.exe"),

      // AUTOMATED BUILD
      h1("4. Automated Build Script"),
      p("A batch file is provided for one-click building:"),
      code("installers\\windows\\build_installer.bat"),
      p("This script automatically:"),
      new Paragraph({ numbering: { reference: "steps", level: 0 }, children: [new TextRun({ text: "Builds the C++ project with CMake (Release mode)", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "steps", level: 0 }, children: [new TextRun({ text: "Locates Inno Setup on the system", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "steps", level: 0 }, children: [new TextRun({ text: "Compiles the installer wizard", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "steps", level: 0 }, children: [new TextRun({ text: "Outputs the final .exe installer", size: 22, font: "Arial" })] }),

      new Paragraph({ children: [new PageBreak()] }),

      // WHAT THE INSTALLER DOES
      h1("5. What the Installer Does"),
      h2("5.1 Wizard Pages"),
      p("The installer presents the following wizard pages to the end user:"),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Welcome page", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - AI2ORBIT Network v1.0.0 branding", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "EULA acceptance", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - License agreement (from eula.h)", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Destination folder", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - Default: C:\\Program Files\\AI2ORBIT\\Network", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Additional tasks", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - Desktop icon, Add to PATH", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Installation progress", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - File copy and registry setup", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Finish page", bold: true, size: 22, font: "Arial" }), new TextRun({ text: " - Option to run Network Value Analysis", size: 22, font: "Arial" })] }),

      h2("5.2 Installed Files"),
      p("Files installed to C:\\Program Files\\AI2ORBIT\\Network\\:"),
      code("AI2ORBIT-NetMon.exe      (Network Quality Monitor)"),
      code("AI2ORBIT-Benchmark.exe   (Performance Benchmark)"),
      code("AI2ORBIT-Checker.exe     (Security Checker)"),
      code("lib\\BenchmarkCore.lib    (Static library for developers)"),
      code("include\\*.h              (Header files for developers)"),
      code("doc\\EULA.txt             (License agreement)"),
      code("README.txt               (Usage documentation)"),

      h2("5.3 Start Menu Shortcuts"),
      p("Created under Start Menu > AI2ORBIT:"),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "AI2ORBIT Network Monitor", size: 22, font: "Arial" }), new TextRun({ text: " (runs --value)", size: 22, font: "Arial", color: "666666" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "AI2ORBIT Benchmark", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "AI2ORBIT Security Checker", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Uninstall AI2ORBIT Network", size: 22, font: "Arial" })] }),

      h2("5.4 Registry Entries"),
      p("Written to HKLM\\Software\\AI2ORBIT:"),
      pb("InstallPath: ", "C:\\Program Files\\AI2ORBIT\\Network"),
      pb("Version: ", "1.0.0"),
      pb("Publisher: ", "AI-2-Orbit Co."),

      h2("5.5 Icon"),
      p("The installer uses ai2orbit.ico for:"),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Setup wizard window icon", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Desktop shortcut icon", size: 22, font: "Arial" })] }),
      new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Add/Remove Programs listing", size: 22, font: "Arial" })] }),
      note("The icon file (ai2orbit.ico) should be a multi-resolution ICO file containing 16x16, 32x32, 48x48, and 256x256 sizes. Place it in installers/windows/ alongside the .iss file."),

      new Paragraph({ children: [new PageBreak()] }),

      // UPDATING
      h1("6. Updating the Installer"),
      h2("6.1 Version Bump"),
      p("When releasing a new version, update these fields in AI2ORBIT_Network_Setup.iss:"),
      code("AppVersion=1.1.0"),
      code("AppVerName=AI2ORBIT Network v1.1.0"),
      code("OutputBaseFilename=AI2ORBIT_Network_Setup_v1.1.0"),

      h2("6.2 Adding New Executables"),
      p("To add a new tool to the installer, add entries in three sections:"),
      p("[Files] - Source file and destination"),
      code('Source: "..\\..\\test_cpp\\build\\Release\\NewTool.exe"; DestDir: "{app}"; Flags: ignoreversion'),
      p("[Icons] - Start Menu shortcut"),
      code('Name: "{group}\\New Tool"; Filename: "{app}\\NewTool.exe"'),
      p("[Run] - Optional post-install action"),
      code('Filename: "{app}\\NewTool.exe"; Flags: postinstall nowait skipifsilent'),

      h2("6.3 Updating the Icon"),
      p("Replace the ai2orbit.ico file in installers/windows/ with the new icon. The .iss file references it via:"),
      code("SetupIconFile=ai2orbit.ico"),
      code("UninstallDisplayIcon={app}\\AI2ORBIT-NetMon.exe"),

      // END
      new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "--- End of Document ---", size: 20, color: "888888", font: "Arial", italics: true })] }),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/var/lib/freelancer/projects/40338131/docs/AI2ORBIT_Windows_Wizard_Guide.docx", buffer);
  console.log("Windows Wizard Guide created successfully.");
});
