const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
        LevelFormat, PageNumber, ShadingType, VerticalAlign, PageBreak, TableOfContents } = require('docx');
const fs = require('fs');

const tb = { style: BorderStyle.SINGLE, size: 1, color: "BBBBBB" };
const cb = { top: tb, bottom: tb, left: tb, right: tb };
const hdrShade = { fill: "1B2A4A", type: ShadingType.CLEAR };
const altShade = { fill: "F5F5F5", type: ShadingType.CLEAR };

function hdrCell(text, w) {
  return new TableCell({ borders: cb, width: { size: w, type: WidthType.DXA }, shading: hdrShade, verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold: true, color: "FFFFFF", size: 20, font: "Arial" })] })] });
}
function cell(text, w, shade) {
  return new TableCell({ borders: cb, width: { size: w, type: WidthType.DXA }, shading: shade, verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({ children: [new TextRun({ text, size: 20, font: "Arial" })] })] });
}
function codeCell(text, w, shade) {
  return new TableCell({ borders: cb, width: { size: w, type: WidthType.DXA }, shading: shade, verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({ children: [new TextRun({ text, size: 18, font: "Consolas" })] })] });
}

function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun({ text })] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 160 }, children: [new TextRun({ text })] }); }
function h3(text) { return new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 200, after: 120 }, children: [new TextRun({ text })] }); }
function p(text) { return new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text, size: 22, font: "Arial" })] }); }
function code(text) { return new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text, size: 20, font: "Consolas", color: "1B2A4A" })] }); }
function bold(text) { return new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text, size: 22, font: "Arial", bold: true })] }); }

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", run: { size: 56, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { after: 120 }, alignment: AlignmentType.CENTER } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, color: "2D5AA0", font: "Arial" }, paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 24, bold: true, color: "444444", font: "Arial" }, paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 2 } },
    ]
  },
  numbering: {
    config: [
      { reference: "bl1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl2", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl3", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl4", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl5", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl6", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl7", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl8", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n1", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n3", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n4", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [
    // COVER PAGE
    {
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "AI2ORBIT Product Suite", size: 18, color: "999999", font: "Arial" })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Copyright 2026 AI2ORBIT Co. Made in Finland. | Page ", size: 18, color: "999999" }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "999999" }), new TextRun({ text: " of ", size: 18, color: "999999" }), new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: "999999" })] })] }) },
      children: [
        new Paragraph({ spacing: { before: 3000 } }),
        new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("AI2ORBIT")] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Product Suite Guide", size: 36, color: "2D5AA0", font: "Arial" })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "Build, Deploy & Run on Any Platform", size: 24, color: "666666", font: "Arial", italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Version 2.0 | April 2026", size: 22, color: "888888" })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "AI2ORBIT Co. | Turku, Finland", size: 22, color: "888888" })] }),
        new Paragraph({ children: [new PageBreak()] }),

        // TOC
        new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Table of Contents")] }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 1: PRODUCT OVERVIEW ============
        h1("1. Product Overview"),
        p("AI2ORBIT is a multi-platform benchmark, network monitoring, and performance optimization suite. The product consists of the following components:"),
        new Table({
          columnWidths: [2800, 3000, 3560],
          rows: [
            new TableRow({ children: [hdrCell("Product", 2800), hdrCell("Type", 3000), hdrCell("Platform", 3560)] }),
            new TableRow({ children: [cell("Benchmark Pro", 2800), cell("CPU/GPU/RAM/ML benchmark", 3000), cell("Windows, Linux, macOS", 3560)] }),
            new TableRow({ children: [cell("Benchmark Pro Network", 2800, altShade), cell("+ Network monitor & security", 3000, altShade), cell("Windows, Linux, macOS", 3560, altShade)] }),
            new TableRow({ children: [cell("Boost Controller", 2800), cell("Performance optimizer (UI)", 3000), cell("Android (APK/AAB)", 3560)] }),
            new TableRow({ children: [cell("Luxury Music Tones", 2800, altShade), cell("Ringtone app (40 tones)", 3000, altShade), cell("Android (APK/AAB)", 3560, altShade)] }),
            new TableRow({ children: [cell("Financial Dashboard", 2800), cell("Real-time stock display", 3000), cell("Browser (HTML)", 3560)] }),
            new TableRow({ children: [cell("Spotify Player", 2800, altShade), cell("Music streaming UI", 3000, altShade), cell("Browser (HTML)", 3560, altShade)] }),
            new TableRow({ children: [cell("Boost Launcher", 2800), cell("Performance optimizer (CLI)", 3000), cell("All platforms", 3560)] }),
          ]
        }),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 2: BUILD WITH MSVC (WINDOWS) ============
        h1("2. Building with MSVC (Windows)"),
        h2("2.1 Prerequisites"),
        new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Visual Studio 2019 or later (Community, Professional, or Enterprise)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "MSVC v142 or v143 toolset (installed via Visual Studio Installer)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "CMake 3.14+ (bundled with Visual Studio or standalone)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl1", level: 0 }, children: [new TextRun({ text: "Windows SDK 10.0+", size: 22 })] }),

        h2("2.2 Build from Developer Command Prompt"),
        bold("Option A: Visual Studio Developer Command Prompt"),
        code('  cd benchmark-pro'),
        code('  mkdir build && cd build'),
        code('  cmake .. -G "Visual Studio 17 2022" -A x64'),
        code('  cmake --build . --config Release'),
        p("This produces Release\\AI2ORBIT-Benchmark.exe, Release\\netmon.exe, and Release\\checker.exe."),

        bold("Option B: MSBuild directly"),
        code('  cmake .. -G "Visual Studio 17 2022"'),
        code('  msbuild AI2ORBIT.sln /p:Configuration=Release /p:Platform=x64'),

        bold("Option C: Ninja (faster builds)"),
        code('  cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release'),
        code('  ninja'),

        h2("2.3 Build Benchmark Pro (without Network)"),
        code('  cmake .. -G "Visual Studio 17 2022" -A x64'),
        code('  cmake --build . --config Release --target AI2ORBIT-Benchmark'),
        p("This builds only the core benchmark executable, excluding netmon and checker."),

        h2("2.4 Build Benchmark Pro Network (full suite)"),
        code('  cmake --build . --config Release'),
        p("This builds all targets: AI2ORBIT-Benchmark, netmon, and checker."),

        h2("2.5 Run Tests"),
        code('  cmake --build . --config Release --target BenchmarkTests'),
        code('  ctest -C Release --output-on-failure'),
        p("All 285 tests should pass with 98.7% code coverage."),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 3: BUILD ON LINUX/macOS ============
        h1("3. Building on Linux / macOS"),
        h2("3.1 Prerequisites"),
        new Paragraph({ numbering: { reference: "bl2", level: 0 }, children: [new TextRun({ text: "GCC 7+ or Clang 8+ (C++17 support required)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl2", level: 0 }, children: [new TextRun({ text: "CMake 3.14+", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl2", level: 0 }, children: [new TextRun({ text: "make or ninja", size: 22 })] }),

        h2("3.2 Standard Build"),
        code('  cd benchmark-pro'),
        code('  mkdir build && cd build'),
        code('  cmake .. -DCMAKE_BUILD_TYPE=Release'),
        code('  make -j$(nproc)'),

        h2("3.3 Automated Build Script"),
        code('  chmod +x build_all.sh'),
        code('  ./build_all.sh --release          # Release build'),
        code('  ./build_all.sh --package           # Build + create installers'),
        code('  ./build_all.sh --test-only         # Run tests only'),
        code('  ./build_all.sh --clean             # Clean and rebuild'),

        h2("3.4 macOS DMG Installer"),
        code('  cd installers/macos'),
        code('  chmod +x create_dmg.sh'),
        code('  ./create_dmg.sh'),
        p("Creates AI2ORBIT-Benchmark.dmg with .app bundle containing all executables."),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 4: SERVER DEPLOYMENT ============
        h1("4. Server Deployment"),
        h2("4.1 Ubuntu / Canonical Server"),
        h3("4.1.1 Install Dependencies"),
        code('  sudo apt update'),
        code('  sudo apt install build-essential cmake g++ git'),

        h3("4.1.2 Build and Install"),
        code('  git clone <repo-url> ai2orbit'),
        code('  cd ai2orbit && mkdir build && cd build'),
        code('  cmake .. -DCMAKE_BUILD_TYPE=Release'),
        code('  make -j$(nproc)'),
        code('  sudo make install'),

        h3("4.1.3 Run as Systemd Service"),
        code('  # Create service file'),
        code('  sudo nano /etc/systemd/system/ai2orbit-netmon.service'),
        p("Service file contents:"),
        code('  [Unit]'),
        code('  Description=AI2ORBIT Network Monitor'),
        code('  After=network.target'),
        code('  [Service]'),
        code('  Type=simple'),
        code('  ExecStart=/usr/local/bin/netmon --daemon --interval 5 --log /var/log/ai2orbit/netmon.log'),
        code('  Restart=always'),
        code('  [Install]'),
        code('  WantedBy=multi-user.target'),
        p("Enable and start:"),
        code('  sudo systemctl enable ai2orbit-netmon'),
        code('  sudo systemctl start ai2orbit-netmon'),

        h2("4.2 Nginx Reverse Proxy (for Dashboard)"),
        code('  server {'),
        code('      listen 80;'),
        code('      server_name benchmark.yourdomain.com;'),
        code('      location / {'),
        code('          root /var/www/ai2orbit/dashboard;'),
        code('          index index.html;'),
        code('      }'),
        code('      location /api/ {'),
        code('          proxy_pass http://127.0.0.1:8080/;'),
        code('      }'),
        code('  }'),

        h2("4.3 Jenkins CI/CD Pipeline"),
        code('  pipeline {'),
        code('    agent any'),
        code('    stages {'),
        code('      stage("Build") {'),
        code('        steps {'),
        code('          sh "mkdir -p build && cd build && cmake .. -DCMAKE_BUILD_TYPE=Release && make -j\\$(nproc)"'),
        code('        }'),
        code('      }'),
        code('      stage("Test") {'),
        code('        steps { sh "cd build && ctest --output-on-failure" }'),
        code('      }'),
        code('      stage("Package") {'),
        code('        steps { sh "./build_all.sh --package" }'),
        code('      }'),
        code('    }'),
        code('  }'),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 5: ANDROID DEPLOYMENT ============
        h1("5. Android Deployment (Phone OS)"),
        h2("5.1 Install APK Directly"),
        code('  adb install AI2ORBIT-Boost.apk'),
        code('  adb install AI2ORBIT-Tones.apk'),

        h2("5.2 Google Play (AAB Upload)"),
        new Paragraph({ numbering: { reference: "n1", level: 0 }, children: [new TextRun({ text: "Go to play.google.com/console", size: 22 })] }),
        new Paragraph({ numbering: { reference: "n1", level: 0 }, children: [new TextRun({ text: "Create new app (or select existing)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "n1", level: 0 }, children: [new TextRun({ text: "Go to Release > Production > Create new release", size: 22 })] }),
        new Paragraph({ numbering: { reference: "n1", level: 0 }, children: [new TextRun({ text: "Upload .aab file (AI2ORBIT-Tones.aab or AI2ORBIT-Boost.aab)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "n1", level: 0 }, children: [new TextRun({ text: "Fill store listing, screenshots, and submit for review", size: 22 })] }),

        h2("5.3 Android Boost via ADB"),
        code('  ./android_boost.sh --boost 100 --package com.ai2orbit.boost'),
        code('  ./android_boost.sh --install AI2ORBIT-Boost.apk --boost 75'),
        code('  ./android_boost.sh --boost-only         # Boost without launching app'),
        code('  ./android_boost.sh --restore             # Restore normal settings'),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 6: COMMAND LINE REFERENCE ============
        h1("6. Command Line Reference"),
        h2("6.1 Benchmark (AI2ORBIT-Benchmark)"),
        new Table({
          columnWidths: [3500, 5860],
          rows: [
            new TableRow({ children: [hdrCell("Command", 3500), hdrCell("Description", 5860)] }),
            new TableRow({ children: [codeCell("--cpu", 3500), cell("Run CPU benchmark", 5860)] }),
            new TableRow({ children: [codeCell("--memory", 3500, altShade), cell("Run memory benchmark", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--gpu", 3500), cell("Run GPU benchmark (CUDA/Vulkan)", 5860)] }),
            new TableRow({ children: [codeCell("--ml", 3500, altShade), cell("Run ML inference benchmark", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--dram", 3500), cell("Run DRAM mapper analysis", 5860)] }),
            new TableRow({ children: [codeCell("--all", 3500, altShade), cell("Run all benchmarks", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--json", 3500), cell("Output results in JSON format", 5860)] }),
            new TableRow({ children: [codeCell("--quiet", 3500, altShade), cell("Minimal output", 5860, altShade)] }),
          ]
        }),

        h2("6.2 Network Monitor (netmon)"),
        new Table({
          columnWidths: [3500, 5860],
          rows: [
            new TableRow({ children: [hdrCell("Command", 3500), hdrCell("Description", 5860)] }),
            new TableRow({ children: [codeCell("--duration <sec>", 3500), cell("Monitoring duration (default: 60)", 5860)] }),
            new TableRow({ children: [codeCell("--interval <sec>", 3500, altShade), cell("Time between checks (default: 1.0)", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--host <ip>", 3500), cell("Target host (default: 127.0.0.1)", 5860)] }),
            new TableRow({ children: [codeCell("--port <port>", 3500, altShade), cell("Target port (default: 80)", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--daemon", 3500), cell("Run continuously until Ctrl+C", 5860)] }),
            new TableRow({ children: [codeCell("--log <file>", 3500, altShade), cell("Log results to file", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--json", 3500), cell("Output in JSON format", 5860)] }),
            new TableRow({ children: [codeCell("--value", 3500, altShade), cell("Run network value analysis", 5860, altShade)] }),
          ]
        }),

        h2("6.3 Security Checker (checker)"),
        new Table({
          columnWidths: [3500, 5860],
          rows: [
            new TableRow({ children: [hdrCell("Command", 3500), hdrCell("Description", 5860)] }),
            new TableRow({ children: [codeCell("--scan", 3500), cell("Scan device for component integrity", 5860)] }),
            new TableRow({ children: [codeCell("--mirror", 3500, altShade), cell("Check for network eavesdropping", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--full", 3500), cell("Run full security check (scan + mirror)", 5860)] }),
            new TableRow({ children: [codeCell("--lobby --user NAME", 3500, altShade), cell("Start interactive group presence lobby", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--block ORIGIN", 3500), cell("Add untrusted origin to blocklist", 5860)] }),
            new TableRow({ children: [codeCell("--trust ORIGIN", 3500, altShade), cell("Add trusted origin to allowlist", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--auth entra", 3500), cell("Use Microsoft Entra ID auth", 5860)] }),
            new TableRow({ children: [codeCell("--json", 3500, altShade), cell("Output in JSON format", 5860, altShade)] }),
          ]
        }),

        h2("6.4 Boost Launcher"),
        new Table({
          columnWidths: [3500, 5860],
          rows: [
            new TableRow({ children: [hdrCell("Command", 3500), hdrCell("Description", 5860)] }),
            new TableRow({ children: [codeCell("--boost <0-100>", 3500), cell("Set boost level (default: 75)", 5860)] }),
            new TableRow({ children: [codeCell("--benchmark", 3500, altShade), cell("Launch benchmark with boost", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--netmon", 3500), cell("Launch netmon with boost", 5860)] }),
            new TableRow({ children: [codeCell("--checker", 3500, altShade), cell("Launch checker with boost", 5860, altShade)] }),
            new TableRow({ children: [codeCell("--full", 3500), cell("Run all tools with boost", 5860)] }),
          ]
        }),
        p("Boost Levels:"),
        new Table({
          columnWidths: [2000, 2000, 5360],
          rows: [
            new TableRow({ children: [hdrCell("Range", 2000), hdrCell("Mode", 2000), hdrCell("Effect", 5360)] }),
            new TableRow({ children: [cell("0-24%", 2000), cell("ECO", 2000), cell("Power saving, normal priority", 5360)] }),
            new TableRow({ children: [cell("25-49%", 2000, altShade), cell("BALANCED", 2000, altShade), cell("Normal performance, moderate priority", 5360, altShade)] }),
            new TableRow({ children: [cell("50-74%", 2000), cell("PERFORMANCE", 2000), cell("High priority, max CPU frequency", 5360)] }),
            new TableRow({ children: [cell("75-100%", 2000, altShade), cell("EXTREME", 2000, altShade), cell("Max CPU/GPU/RAM, thermal limits off", 5360, altShade)] }),
          ]
        }),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 7: UI VERSION ============
        h1("7. User Interface Version"),
        h2("7.1 Boost Controller App (Android)"),
        new Paragraph({ numbering: { reference: "bl3", level: 0 }, children: [new TextRun({ text: "Black screen with gold slider (0-100%)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl3", level: 0 }, children: [new TextRun({ text: "Slide left/right to adjust boost level", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl3", level: 0 }, children: [new TextRun({ text: "Shows current mode (ECO/BALANCED/PERFORMANCE/EXTREME)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl3", level: 0 }, children: [new TextRun({ text: "Tap APPLY to set the boost level", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl3", level: 0 }, children: [new TextRun({ text: "Package: com.ai2orbit.boost", size: 22 })] }),

        h2("7.2 Luxury Music Tones (Android)"),
        new Paragraph({ numbering: { reference: "bl4", level: 0 }, children: [new TextRun({ text: "ZEDGE-style grid layout with luxury gold icons", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl4", level: 0 }, children: [new TextRun({ text: "3 categories: Short Tones (3s), Audio Tones (15s), Music Tones (59s)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl4", level: 0 }, children: [new TextRun({ text: "Tap icon to preview, tap download to save as ringtone", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl4", level: 0 }, children: [new TextRun({ text: "Package: com.ai2orbit.tones", size: 22 })] }),

        h2("7.3 Financial Dashboard (Browser)"),
        new Paragraph({ numbering: { reference: "bl5", level: 0 }, children: [new TextRun({ text: "Open index.html in any browser (Chrome, Firefox, Edge)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl5", level: 0 }, children: [new TextRun({ text: "32 stocks, 6 indices, 4 crypto, 4 forex in single view", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl5", level: 0 }, children: [new TextRun({ text: "Auto-updates every 12 seconds with sparkline charts", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl5", level: 0 }, children: [new TextRun({ text: "Deploy: copy index.html to any web server (Nginx, Apache, S3)", size: 22 })] }),

        h2("7.4 Spotify Player (Browser)"),
        new Paragraph({ numbering: { reference: "bl6", level: 0 }, children: [new TextRun({ text: "Spotify-style dark theme music player", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl6", level: 0 }, children: [new TextRun({ text: "Playlist sidebar, album art, waveform visualization", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl6", level: 0 }, children: [new TextRun({ text: "Search, play/pause, next/prev, volume controls", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl6", level: 0 }, children: [new TextRun({ text: "Deploy: copy index.html to any web server", size: 22 })] }),
        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 8: QUICK START EXAMPLES ============
        h1("8. Quick Start Examples"),

        h2("8.1 Server: Run Network Monitor Daemon"),
        code('  # Linux/Ubuntu server'),
        code('  cd build'),
        code('  ./netmon --daemon --interval 5 --host 10.0.0.1 --port 443 --log /var/log/netmon.log'),

        h2("8.2 Server: Full Security Scan"),
        code('  ./checker --full --json > /var/log/security_scan.json'),

        h2("8.3 Desktop: Run Benchmark with Boost"),
        code('  # Linux/macOS'),
        code('  ./boost_run.sh --benchmark --boost 100'),
        code('  '),
        code('  # Windows'),
        code('  boost_run.bat --benchmark --boost 100'),
        code('  '),
        code('  # Cross-platform (Python)'),
        code('  python3 boost_run.py --benchmark --boost 75'),

        h2("8.4 Phone: Install and Boost App"),
        code('  # Install APK via ADB'),
        code('  adb install AI2ORBIT-Boost.apk'),
        code('  '),
        code('  # Run with max boost'),
        code('  ./android_boost.sh --boost 100 --package com.ai2orbit.boost'),

        h2("8.5 Deploy Dashboard Behind Nginx"),
        code('  # Copy files'),
        code('  sudo cp financial-dashboard/index.html /var/www/ai2orbit/'),
        code('  '),
        code('  # Configure Nginx (see Section 4.2)'),
        code('  sudo systemctl reload nginx'),

        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 9: IVR & PSMS INTEGRATION ============
        h1("9. IVR & Premium SMS (PSMS) Integration"),
        p("Components can be purchased and delivered via IVR (Interactive Voice Response) premium calls and PSMS (Premium SMS) messages. This enables monetization through telecom operator billing."),

        h2("9.1 IVR Call Flow"),
        p("Users call a premium-rate number and navigate an IVR menu using DTMF tones to select and purchase content."),
        bold("Call Number Format:"),
        new Table({
          columnWidths: [3000, 6360],
          rows: [
            new TableRow({ children: [hdrCell("Action", 3000), hdrCell("Example", 6360)] }),
            new TableRow({ children: [cell("Direct call", 3000), codeCell("CALL 16400", 6360)] }),
            new TableRow({ children: [cell("Call with selection", 3000, altShade), codeCell("CALL 16400##*2*2*#", 6360, altShade)] }),
            new TableRow({ children: [cell("Call with menu path", 3000), codeCell("CALL 16400##*1*3*#  (Category 1, Item 3)", 6360)] }),
          ]
        }),
        p("DTMF Selection Syntax: ##*<category>*<item>*#"),
        new Paragraph({ numbering: { reference: "bl7", level: 0 }, children: [new TextRun({ text: "First digit: Category (1=Tones, 2=Games, 3=Apps, 4=Benchmarks)", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl7", level: 0 }, children: [new TextRun({ text: "Second digit: Item number within category", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl7", level: 0 }, children: [new TextRun({ text: "Confirmation: # key to confirm purchase", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl7", level: 0 }, children: [new TextRun({ text: "Flow: Call > Welcome message > DTMF menu > Confirm > Deliver content > Disconnect", size: 22 })] }),

        h2("9.2 Premium SMS (PSMS)"),
        p("Users send an SMS with a keyword to a short code to purchase and receive content."),
        bold("SMS Format: Send keyword to short code number"),
        new Table({
          columnWidths: [2500, 2000, 2000, 2860],
          rows: [
            new TableRow({ children: [hdrCell("SMS To", 2500), hdrCell("Keyword", 2000), hdrCell("Content", 2000), hdrCell("Delivery", 2860)] }),
            new TableRow({ children: [cell("16401", 2500), codeCell("TONE1", 2000), cell("Classic Beep", 2000), cell("WAP Push / MMS", 2860)] }),
            new TableRow({ children: [cell("16401", 2500, altShade), codeCell("TONE14", 2000, altShade), cell("Soft Whistle", 2000, altShade), cell("WAP Push / MMS", 2860, altShade)] }),
            new TableRow({ children: [cell("16401", 2500), codeCell("GAME1", 2000), cell("Arcade Loop", 2000), cell("Download link SMS", 2860)] }),
            new TableRow({ children: [cell("16401", 2500, altShade), codeCell("GAME2", 2000, altShade), cell("Space Signal", 2000, altShade), cell("Download link SMS", 2860, altShade)] }),
            new TableRow({ children: [cell("16401", 2500), codeCell("MUSIC1", 2000), cell("Morning Melody", 2000), cell("WAP Push / MMS", 2860)] }),
            new TableRow({ children: [cell("16401", 2500, altShade), codeCell("BOOST", 2000, altShade), cell("Boost Controller", 2000, altShade), cell("Download link SMS", 2860, altShade)] }),
            new TableRow({ children: [cell("16401", 2500), codeCell("BENCH", 2000), cell("Benchmark Pro", 2000), cell("Download link SMS", 2860)] }),
          ]
        }),

        h2("9.3 Data Message at App Opening"),
        p("When a user opens the app for the first time, a data message can be sent to the operator billing system for subscription or one-time purchase activation."),
        new Paragraph({ numbering: { reference: "bl8", level: 0 }, children: [new TextRun({ text: "App sends silent data SMS to billing gateway on first launch", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl8", level: 0 }, children: [new TextRun({ text: "Operator confirms subscription via MT (Mobile Terminated) SMS", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl8", level: 0 }, children: [new TextRun({ text: "Content unlocked after operator confirmation", size: 22 })] }),
        new Paragraph({ numbering: { reference: "bl8", level: 0 }, children: [new TextRun({ text: "Send-and-forget model: app fires request and does not wait for sync response", size: 22 })] }),

        h2("9.4 Component Number Configuration"),
        p("To set up IVR/PSMS numbers for a component, configure the following parameters:"),
        new Table({
          columnWidths: [3000, 6360],
          rows: [
            new TableRow({ children: [hdrCell("Parameter", 3000), hdrCell("Description", 6360)] }),
            new TableRow({ children: [cell("IVR Number", 3000), cell("Premium rate call number (e.g., 16400)", 6360)] }),
            new TableRow({ children: [cell("PSMS Short Code", 3000, altShade), cell("SMS destination number (e.g., 16401)", 6360, altShade)] }),
            new TableRow({ children: [cell("Keyword Prefix", 3000), cell("Content keyword (TONE, GAME, MUSIC, BOOST, BENCH)", 6360)] }),
            new TableRow({ children: [cell("DTMF Menu Path", 3000, altShade), cell("IVR selection sequence (e.g., ##*2*2*#)", 6360, altShade)] }),
            new TableRow({ children: [cell("Delivery Method", 3000), cell("WAP Push, MMS, Download Link SMS, or Data Message", 6360)] }),
            new TableRow({ children: [cell("Billing Type", 3000, altShade), cell("One-time purchase or subscription", 6360, altShade)] }),
            new TableRow({ children: [cell("Operator", 3000), cell("Telecom operator for billing agreement", 6360)] }),
          ]
        }),

        h2("9.5 Example: Full Purchase Flow"),
        bold("Via IVR Call:"),
        code('  User dials: 16400'),
        code('  IVR: "Welcome to Luxury Music Tones. Press 1 for Tones, 2 for Games."'),
        code('  User presses: 1'),
        code('  IVR: "Press 1 for Classic Beep, 2 for Soft Chime..."'),
        code('  User presses: 2'),
        code('  IVR: "Soft Chime selected. Press # to confirm purchase."'),
        code('  User presses: #'),
        code('  IVR: "Thank you. Your tone will be delivered via SMS."'),
        code('  System sends download link SMS to user.'),
        p(""),
        bold("Via PSMS:"),
        code('  User sends SMS: TONE2 to 16401'),
        code('  System replies: "Soft Chime purchased. Download: https://dl.ai2orbit.com/tone2.ogg"'),
        code('  Operator bills user on next phone bill.'),
        p(""),
        bold("Shortcut (Call with DTMF):"),
        code('  User dials: 16400##*1*2*#'),
        code('  System auto-navigates: Category 1 (Tones) > Item 2 (Soft Chime)'),
        code('  Confirms and delivers immediately.'),

        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 10: APACHE MPM & SSL CONFIGURATION ============
        h1("10. Apache MPM & SSL Configuration"),
        p("Reference: https://httpd.apache.org/docs/2.4/mpm.html"),

        h2("10.1 Apache MPM Worker Configuration"),
        p("For handling concurrent connections from mobile devices, tablets, and servers, use MPM Event or Worker module:"),
        code('  # /etc/apache2/mods-available/mpm_event.conf'),
        code('  <IfModule mpm_event_module>'),
        code('      StartServers             3'),
        code('      MinSpareThreads         75'),
        code('      MaxSpareThreads        250'),
        code('      ThreadsPerChild         25'),
        code('      MaxRequestWorkers      400'),
        code('      MaxConnectionsPerChild   0'),
        code('  </IfModule>'),
        p("Enable MPM Event:"),
        code('  sudo a2dismod mpm_prefork'),
        code('  sudo a2enmod mpm_event'),

        h2("10.2 SSL Certificate Setup"),
        code('  # Install certbot for Let\'s Encrypt'),
        code('  sudo apt install certbot python3-certbot-apache'),
        code('  sudo certbot --apache -d benchmark.yourdomain.com'),
        p("Or manual SSL configuration:"),
        code('  <VirtualHost *:443>'),
        code('      ServerName benchmark.yourdomain.com'),
        code('      SSLEngine on'),
        code('      SSLCertificateFile /etc/ssl/certs/ai2orbit.crt'),
        code('      SSLCertificateKeyFile /etc/ssl/private/ai2orbit.key'),
        code('      SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1'),
        code('      SSLCipherSuite HIGH:!aNULL:!MD5'),
        code('      DocumentRoot /var/www/ai2orbit'),
        code('      ProxyPass /api/ http://127.0.0.1:8080/'),
        code('      ProxyPassReverse /api/ http://127.0.0.1:8080/'),
        code('  </VirtualHost>'),

        h2("10.3 Port & Socket Configuration"),
        p("Network chain: Mobile/Tablet > Zyxel Firewall > Apache Server > Backend"),
        new Table({
          columnWidths: [2000, 1500, 2500, 3360],
          rows: [
            new TableRow({ children: [hdrCell("Service", 2000), hdrCell("Port", 1500), hdrCell("Protocol", 2500), hdrCell("Description", 3360)] }),
            new TableRow({ children: [cell("HTTPS", 2000), cell("443", 1500), cell("TLS 1.2/1.3", 2500), cell("SSL encrypted web traffic", 3360)] }),
            new TableRow({ children: [cell("HTTP", 2000, altShade), cell("80", 1500, altShade), cell("TCP", 2500, altShade), cell("Redirect to 443", 3360, altShade)] }),
            new TableRow({ children: [cell("WebSocket", 2000), cell("443", 1500), cell("WSS (TLS)", 2500), cell("Real-time dashboard data", 3360)] }),
            new TableRow({ children: [cell("API Backend", 2000, altShade), cell("8080", 1500, altShade), cell("HTTP (internal)", 2500, altShade), cell("Benchmark results API", 3360, altShade)] }),
            new TableRow({ children: [cell("Netmon", 2000), cell("9090", 1500), cell("TCP", 2500), cell("Network monitor endpoint", 3360)] }),
            new TableRow({ children: [cell("SMPP", 2000, altShade), cell("2775", 1500, altShade), cell("SMPP v3.4", 2500, altShade), cell("SMS gateway (PSMS)", 3360, altShade)] }),
          ]
        }),

        h2("10.4 Zyxel Firewall Port Forwarding"),
        p("Configure NAT rules on Zyxel firewall to route external traffic to internal server:"),
        code('  # Zyxel USG/ATP Configuration'),
        code('  NAT Rule 1: WAN:443 > Server_IP:443 (HTTPS)'),
        code('  NAT Rule 2: WAN:80  > Server_IP:80  (HTTP redirect)'),
        code('  NAT Rule 3: WAN:9090 > Server_IP:9090 (Netmon)'),
        code('  Firewall Policy: Allow HTTPS, WSS from Any to Server_IP'),
        code('  SSL Inspection: Bypass for benchmark.yourdomain.com'),

        h2("10.5 Device Connection Chain"),
        code('  Mobile App (Android/iOS)'),
        code('    |-- HTTPS :443 (SSL/TLS)'),
        code('    v'),
        code('  Zyxel Firewall (NAT + Port Forward)'),
        code('    |-- Port 443 forwarded'),
        code('    v'),
        code('  Apache Server (MPM Event + mod_ssl + mod_proxy)'),
        code('    |-- Static files: /var/www/ai2orbit/'),
        code('    |-- API proxy: :8080 (benchmark backend)'),
        code('    |-- WebSocket: WSS for real-time dashboard'),
        code('    v'),
        code('  Backend Services'),
        code('    |-- Netmon daemon (:9090)'),
        code('    |-- Checker service'),
        code('    |-- Financial Dashboard'),
        code('    |-- SMPP Gateway (:2775) for PSMS'),

        new Paragraph({ children: [new PageBreak()] }),

        // ============ SECTION 11: VERSION HISTORY ============
        h1("11. Version History"),
        new Table({
          columnWidths: [1500, 2000, 5860],
          rows: [
            new TableRow({ children: [hdrCell("Version", 1500), hdrCell("Date", 2000), hdrCell("Changes", 5860)] }),
            new TableRow({ children: [cell("1.0", 1500), cell("April 12, 2026", 2000), cell("Initial release: Benchmark Pro with 285 tests, 98.7% coverage", 5860)] }),
            new TableRow({ children: [cell("1.5", 1500, altShade), cell("April 13, 2026", 2000, altShade), cell("Added Windows installer (Inno Setup), macOS DMG, automated build scripts", 5860, altShade)] }),
            new TableRow({ children: [cell("2.0", 1500), cell("April 14, 2026", 2000), cell("Added Luxury Music Tones, Financial Dashboard, Spotify Player, Boost Controller", 5860)] }),
            new TableRow({ children: [cell("2.1", 1500, altShade), cell("April 15, 2026", 2000, altShade), cell("Added Boost Launcher CLI with --boost parameter, MSVC build guide, server deployment docs", 5860, altShade)] }),
          ]
        }),

        new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Copyright 2026 AI2ORBIT Co. Made in Finland.", size: 22, color: "888888", italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "All Rights Reserved.", size: 20, color: "888888" })] }),
      ]
    }
  ]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/var/lib/freelancer/projects/40338131/docs/AI2ORBIT_Product_Guide.docx", buffer);
  console.log("Product Guide created!");
});
