const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
        WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak } = require('docx');

const tblBorder = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cb = { top: tblBorder, bottom: tblBorder, left: tblBorder, right: tblBorder };
const hdrShade = { fill: "1B2A4A", type: ShadingType.CLEAR };
const altShade = { fill: "F5F7FA", type: ShadingType.CLEAR };

function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun(text)] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 }, children: [new TextRun(text)] }); }
function p(text, opts = {}) { return new Paragraph({ spacing: { after: 100 }, ...opts, children: [new TextRun({ text, size: 22, font: "Arial", ...opts.run })] }); }
function pb(label, value) { return new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: label, bold: true, size: 22, font: "Arial" }), new TextRun({ text: value, size: 22, font: "Arial" })] }); }
function code(text) { return new Paragraph({ spacing: { after: 60 }, indent: { left: 360 }, children: [new TextRun({ text, size: 20, font: "Courier New", color: "333333" })] }); }

function mkCell(text, opts = {}) {
  return new TableCell({
    borders: cb, width: { size: opts.w || 4680, type: WidthType.DXA },
    shading: opts.shading, verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT,
      children: [new TextRun({ text, size: opts.size || 20, font: "Arial", bold: opts.bold, color: opts.color })] })]
  });
}

function mkRow(cells, isHeader) {
  return new TableRow({ tableHeader: isHeader,
    children: cells.map((c, i) => mkCell(c.text, { w: c.w, bold: isHeader, size: isHeader ? 20 : 20,
      color: isHeader ? "FFFFFF" : "333333", shading: isHeader ? hdrShade : (c.alt ? altShade : undefined), align: c.align }))
  });
}

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", run: { size: 52, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 600, after: 120 }, alignment: AlignmentType.CENTER } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, color: "2D4A7A", font: "Arial" }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
    ]
  },
  numbering: {
    config: [
      { reference: "bl-desktop", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl-android", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl-ios", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl-flags", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl-tests", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl-deps", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    properties: {
      page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
    },
    headers: {
      default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "AI2ORBIT - Build Syntax Guide v1.0.0", size: 18, color: "888888", font: "Arial", italics: true })] })] })
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
        new TextRun({ text: "Copyright (c) AI-2-Orbit Co. 2026. All rights reserved. | Turku, Finland  |  Page ", size: 18, color: "888888", font: "Arial" }),
        new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "888888", font: "Arial" }),
        new TextRun({ text: " of ", size: 18, color: "888888", font: "Arial" }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: "888888", font: "Arial" }),
      ] })] })
    },
    children: [
      // TITLE PAGE
      new Paragraph({ spacing: { before: 2400 }, alignment: AlignmentType.CENTER, children: [] }),
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("AI2ORBIT")] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Build Syntax, Naming & Release Candidate Guide", size: 32, color: "2D4A7A", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Version 1.0.0", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "AI-2-Orbit Co. | Turku, Finland", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "April 2026", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "CONFIDENTIAL", size: 20, bold: true, color: "CC0000", font: "Arial" })] }),

      new Paragraph({ children: [new PageBreak()] }),

      // SECTION 1: OVERVIEW
      h1("1. Overview"),
      p("AI2ORBIT is a multi-platform benchmark and network monitoring product suite built on a shared C++17 core engine (BenchmarkCore v2.0.0). The suite compiles and runs on Windows, macOS, Linux, Android (Kotlin + NDK), and iOS (Objective-C++ bridge + Swift)."),
      p("The product line consists of desktop CLI tools, mobile applications, and an iOS framework - all powered by the same BenchmarkCore static library for consistent performance measurement across platforms."),

      // SECTION 2: NAMING
      h1("2. Product Naming Convention"),
      p("All executables follow the unified pattern: AI2ORBIT-{ModuleName}"),
      h2("2.1 Desktop Products (Windows / macOS / Linux)"),
      new Table({
        columnWidths: [3000, 6360], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Executable", w: 3000}, {text: "Description", w: 6360}], true),
          mkRow([{text: "AI2ORBIT-Benchmark", w: 3000}, {text: "Full system performance benchmark suite (CPU, RAM, GPU, DRAM, Network, ML)", w: 6360, alt: true}]),
          mkRow([{text: "AI2ORBIT-NetMon", w: 3000}, {text: "Network quality monitor with value analysis, signal bands, packet cohort", w: 6360}]),
          mkRow([{text: "AI2ORBIT-Checker", w: 3000}, {text: "Security and integrity checker (device scan, mirror detection, lobby)", w: 6360, alt: true}]),
        ]
      }),

      h2("2.2 Android Applications (Google Play)"),
      new Table({
        columnWidths: [3600, 2400, 3360], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Package", w: 3600}, {text: "App Name", w: 2400}, {text: "Description", w: 3360}], true),
          mkRow([{text: "com.ai2orbit.benchmarkpro", w: 3600}, {text: "Benchmark Pro", w: 2400}, {text: "Main app (Benchmark + History tabs)", w: 3360, alt: true}]),
          mkRow([{text: "com.ai2orbit.network", w: 3600}, {text: "AI2ORBIT Network", w: 2400}, {text: "Standalone network monitor", w: 3360}]),
          mkRow([{text: "com.ai2orbit.financial", w: 3600}, {text: "AI2ORBIT Financial", w: 2400}, {text: "CDS/rating calculator", w: 3360, alt: true}]),
          mkRow([{text: "com.ai2orbit.music", w: 3600}, {text: "AI2ORBIT Music", w: 2400}, {text: "Standalone music player", w: 3360}]),
        ]
      }),

      h2("2.3 iOS Applications (App Store)"),
      pb("Bundle ID: ", "com.ai2orbit.benchmarkcore"),
      pb("Framework: ", "BenchmarkCore.framework via Objective-C++ bridge (BenchmarkBridge.h / BenchmarkBridge.mm)"),

      new Paragraph({ children: [new PageBreak()] }),

      // SECTION 3: BUILD SYSTEM
      h1("3. Build System - CMake Configuration"),
      pb("Build system: ", "CMake 3.14+ with C++17 standard"),
      pb("Project name: ", "BenchmarkCore"),
      pb("Project version: ", "2.0.0"),
      pb("Core library: ", "BenchmarkCore (static library - .a on Unix, .lib on Windows)"),

      h2("3.1 Source Modules"),
      new Table({
        columnWidths: [3120, 3120, 3120], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Module", w: 3120}, {text: "Module", w: 3120}, {text: "Module", w: 3120}], true),
          mkRow([{text: "memory_benchmark", w: 3120}, {text: "vulkan_benchmark", w: 3120}, {text: "netmon", w: 3120, alt: true}]),
          mkRow([{text: "cpu_benchmark", w: 3120, alt: true}, {text: "dram_mapper", w: 3120, alt: true}, {text: "ml_benchmark", w: 3120}]),
          mkRow([{text: "memory_profiler", w: 3120}, {text: "cuda_native", w: 3120}, {text: "checker", w: 3120, alt: true}]),
          mkRow([{text: "cuda_benchmark", w: 3120, alt: true}, {text: "network_benchmark", w: 3120, alt: true}, {text: "", w: 3120}]),
        ]
      }),

      h2("3.2 Build Commands (All Platforms)"),
      code("mkdir build && cd build"),
      code("cmake .. -DCMAKE_BUILD_TYPE=Release"),
      code("cmake --build . --config Release"),
      p(""),
      pb("Install: ", "cmake --install . --prefix /usr/local"),

      // SECTION 4: COMPILER COMPATIBILITY
      h1("4. Compiler Compatibility"),
      new Table({
        columnWidths: [2400, 3480, 3480], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Compiler", w: 2400}, {text: "Counter / Version", w: 3480}, {text: "Notes", w: 3480}], true),
          mkRow([{text: "GCC", w: 2400}, {text: "ta-4 (GCC 10+ recommended)", w: 3480}, {text: "-Wall -Wextra -Werror (Linux)", w: 3480, alt: true}]),
          mkRow([{text: "MSVC", w: 2400, alt: true}, {text: "yg-4 (VS 2019+ / MSVC 14.2+)", w: 3480, alt: true}, {text: "/W4, /O2 (Release)", w: 3480}]),
          mkRow([{text: "Clang/AppleClang", w: 2400}, {text: "macOS native", w: 3480}, {text: "-Wall -Wextra (no -Werror on Apple)", w: 3480, alt: true}]),
          mkRow([{text: "Android NDK", w: 2400, alt: true}, {text: "r25 with c++_shared STL", w: 3480, alt: true}, {text: "ABI: armeabi-v7a, arm64-v8a, x86, x86_64", w: 3480}]),
        ]
      }),

      h2("4.1 Optimization Flags"),
      pb("GCC/Clang Release: ", "-O3"),
      pb("MSVC Release: ", "/O2"),
      pb("NDK C++ Flags: ", "-std=c++17 -Wall -Wextra"),

      new Paragraph({ children: [new PageBreak()] }),

      // SECTION 5: TESTING
      h1("5. Testing Framework"),
      pb("Framework: ", "Google Test v1.14.0 (fetched via CMake FetchContent)"),
      pb("Total tests: ", "285 tests (100% passing)"),
      pb("Code coverage: ", "98.7% (via lcov)"),

      h2("5.1 Test Executables (12 modules)"),
      new Table({
        columnWidths: [3120, 3120, 3120], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Test Module", w: 3120}, {text: "Test Module", w: 3120}, {text: "Test Module", w: 3120}], true),
          mkRow([{text: "test_timer", w: 3120}, {text: "test_vulkan_benchmark", w: 3120}, {text: "test_netmon", w: 3120, alt: true}]),
          mkRow([{text: "test_cpu_benchmark", w: 3120, alt: true}, {text: "test_dram_mapper", w: 3120, alt: true}, {text: "test_ml_benchmark", w: 3120}]),
          mkRow([{text: "test_memory_benchmark", w: 3120}, {text: "test_cuda_native", w: 3120}, {text: "test_checker", w: 3120, alt: true}]),
          mkRow([{text: "test_memory_profiler", w: 3120, alt: true}, {text: "test_network_benchmark", w: 3120, alt: true}, {text: "", w: 3120}]),
          mkRow([{text: "test_cuda_benchmark", w: 3120}, {text: "", w: 3120}, {text: "", w: 3120}]),
        ]
      }),

      h2("5.2 Running Tests"),
      code("cd build && ctest --output-on-failure"),
      p(""),
      pb("Coverage build: ", ""),
      code("cmake .. -DENABLE_COVERAGE=ON"),
      code("cmake --build ."),
      code("ctest --output-on-failure"),
      code("lcov --capture --directory . --output-file coverage.info"),
      code("genhtml coverage.info --output-directory coverage_report"),

      // SECTION 6: VERSIONING
      h1("6. Release Candidates and Versioning"),
      pb("Version format: ", "MAJOR.MINOR.PATCH (Semantic Versioning)"),

      h2("6.1 Current Versions"),
      new Table({
        columnWidths: [4680, 4680], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Component", w: 4680}, {text: "Version", w: 4680}], true),
          mkRow([{text: "BenchmarkCore C++ engine", w: 4680}, {text: "v2.0.0", w: 4680, alt: true}]),
          mkRow([{text: "Benchmark Pro Android", w: 4680, alt: true}, {text: "v1.3.0 (versionCode 4)", w: 4680}]),
          mkRow([{text: "Network app Android", w: 4680}, {text: "v1.0.0", w: 4680, alt: true}]),
          mkRow([{text: "Financial app Android", w: 4680, alt: true}, {text: "v1.0.0", w: 4680}]),
          mkRow([{text: "Music app Android", w: 4680}, {text: "v1.0.0", w: 4680, alt: true}]),
          mkRow([{text: "Desktop installer (Win/Mac)", w: 4680, alt: true}, {text: "v1.0.0", w: 4680}]),
        ]
      }),

      h2("6.2 Release Candidate Naming"),
      pb("RC format: ", "AI2ORBIT-{Product}-v{X.Y.Z}-rc{N}"),
      pb("Example RC: ", "AI2ORBIT_Network_Setup_v1.0.0-rc1.exe"),
      pb("Production: ", "AI2ORBIT_Network_Setup_v1.0.0.exe"),

      h2("6.3 Android Release Signing"),
      pb("Keystore: ", "ai2orbit-release.keystore"),
      pb("Key alias: ", "ai2orbit-key"),
      pb("AAB build: ", "./gradlew bundleRelease"),
      pb("APK build: ", "./gradlew assembleRelease"),

      new Paragraph({ children: [new PageBreak()] }),

      // SECTION 7: PACKAGING
      h1("7. Platform-Specific Packaging"),

      h2("7.1 Windows"),
      new Table({
        columnWidths: [3120, 6240], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Property", w: 3120}, {text: "Value", w: 6240}], true),
          mkRow([{text: "Installer", w: 3120}, {text: "Inno Setup 6 wizard (.iss script)", w: 6240, alt: true}]),
          mkRow([{text: "Output", w: 3120, alt: true}, {text: "AI2ORBIT_Network_Setup_v1.0.0.exe", w: 6240}]),
          mkRow([{text: "Install path", w: 3120}, {text: "C:\\Program Files\\AI2ORBIT\\Network\\", w: 6240, alt: true}]),
          mkRow([{text: "Start Menu", w: 3120, alt: true}, {text: "AI2ORBIT group with shortcuts for all 3 tools", w: 6240}]),
          mkRow([{text: "Registry", w: 3120}, {text: "HKLM\\Software\\AI2ORBIT (InstallPath, Version, Publisher)", w: 6240, alt: true}]),
          mkRow([{text: "CPack fallback", w: 3120, alt: true}, {text: "NSIS + ZIP", w: 6240}]),
        ]
      }),

      h2("7.2 macOS"),
      new Table({
        columnWidths: [3120, 6240], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Property", w: 3120}, {text: "Value", w: 6240}], true),
          mkRow([{text: "Installer", w: 3120}, {text: "DMG with .app bundle (drag-and-drop)", w: 6240, alt: true}]),
          mkRow([{text: "Output", w: 3120, alt: true}, {text: "AI2ORBIT_Network_v1.0.0.dmg", w: 6240}]),
          mkRow([{text: "Bundle ID", w: 3120}, {text: "com.ai2orbit.network", w: 6240, alt: true}]),
          mkRow([{text: "Minimum OS", w: 3120, alt: true}, {text: "macOS 12.0 (Monterey)", w: 6240}]),
          mkRow([{text: "CPack fallback", w: 3120}, {text: "DragNDrop + ZIP", w: 6240, alt: true}]),
        ]
      }),

      h2("7.3 Linux"),
      pb("Packages: ", "TGZ and DEB (via CPack)"),
      pb("Install path: ", "/usr/local/bin/"),

      h2("7.4 Android"),
      pb("Format: ", "AAB (App Bundle) for Google Play, APK for direct install"),
      pb("Minimum SDK: ", "21 (Android 5.0)"),
      pb("Target SDK: ", "34 (Android 14)"),

      h2("7.5 iOS"),
      pb("Format: ", "IPA via Xcode Archive"),
      pb("Minimum: ", "iOS 18 v26"),
      pb("Framework: ", "BenchmarkCore.framework (Obj-C++ bridge)"),

      new Paragraph({ children: [new PageBreak()] }),

      // SECTION 8: DEPENDENCIES
      h1("8. Dependencies"),
      new Table({
        columnWidths: [2400, 6960], margins: { top: 60, bottom: 60, left: 120, right: 120 },
        rows: [
          mkRow([{text: "Platform", w: 2400}, {text: "Dependencies", w: 6960}], true),
          mkRow([{text: "C++ (all)", w: 2400}, {text: "pthreads, ws2_32 (Windows only)", w: 6960, alt: true}]),
          mkRow([{text: "Android", w: 2400, alt: true}, {text: "AndroidX, Material3, Room 2.6.1, KSP, ViewPager2", w: 6960}]),
          mkRow([{text: "iOS", w: 2400}, {text: "UIKit, Foundation, BenchmarkBridge (custom Obj-C++ bridge)", w: 6960, alt: true}]),
          mkRow([{text: "Testing", w: 2400, alt: true}, {text: "Google Test 1.14.0, Google Mock", w: 6960}]),
        ]
      }),

      // END
      new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "--- End of Document ---", size: 20, color: "888888", font: "Arial", italics: true })] }),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/var/lib/freelancer/projects/40338131/docs/AI2ORBIT_Build_Syntax_Guide.docx", buffer);
  console.log("Build Syntax Guide created successfully.");
});
