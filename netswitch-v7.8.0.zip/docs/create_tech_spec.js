const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
        WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak } = require('docx');

const tb = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cb = { top: tb, bottom: tb, left: tb, right: tb };
const hS = { fill: "1B2A4A", type: ShadingType.CLEAR };
const aS = { fill: "F5F7FA", type: ShadingType.CLEAR };

function mkCell(text, opts = {}) {
  return new TableCell({
    borders: cb, width: { size: opts.w || 3120, type: WidthType.DXA },
    shading: opts.shading, verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT,
      children: [new TextRun({ text, size: opts.size || 20, font: opts.font || "Arial", bold: opts.bold, color: opts.color || "333333" })] })]
  });
}
function hdrCell(text, w) { return mkCell(text, { w, bold: true, color: "FFFFFF", shading: hS, size: 20 }); }
function dataCell(text, w, alt) { return mkCell(text, { w, shading: alt ? aS : undefined }); }
function numCell(text, w, alt) { return mkCell(text, { w, shading: alt ? aS : undefined, align: AlignmentType.RIGHT }); }

function h1(t) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun(t)] }); }
function h2(t) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 }, children: [new TextRun(t)] }); }
function p(t) { return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: t, size: 22, font: "Arial" })] }); }
function pb(l, v) { return new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: l, bold: true, size: 22, font: "Arial" }), new TextRun({ text: v, size: 22, font: "Arial" })] }); }
function code(t) { return new Paragraph({ spacing: { after: 40 }, indent: { left: 360 }, children: [new TextRun({ text: t, size: 18, font: "Courier New", color: "333333" })] }); }

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", run: { size: 52, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 600, after: 120 }, alignment: AlignmentType.CENTER } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: "1B2A4A", font: "Arial" }, paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, color: "2D4A7A", font: "Arial" }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
    ]
  },
  numbering: { config: [
    { reference: "bl1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ]},
  sections: [{
    properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "AI2ORBIT - Technical Specification v1.0.0", size: 18, color: "888888", font: "Arial", italics: true })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
      new TextRun({ text: "Copyright (c) AI-2-Orbit Co. 2026  |  Page ", size: 18, color: "888888", font: "Arial" }),
      new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "888888", font: "Arial" }),
      new TextRun({ text: " of ", size: 18, color: "888888", font: "Arial" }),
      new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: "888888", font: "Arial" }),
    ] })] }) },
    children: [
      // TITLE PAGE
      new Paragraph({ spacing: { before: 2000 }, children: [] }),
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("AI2ORBIT")] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Technical Specification", size: 36, color: "2D4A7A", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Complete Results, Configurations & Technical Syntaxes", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "BenchmarkCore v2.0.0 | All Platforms", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "AI-2-Orbit Co. | Turku, Finland | April 2026", size: 24, color: "666666", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "CONFIDENTIAL", size: 20, bold: true, color: "CC0000", font: "Arial" })] }),

      new Paragraph({ children: [new PageBreak()] }),

      // 1. BENCHMARK RESULTS
      h1("1. Performance Benchmark Results"),
      p("Full system benchmark output from BenchmarkCore v2.0.0 with 10 test modules, 230+ individual tests."),

      h2("1.1 Performance Scoreboard"),
      new Table({
        columnWidths: [2800, 2400, 1800, 1200, 1160], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Module", 2800), hdrCell("Value", 2400), hdrCell("Unit", 1800), hdrCell("DRAM", 1200), hdrCell("Status", 1160)] }),
          new TableRow({ children: [dataCell("CPU Compute", 2800), numCell("916.71", 2400), dataCell("MFlops", 1800), dataCell("N/A", 1200), dataCell("PASS", 1160)] }),
          new TableRow({ children: [dataCell("RAM Throughput", 2800, true), numCell("1270.2", 2400, true), dataCell("MB/s", 1800, true), dataCell("N/A", 1200, true), dataCell("PASS", 1160, true)] }),
          new TableRow({ children: [dataCell("Cache Peak BW", 2800), numCell("55573.7", 2400), dataCell("MB/s", 1800), dataCell("N/A", 1200), dataCell("PASS", 1160)] }),
          new TableRow({ children: [dataCell("GPU Compute", 2800, true), numCell("611.95", 2400, true), dataCell("GFLOPS", 1800, true), dataCell("N/A", 1200, true), dataCell("PASS", 1160, true)] }),
          new TableRow({ children: [dataCell("CUDA-C Peak", 2800), numCell("680.14", 2400), dataCell("GFLOPS", 1800), dataCell("17.9x", 1200), dataCell("PASS", 1160)] }),
          new TableRow({ children: [dataCell("Vulkan Fill", 2800, true), numCell("414637.17", 2400, true), dataCell("Mpix/s", 1800, true), dataCell("N/A", 1200, true), dataCell("PASS", 1160, true)] }),
          new TableRow({ children: [dataCell("DRAM Accel", 2800), numCell("1.2x", 2400), dataCell("factor", 1800), dataCell("N/A", 1200), dataCell("PASS", 1160)] }),
          new TableRow({ children: [dataCell("Network BW", 2800, true), numCell("1539.59", 2400, true), dataCell("Mbps", 1800, true), dataCell("N/A", 1200, true), dataCell("PASS", 1160, true)] }),
          new TableRow({ children: [dataCell("Net Quality", 2800), numCell("WHITE", 2400), dataCell("echo=48.7us", 1800), dataCell("N/A", 1200), dataCell("PASS", 1160)] }),
          new TableRow({ children: [dataCell("AI MatMul", 2800, true), numCell("23.72", 2400, true), dataCell("GFLOPS", 1800, true), dataCell("2.5x", 1200, true), dataCell("PASS", 1160, true)] }),
        ]
      }),

      h2("1.2 CPU Benchmark"),
      pb("Type: ", "Mixed CPU Workload"),
      pb("Iterations: ", "1,000,000"),
      pb("Total Time: ", "0.003273 seconds"),
      pb("Operations/Second: ", "916,710,159.47"),
      pb("Time/Operation: ", "1.09 ns"),

      h2("1.3 RAM Benchmark"),
      pb("Buffer Size: ", "100.00 MB"),
      pb("Iterations: ", "10"),
      pb("Throughput: ", "1,270.18 MB/s"),
      pb("Min Latency: ", "235,673,585.00 ns"),
      pb("Max Latency: ", "237,519,579.00 ns"),
      pb("Std Deviation: ", "514,891.23 ns"),
      pb("Coefficient of Variation: ", "0.22%"),
      pb("Verification: ", "PASSED"),

      h2("1.4 Memory Hierarchy Profiler"),
      p("Cache hierarchy latency and bandwidth measurements:"),
      new Table({
        columnWidths: [1800, 1800, 1800, 1800, 2160], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Size", 1800), hdrCell("Level", 1800), hdrCell("Latency (ns)", 1800), hdrCell("BW (MB/s)", 1800), hdrCell("Status", 2160)] }),
          new TableRow({ children: [dataCell("1 KB", 1800), dataCell("L1", 1800), numCell("0.00", 1800), numCell("52987.7", 1800), dataCell("PASS", 2160)] }),
          new TableRow({ children: [dataCell("32 KB", 1800, true), dataCell("L1", 1800, true), numCell("0.00", 1800, true), numCell("55212.0", 1800, true), dataCell("PASS", 2160, true)] }),
          new TableRow({ children: [dataCell("128 KB", 1800), dataCell("L2", 1800), numCell("0.00", 1800), numCell("55223.4", 1800), dataCell("PASS", 2160)] }),
          new TableRow({ children: [dataCell("1 MB", 1800, true), dataCell("L2", 1800, true), numCell("0.00", 1800, true), numCell("54466.8", 1800, true), dataCell("PASS", 2160, true)] }),
          new TableRow({ children: [dataCell("4 MB", 1800), dataCell("L3", 1800), numCell("0.00", 1800), numCell("52198.6", 1800), dataCell("PASS", 2160)] }),
          new TableRow({ children: [dataCell("16 MB", 1800, true), dataCell("DRAM", 1800, true), numCell("0.00", 1800, true), numCell("49342.0", 1800, true), dataCell("PASS", 2160, true)] }),
          new TableRow({ children: [dataCell("64 MB", 1800), dataCell("DRAM", 1800), numCell("0.00", 1800), numCell("34889.8", 1800), dataCell("PASS", 2160)] }),
        ]
      }),

      new Paragraph({ children: [new PageBreak()] }),

      h2("1.5 CUDA-C Native Benchmark"),
      new Table({
        columnWidths: [3600, 2880, 2880], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Kernel", 3600), hdrCell("Performance", 2880), hdrCell("Time (ms)", 2880)] }),
          new TableRow({ children: [dataCell("SGEMM (Matrix Multiply)", 3600), numCell("680.14 GFLOPS", 2880), numCell("11.840", 2880)] }),
          new TableRow({ children: [dataCell("Parallel Reduction (Sum)", 3600, true), numCell("18.13 GB/s", 2880, true), numCell("13.883", 2880, true)] }),
          new TableRow({ children: [dataCell("2D Stencil (5-point)", 3600), numCell("1109.53 GB/s", 2880), numCell("0.271", 2880)] }),
          new TableRow({ children: [dataCell("PCIe Transfer (H2D + D2H)", 3600, true), numCell("25.00 GB/s", 2880, true), numCell("4.462", 2880, true)] }),
          new TableRow({ children: [dataCell("Atomic Operations", 3600), numCell("29.00 Gops/s", 2880), numCell("1.157", 2880)] }),
        ]
      }),
      pb("DRAM-Prioritized Speedup: ", "17.9x"),

      h2("1.6 AI/ML Benchmark"),
      pb("Network Architecture: ", "784 -> 128 (relu) -> 10 [101,770 params]"),
      pb("Inference Throughput: ", "101,886 inferences/s"),
      pb("Inference Latency: ", "9.8 us (avg), 9.4 us (min)"),
      pb("Training Speed: ", "45.47 epochs/s"),
      pb("Training Accuracy: ", "100.0%"),
      pb("Loss History: ", "2.1104 -> 1.7488 -> 1.4046 -> 1.0679 -> 0.7677"),
      p(""),
      pb("MatMul: ", "23.72 GFLOPS"),
      pb("Element-wise: ", "20.00 Gops/s"),
      pb("Conv2D: ", "3.51 GFLOPS"),
      pb("Inference DRAM Speedup: ", "2.5x"),
      pb("Training DRAM Speedup: ", "14.3x"),

      new Paragraph({ children: [new PageBreak()] }),

      // 2. NETWORK VALUE ANALYSIS
      h1("2. Network Value Analysis Results"),
      p("Complete output from AI2ORBIT-NetMon --value analysis."),

      h2("2.1 Packet Cohort Analysis"),
      new Table({
        columnWidths: [4680, 4680], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Parameter", 4680), hdrCell("Value", 4680)] }),
          new TableRow({ children: [dataCell("Packet Size", 4680), numCell("1.0 KB", 4680)] }),
          new TableRow({ children: [dataCell("Cohort Size", 4680, true), numCell("44.0 KB", 4680, true)] }),
          new TableRow({ children: [dataCell("Octets/Frame", 4680), numCell("500", 4680)] }),
          new TableRow({ children: [dataCell("Frame Threshold", 4680, true), numCell("413.0", 4680, true)] }),
          new TableRow({ children: [dataCell("Assembled Size", 4680), numCell("1.886 KB", 4680)] }),
        ]
      }),

      h2("2.2 Signal Quality"),
      pb("Signal Factor: ", "0.006624"),
      pb("RadSin(59): ", "0.857167"),
      pb("Normalized: ", "0.006555"),
      pb("1MB Correction: ", "-0.000400"),
      p(""),
      pb("Mathematical formula: ", ""),
      code("sin(24KB / 500 / 4.3998 / 1.4117 * radsin(59))"),
      code("1MB gives -0.0004 correction"),

      h2("2.3 Line Metrics"),
      pb("Line Length: ", "458.5828"),
      pb("Router Distance: ", "3.0336"),
      pb("Occupancy Norm: ", "0.9900"),
      p(""),
      pb("Line formula: ", "124457.1 * 4417.00890449 / 1.19875423 / 1e6"),
      pb("Router distance: ", "74.4 / 89.049 * rad(cos(tau)) * sec * meter * mile(1.60944 * sin(tau) - 2.9)"),

      h2("2.4 Network Value"),
      pb("Value Margin: ", "1.866542"),
      pb("Profit Factor: ", "0.042421"),

      h2("2.5 Compiler Compatibility Counters"),
      pb("GCC Counter: ", "4 (ta-4)"),
      pb("MSVC Counter: ", "4 (yg-4)"),

      h2("2.6 Signal Bands (5G NR / LTE)"),
      new Table({
        columnWidths: [1560, 2400, 2400, 2400, 600], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Band", 1560), hdrCell("Freq (GHz)", 2400), hdrCell("RSSI (dBm)", 2400), hdrCell("SNR (dB)", 2400), hdrCell("", 600)] }),
          new TableRow({ children: [dataCell("n9", 1560), numCell("0.900", 2400), numCell("-75.0", 2400), numCell("18.0", 2400), dataCell("", 600)] }),
          new TableRow({ children: [dataCell("n8", 1560, true), numCell("0.900", 2400, true), numCell("-72.0", 2400, true), numCell("20.4", 2400, true), dataCell("", 600, true)] }),
          new TableRow({ children: [dataCell("n77", 1560), numCell("3.700", 2400), numCell("-93.8", 2400), numCell("3.0", 2400), dataCell("", 600)] }),
          new TableRow({ children: [dataCell("n78", 1560, true), numCell("3.500", 2400, true), numCell("-91.6", 2400, true), numCell("4.7", 2400, true), dataCell("", 600, true)] }),
          new TableRow({ children: [dataCell("n79", 1560), numCell("4.700", 2400), numCell("-98.8", 2400), numCell("-1.0", 2400), dataCell("", 600)] }),
          new TableRow({ children: [dataCell("n10", 1560, true), numCell("2.100", 2400, true), numCell("-83.4", 2400, true), numCell("11.3", 2400, true), dataCell("", 600, true)] }),
          new TableRow({ children: [dataCell("n11", 1560), numCell("1.500", 2400), numCell("-80.0", 2400), numCell("14.0", 2400), dataCell("", 600)] }),
          new TableRow({ children: [dataCell("n15", 1560, true), numCell("1.500", 2400, true), numCell("-81.0", 2400, true), numCell("13.2", 2400, true), dataCell("", 600, true)] }),
          new TableRow({ children: [dataCell("n28", 1560), numCell("0.700", 2400), numCell("-67.0", 2400), numCell("24.4", 2400), dataCell("", 600)] }),
        ]
      }),

      h2("2.7 Occupancy Testing"),
      pb("Load 1: ", "0.990000"),
      pb("Load 100: ", "0.000399872"),
      p("Power law: occupancy = 0.99 / x^exponent"),

      new Paragraph({ children: [new PageBreak()] }),

      // 3. SECURITY CHECKER
      h1("3. Security Checker Results"),
      p("Full security check output from AI2ORBIT-Checker --full."),

      h2("3.1 Overall Status"),
      pb("Result: ", "PASSED"),
      pb("Time: ", "0.002 seconds"),

      h2("3.2 Authentication"),
      pb("Provider: ", "Local (supports Microsoft Entra ID and OKTA)"),

      h2("3.3 Group Presence"),
      pb("Connection: ", "OPEN"),
      pb("Members: ", "1/1 at desk"),
      pb("Quorum: ", "MET (configurable ratio 0.0-1.0, default 0.5)"),

      h2("3.4 Network Echo (Mirror Detection)"),
      pb("Baseline Echo: ", "40.9 us"),
      pb("Current Echo: ", "40.9 us"),
      pb("Deviation: ", "0.0%"),
      pb("Mirror Status: ", "CLEAR"),
      pb("Checksum: ", "469d2ff6 [VALID]"),
      pb("Detail: ", "Echo stable (0% deviation) - no mirror detected"),

      h2("3.5 Device Integrity"),
      pb("Platform: ", "Linux"),
      pb("Device: ", "x86_64"),
      pb("OS: ", "Linux 6.8.0-100-generic"),
      pb("Components Scanned: ", "23"),
      pb("Trusted: ", "15"),
      pb("Unknown: ", "8"),
      pb("Untrusted: ", "0"),
      pb("Verdict: ", "CLEAN"),

      new Paragraph({ children: [new PageBreak()] }),

      // 4. NETWORK QUALITY MONITOR
      h1("4. Network Quality Monitor"),
      h2("4.1 Quality Classification System"),
      new Table({
        columnWidths: [2340, 2340, 4680], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Rating", 2340), hdrCell("Meaning", 2340), hdrCell("Criteria", 4680)] }),
          new TableRow({ children: [dataCell("WHITE", 2340), dataCell("Good", 2340), dataCell("Low latency, high bandwidth, zero/low packet loss", 4680)] }),
          new TableRow({ children: [dataCell("GREY", 2340, true), dataCell("Fair", 2340, true), dataCell("Moderate latency or bandwidth degradation", 4680, true)] }),
          new TableRow({ children: [dataCell("BLACK", 2340), dataCell("Poor", 2340), dataCell("High latency, low bandwidth, or significant packet loss", 4680)] }),
        ]
      }),

      h2("4.2 Live Sample Output"),
      pb("Quality: ", "WHITE [Good]"),
      pb("Echo Latency: ", "48.7 us"),
      pb("Bandwidth: ", "10,386.2 Mbps"),
      pb("Packet Loss: ", "0.00%"),
      pb("Jitter: ", "4.6 us"),
      pb("CRC32 Checksum: ", "9a2f177c [VALID] (IEEE 802.3)"),

      h2("4.3 Monitoring Modes"),
      pb("Live mode: ", "AI2ORBIT-NetMon (continuous monitoring, configurable interval)"),
      pb("Value mode: ", "AI2ORBIT-NetMon --value (single analysis, exits)"),
      pb("EULA skip: ", "AI2ORBIT-NetMon --accept-eula --value"),

      // 5. TEST RESULTS
      h1("5. Test Suite Results"),
      pb("Total Tests: ", "285"),
      pb("Passed: ", "285 (100%)"),
      pb("Failed: ", "0"),
      pb("Total Time: ", "48.81 seconds"),
      pb("Code Coverage: ", "98.7%"),

      h2("5.1 Test Breakdown by Module"),
      new Table({
        columnWidths: [4680, 2340, 2340], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Test Module", 4680), hdrCell("Tests", 2340), hdrCell("Status", 2340)] }),
          new TableRow({ children: [dataCell("test_timer", 4680), numCell("15", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_cpu_benchmark", 4680, true), numCell("20", 2340, true), dataCell("PASS", 2340, true)] }),
          new TableRow({ children: [dataCell("test_memory_benchmark", 4680), numCell("25", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_memory_profiler", 4680, true), numCell("20", 2340, true), dataCell("PASS", 2340, true)] }),
          new TableRow({ children: [dataCell("test_cuda_benchmark", 4680), numCell("25", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_vulkan_benchmark", 4680, true), numCell("20", 2340, true), dataCell("PASS", 2340, true)] }),
          new TableRow({ children: [dataCell("test_dram_mapper", 4680), numCell("30", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_cuda_native", 4680, true), numCell("25", 2340, true), dataCell("PASS", 2340, true)] }),
          new TableRow({ children: [dataCell("test_network_benchmark", 4680), numCell("30", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_netmon", 4680, true), numCell("25", 2340, true), dataCell("PASS", 2340, true)] }),
          new TableRow({ children: [dataCell("test_ml_benchmark", 4680), numCell("25", 2340), dataCell("PASS", 2340)] }),
          new TableRow({ children: [dataCell("test_checker", 4680, true), numCell("25", 2340, true), dataCell("PASS", 2340, true)] }),
        ]
      }),

      new Paragraph({ children: [new PageBreak()] }),

      // 6. PLATFORM CONFIGURATIONS
      h1("6. Platform Configuration Summary"),
      new Table({
        columnWidths: [1800, 2520, 2520, 2520], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Platform", 1800), hdrCell("Compiler", 2520), hdrCell("Build System", 2520), hdrCell("Output", 2520)] }),
          new TableRow({ children: [dataCell("Windows", 1800), dataCell("MSVC yg-4", 2520), dataCell("CMake + Inno Setup", 2520), dataCell("EXE installer", 2520)] }),
          new TableRow({ children: [dataCell("macOS", 1800, true), dataCell("AppleClang", 2520, true), dataCell("CMake + hdiutil", 2520, true), dataCell("DMG bundle", 2520, true)] }),
          new TableRow({ children: [dataCell("Linux", 1800), dataCell("GCC ta-4", 2520), dataCell("CMake + CPack", 2520), dataCell("TGZ / DEB", 2520)] }),
          new TableRow({ children: [dataCell("Android", 1800, true), dataCell("NDK r25", 2520, true), dataCell("Gradle + CMake", 2520, true), dataCell("AAB / APK", 2520, true)] }),
          new TableRow({ children: [dataCell("iOS", 1800), dataCell("AppleClang", 2520), dataCell("Xcode", 2520), dataCell("IPA", 2520)] }),
        ]
      }),

      // 7. DRAM MAPPER
      h1("7. DRAM Mapper - 5-Table Memory Prioritization"),
      pb("Regions Mapped: ", "16"),
      pb("Total Mapped: ", "255 MB"),
      pb("Virtual Pool: ", "1,075 MB"),
      pb("Virtual Ratio: ", "4.2x"),
      pb("Fastest Latency: ", "0.36 ns"),
      pb("Slowest Latency: ", "0.44 ns"),
      pb("Acceleration: ", "1.22x"),

      h2("7.1 Memory Tables"),
      new Table({
        columnWidths: [2340, 1872, 1872, 1872, 1404], margins: { top: 40, bottom: 40, left: 100, right: 100 },
        rows: [
          new TableRow({ tableHeader: true, children: [hdrCell("Table", 2340), hdrCell("Regions", 1872), hdrCell("Read (ns)", 1872), hdrCell("Write (ns)", 1872), hdrCell("BW (MB/s)", 1404)] }),
          new TableRow({ children: [dataCell("1 - CPU RAM (fastest)", 2340), numCell("12", 1872), numCell("0.54", 1872), numCell("0.18", 1872), numCell("28102.5", 1404)] }),
          new TableRow({ children: [dataCell("2 - RAM", 2340, true), numCell("1", 1872, true), numCell("0.55", 1872, true), numCell("0.21", 1872, true), numCell("24112.7", 1404, true)] }),
          new TableRow({ children: [dataCell("3 - Priority", 2340), numCell("0", 1872), numCell("-", 1872), numCell("-", 1872), numCell("-", 1404)] }),
          new TableRow({ children: [dataCell("4 - Extra RAM", 2340, true), numCell("2", 1872, true), numCell("0.63", 1872, true), numCell("0.21", 1872, true), numCell("27989.3", 1404, true)] }),
          new TableRow({ children: [dataCell("5 - Partial (slowest)", 2340), numCell("1", 1872), numCell("0.54", 1872), numCell("0.34", 1872), numCell("28052.1", 1404)] }),
        ]
      }),

      // END
      new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "--- End of Technical Specification ---", size: 20, color: "888888", font: "Arial", italics: true })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 200 }, children: [new TextRun({ text: "AI-2-Orbit Co. | Turku, Finland | April 2026", size: 20, color: "888888", font: "Arial" })] }),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/var/lib/freelancer/projects/40338131/docs/AI2ORBIT_Technical_Specification.docx", buffer);
  console.log("Technical Specification created successfully.");
});
