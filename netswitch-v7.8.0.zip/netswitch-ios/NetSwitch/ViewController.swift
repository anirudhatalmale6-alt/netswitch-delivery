// NetSwitch AI Rerouter - iOS
// Copyright AI2ORBIT Co. 2026

import UIKit
import WebKit
import CoreTelephony
import SystemConfiguration

class ViewController: UIViewController, WKScriptMessageHandler {

    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        let config = WKWebViewConfiguration()
        let controller = WKUserContentController()
        controller.add(self, name: "netswitch")
        config.userContentController = controller
        config.preferences.javaScriptEnabled = true

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(webView)

        if let htmlPath = Bundle.main.path(forResource: "index", ofType: "html", inDirectory: "web") {
            let url = URL(fileURLWithPath: htmlPath)
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }

        injectNetworkData()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "netswitch", let body = message.body as? String {
            if body == "getNetworkData" {
                injectNetworkData()
            }
        }
    }

    private func injectNetworkData() {
        let carrier = getCarrierName()
        let connType = getConnectionType()
        let ip = getIPAddress()
        let device = UIDevice.current
        let timestamp = formatTimestamp()

        let js = """
        if (typeof RT !== 'undefined') {
            RT.sourceAddr = '\(carrier) [\(ip)]';
            var pipe = {
                id: 'IOS-\(String(format: "%03d", Int.random(in: 0...999)))',
                timestamp: '\(timestamp)',
                geo: '\(carrier) (\(device.model)) [\(ip)]',
                target: 'NETWORK', ip: '\(ip)',
                location: '\(connType) / iOS \(device.systemVersion)',
                routes: [{
                    carrier: '\(carrier)', teleop: '-',
                    conn: '\(connType)', sw: '\(device.model)',
                    router: '\(ip)', time: '-'
                }],
                status: 'active'
            };
            RT.pipes = [pipe];
            RT.renderPipeListing();
        }
        """
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    private func getCarrierName() -> String {
        let info = CTTelephonyNetworkInfo()
        if let carriers = info.serviceSubscriberCellularProviders {
            for (_, carrier) in carriers {
                if let name = carrier.carrierName { return name }
            }
        }
        return "Unknown"
    }

    private func getConnectionType() -> String {
        let info = CTTelephonyNetworkInfo()
        if let tech = info.serviceCurrentRadioAccessTechnology?.values.first {
            switch tech {
            case CTRadioAccessTechnologyLTE: return "4G LTE"
            case CTRadioAccessTechnologyNR, CTRadioAccessTechnologyNRNSA: return "5G NR"
            case CTRadioAccessTechnologyWCDMA, CTRadioAccessTechnologyHSDPA: return "3G HSPA"
            case CTRadioAccessTechnologyEdge: return "2G EDGE"
            default: return "MOBILE"
            }
        }
        return "WIFI"
    }

    private func getIPAddress() -> String {
        var address = "0.0.0.0"
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr else { return address }
        for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
            let flags = Int32(ptr.pointee.ifa_flags)
            let addr = ptr.pointee.ifa_addr.pointee
            if addr.sa_family == UInt8(AF_INET) && (flags & (IFF_UP | IFF_RUNNING)) != 0 {
                var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                if getnameinfo(ptr.pointee.ifa_addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                    let ip = String(cString: hostname)
                    if ip != "127.0.0.1" { address = ip; break }
                }
            }
        }
        freeifaddrs(ifaddr)
        return address
    }

    private func formatTimestamp() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "dd.MM.yyyy HH.mm:ss"
        return fmt.string(from: Date()) + " EEST"
    }

    override var prefersStatusBarHidden: Bool { false }
    override var preferredStatusBarStyle: UIStatusBarStyle { .darkContent }
}
