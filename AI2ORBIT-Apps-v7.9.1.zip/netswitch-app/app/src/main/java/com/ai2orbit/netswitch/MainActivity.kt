package com.ai2orbit.netswitch

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        setupWebView()

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.READ_PHONE_STATE), 100)
        }

        webView.loadUrl("file:///android_asset/web/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NetSwitchBridge(this), "NetSwitchBridge")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}

class NetSwitchBridge(private val context: Context) {

    @JavascriptInterface
    fun getNetworkData(): String {
        val json = JSONObject()
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

            json.put("carrier", tm.networkOperatorName ?: "Unknown")
            json.put("carrierId", tm.networkOperator ?: "")
            json.put("simOperator", tm.simOperatorName ?: "Unknown")

            val nc = cm.getNetworkCapabilities(cm.activeNetwork)
            val connType = when {
                nc == null -> "NONE"
                nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
                nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getCellType(tm)
                nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
                else -> "OTHER"
            }
            json.put("connectionType", connType)

            val ip = getLocalIpAddress()
            json.put("ipAddress", ip)
            json.put("deviceModel", Build.MODEL)
            json.put("deviceBrand", Build.MANUFACTURER)
            json.put("androidVersion", Build.VERSION.RELEASE)
            json.put("sdkVersion", Build.VERSION.SDK_INT)

            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiInfo = wm.connectionInfo
            if (wifiInfo != null) {
                json.put("wifiSSID", wifiInfo.ssid?.replace("\"", "") ?: "")
                json.put("wifiBSSID", wifiInfo.bssid ?: "")
                json.put("wifiSignal", wifiInfo.rssi)
                json.put("wifiSpeed", wifiInfo.linkSpeed)
                json.put("wifiFrequency", wifiInfo.frequency)
            }

            json.put("timestamp", SimpleDateFormat("dd.MM.yyyy HH.mm:ss", Locale.getDefault())
                .format(Date()) + " " + TimeZone.getDefault().getDisplayName(false, TimeZone.SHORT))

        } catch (e: Exception) {
            json.put("error", e.message)
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getInterfaceData(): String {
        val arr = JSONArray()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp) continue
                val obj = JSONObject()
                obj.put("name", iface.name)
                obj.put("displayName", iface.displayName)
                obj.put("mtu", iface.mtu)
                obj.put("isLoopback", iface.isLoopback)
                obj.put("isVirtual", iface.isVirtual)
                val addrs = JSONArray()
                iface.inetAddresses?.let {
                    while (it.hasMoreElements()) {
                        addrs.put(it.nextElement().hostAddress)
                    }
                }
                obj.put("addresses", addrs)
                arr.put(obj)
            }
        } catch (_: Exception) {}
        return arr.toString()
    }

    @JavascriptInterface
    fun getPasNumber(): String {
        return "PAS-" + Build.SERIAL.takeLast(8).uppercase()
    }

    @JavascriptInterface
    fun getAppVersion(): String = "2.0.0"

    private fun getCellType(tm: TelephonyManager): String {
        return when (tm.dataNetworkType) {
            TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
            TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
            TelephonyManager.NETWORK_TYPE_HSDPA,
            TelephonyManager.NETWORK_TYPE_HSUPA,
            TelephonyManager.NETWORK_TYPE_HSPA -> "3G HSPA"
            TelephonyManager.NETWORK_TYPE_UMTS -> "3G UMTS"
            TelephonyManager.NETWORK_TYPE_EDGE -> "2G EDGE"
            TelephonyManager.NETWORK_TYPE_GPRS -> "2G GPRS"
            else -> "MOBILE"
        }
    }

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is InetAddress &&
                        addr.hostAddress?.contains('.') == true) {
                        return addr.hostAddress ?: "0.0.0.0"
                    }
                }
            }
        } catch (_: Exception) {}
        return "0.0.0.0"
    }
}
