// NetSwitch Routing Tester v1.2
// AI2ORBIT Co. 2026 - Windows Desktop
// Origin: Royal Observatory Greenwich, London
// Stacey-Reynolds Modified for Mobile (5th Punch)

const RT = {
    running: false,
    currentSection: -1,
    elapsed: 0,
    startTime: 0,
    interval: null,
    results: [],

    // Greenwich origin (Prime Meridian)
    origin: { name: 'Greenwich, London', lat: 51.4769, lng: -0.0005 },

    // End device (customer CPE) - Arista 7050T-52
    endDevice: {
        model: 'Arista 7050T-52',
        type: 'Layer 3 Switch',
        ports: { rj45: 48, sfp: 4, speedGbps: 10 },
        totalPorts: 52,
        powerSupply: 'Dual',
        license: 'Permanent',
        protocols: ['OSPF', 'BGP', 'EIGRP', 'RIP', 'Static'],
        pushConstant: 'BenchmarkAIConstant',
        formula: '5Bunch+1 + StaceyReynolds'
    },

    // Enterprise storage (backend) - IBM Storwize V7000 G2
    enterpriseStorage: {
        model: 'IBM Storwize V7000 G2',
        array: 'Control Array 2076-624',
        type: 'Enterprise Storage',
        controllers: { count: 2, processor: 'Intel Xeon', cacheGB: 256 },
        connectivity: ['8Gb Fibre Channel', '16Gb Fibre Channel', '10Gb iSCSI'],
        maxCapacity: '1 PB',
        maxDrives: 480,
        driveTypes: ['2.5" SAS', '3.5" SAS', 'NL-SAS', 'SSD', 'HDD'],
        raidLevels: [0, 1, 3, 5, 6, 10],
        features: ['Easy Tier', 'Thin Provisioning', 'FlashCopy', 'Metro Mirror', 'Global Mirror'],
        power: 'Redundant Hot-Swap',
        battery: 'Dual Redundant'
    },

    // Transport layer hierarchy (light → copper → wireless)
    transportLayers: [
        { name: 'Fiber Optic (Light)', type: 'light',    speed: 'c * 0.67', latency: 'Lowest', color: '#06b6d4', order: 1 },
        { name: 'Copper Wire',         type: 'copper',   speed: 'c * 0.64', latency: 'Medium', color: '#f59e0b', order: 2 },
        { name: 'Wireless (RF)',       type: 'wireless', speed: 'c * 0.99', latency: 'Variable', color: '#8b5cf6', order: 3 }
    ],

    // Timing constants (from raw spec)
    timingConst: { zero: 10000, oneSec: 1e11, t65k: 1.25, half: 1e8 },

    // Status indicators (3 zeros=running, 2=waiting, 1=idle, none=not equipped)
    statusCodes: [
        { code: '000', label: 'RUNNING', color: '#10b981' },
        { code: '00',  label: 'WAITING', color: '#f59e0b' },
        { code: '0',   label: 'IDLE',    color: '#6b7fa0' },
        { code: '-',   label: 'NOT EQUIPPED', color: '#ef4444' }
    ],

    // Train tracks model (50 stops, 75 of 11 tracks)
    trainTracks: { stops: 50, trackCount: 11, sequence: [1.1, 1, 1, 5, 5, 6, 5, 6, 5] },

    // Tubing values
    tubing: { forward: [50, 55, 50, 60, 69, 60], cross: 84, crossVals: [84, 83.75, 77] },

    // Base shell
    baseShell: { vals: [1.77, 5.77, 5.75] },

    // Staciness range (Cambrian = highest, Stainy = lowest)
    staciness: { cambrian: 'MAX', stainy: 'MIN' },

    // Carrier use cases
    carriers: [
        { name: 'AT&T',             region: 'US',  type: 'copper' },
        { name: 'France Telecom',   region: 'EU',  type: 'light' },
        { name: 'Deutsche Welle',   region: 'EU',  type: 'light' },
        { name: 'BT (Portsmouth)',  region: 'UK',  type: 'copper' },
        { name: 'BBC (Bermuda)',    region: 'ATL', type: 'light' }
    ],

    // 9 data path sections (source → target)
    sections: [
        { id: 1, name: 'Source Origin',       desc: 'Application layer packet generation at source host',         distMi: 0,      status: 'idle', timeMs: 0 },
        { id: 2, name: 'Local Network Egress', desc: 'LAN traversal from host NIC to default gateway (switch/AP)', distMi: 0.001,  status: 'idle', timeMs: 0 },
        { id: 3, name: 'ISP Uplink',          desc: 'Gateway to ISP backbone via DSLAM/OLT/cell tower',           distMi: 3.1,    status: 'idle', timeMs: 0 },
        { id: 4, name: 'Backbone Transit',    desc: 'ISP core network to transit provider peering point',          distMi: 124.3,  status: 'idle', timeMs: 0 },
        { id: 5, name: 'Peering Exchange',    desc: 'Internet Exchange Point (IXP) crossing - LINX London',        distMi: 0.05,   status: 'idle', timeMs: 0 },
        { id: 6, name: 'Transit Backbone',    desc: 'Tier-1 transit provider long-haul fiber route',               distMi: 3452.7, status: 'idle', timeMs: 0 },
        { id: 7, name: 'Destination ISP',     desc: 'Transit handoff to destination ISP backbone',                 distMi: 87.6,   status: 'idle', timeMs: 0 },
        { id: 8, name: 'Last Mile Ingress',   desc: 'ISP last mile to destination gateway (FTTP/5G/cable)',        distMi: 2.4,    status: 'idle', timeMs: 0 },
        { id: 9, name: 'Target Delivery',     desc: 'Gateway to target host application layer delivery',           distMi: 0.001,  status: 'idle', timeMs: 0 }
    ],

    // Target endpoints (distances from Greenwich in miles)
    targets: [
        { name: 'New York',      lat: 40.7128,  lng: -74.0060, color: '#ef4444' },
        { name: 'San Francisco', lat: 37.7749,  lng: -122.4194, color: '#f97316' },
        { name: 'Frankfurt',     lat: 50.1109,  lng: 8.6821,   color: '#f59e0b' },
        { name: 'Helsinki',      lat: 60.1699,  lng: 24.9384,  color: '#3b82f6' },
        { name: 'Tokyo',         lat: 35.6762,  lng: 139.6503, color: '#8b5cf6' },
        { name: 'Singapore',     lat: 1.3521,   lng: 103.8198, color: '#ec4899' },
        { name: 'Sydney',        lat: -33.8688, lng: 151.2093, color: '#06b6d4' },
        { name: 'Dubai',         lat: 25.2048,  lng: 55.2708,  color: '#10b981' }
    ],

    // Haversine distance in miles
    haversineMi(lat1, lng1, lat2, lng2) {
        const R = 3958.8; // Earth radius in miles
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    },

    // Stacey-Reynolds Modified for Mobile (5th Punch)
    // 9-phase time weights (from audio spec)
    phaseWeights: [1.0, 0.25, 0.25, 0.5, 0.5, 1.0, 0.1, 0.0625, 0.0078125],
    // Parity bit placement: short/opposing/great/back
    parityBits: ['short', 'opposing', 'great', 'back'],
    // SR constants (imperial)
    srConst: { left: 0.4755, right: 0.855, exp: 1.00077757575755557 },
    // Diagnostic commands
    diagnostics: ['ping', 'traceroute', 'inv-traceroute', 'netstat', 'netstat-stata', 'netstat-over'],

    // Data tracing math (split/derivate)
    tracing: {
        splitParts: 12, // 11+1
        kilobits: 75, // bytes
        dataParts: 14, // parts change first bit 8→7→6
        octet: [4, 9, 4, 4, 4],
        kbLog: [
            'Kb 200 log 8,8,8 100 log 8,8,8,787 IPADDRESS Log 8,8,7/,8,7/ 1,8IPADDRESS',
            'Kb 200 log sin·coscos [TIME0] 8,8,8 100 sin·coscos [TIME1] log 8,8,8',
            'sin·coscos [TIME8] Log 8,8,7/,8,7/IPADDRESS [8] 8 8 8 8 8'
        ],
        hexFormat: [7, 25], // hexa 7 tai hexa 25
        ipSplit: { subnet: [25, 8, 7], slipPct: [1.4, 1.7, 1.8, 1.9],
            splitValues: [107, 117, 55, 57], bittioctet: '8 -7', seq: [1, 2, 5, 2, 1],
            tavuParts: 50000 // 1 tavu (byte) = 50,000 small parts
        },
        portTiming: [
            '1. time to leave port d\'x',
            '2. derivate d\'x',
            '3. derivate 6 and 0.00717%'
        ],
        derivate: { base: 6, pct: 0.00717,
            cascade: [0.00000009, 0.000000000002, 0.000000000, 0.00000000, 0.0000000001],
            untilLast: true
        },
        slipCompare: 'measures ms from this end to target ip, then slips in to 12 parts even and compare the real to reference',
        signalSlip: '25 octet parts of 5 — slip all signal data of 1/5 samples for each',
        splitPct: 51.4,
        octetParts: 25,
        sampleRate: 5, // 25/5 take 5th
        example: {
            target: 'yle.fi', latency: '1ms',
            out: 0.4998850000000000,
            in: 0.5000000101044201
        },
        routeExample: ['Gothenburg', 'Gotland', 'Germany', 'Hamburg', 'Rotterdam Pier',
            'Esbjerg', 'Fredrikshafen', 'Gothenburg', 'Stockholm Nord', 'Stockholm South',
            'Stockholm Sweden', 'Mariehamn', 'Helsinki']
    },

    // Source address (phone location)
    sourceAddr: 'Vitikka4, Friisilä Espoo [112,761,12,113]',

    // Pipe listing data (traffic in use by client app)
    pipes: [
        {
            id: '0001-000', timestamp: '', geo: '', ip: '', location: '',
            routes: [],
            status: 'empty'
        },
        {
            id: '0002-00', timestamp: '25.06.2026 08.59:12 pm. EEST',
            geo: 'Vitikka4, Friisilä Espoo [112,761,12,113]', ip: '142.54.6.112', target: 'BBC.CO.UK',
            location: 'London, E141AA, UK',
            routes: [
                { carrier: 'VODAFONE UK', teleop: 'UK VOD1', conn: '4G T2', sw: 'ASPIR035-561', router: '52654-ET.100.001.123.12', time: '7ms' },
                { carrier: 'VIRGINMEDIA UK', teleop: 'UK VVEDM1', conn: '5G-FIXED T2', sw: '4353EE-561', router: '2654-567.502.001.123.12', time: '1ms' },
                { carrier: 'EE UK', teleop: 'UK EE3431', conn: 'T1 T2', sw: '7876VM-665', router: '11654-001.200.001.123.12', time: '3ms' }
            ],
            status: 'active'
        },
        {
            id: '', timestamp: '24.06.2026 00.00:00 pm. EEST',
            geo: '', ip: '', location: '', routes: [],
            clickToSee: true, status: 'collapsed'
        },
        {
            id: '0003-000', timestamp: '23.06.2026 12.02:01 pm. EEST',
            geo: 'Vitikka4, Friisilä Espoo [112,761,12,113]', ip: '242.14.16.142', target: 'Barclays.co.uk',
            location: 'London, SW1 1BB, UK', routes: [],
            status: 'empty'
        }
    ],

    // SR Modified Mobile compute (5th Punch formula)
    srCompute(P, distMi, f, theta, t) {
        const rad = theta * Math.PI / 180;
        const sinT = Math.sin(rad);
        const cosT = Math.cos(rad);
        // LoS input (imperial)
        const los = P / Math.max(distMi, 1e-6) / f / sinT / Math.max(t, 0.001);
        // Phase 1: sin-sin-cos chain with log timing
        const ssc = sinT * sinT * cosT * sinT * sinT * sinT * sinT;
        const logTiming = Math.log(Math.max(Math.abs(t), 1e-12));
        const phase1 = ssc * logTiming;
        // Phase 2: hyper-hypo-5 (hyperbolic)
        const hyper5 = Math.sinh(5 * cosT) * Math.cosh(5 * sinT);
        const phase2 = hyper5 * Math.log(Math.abs(cosT) + 1e-12);
        // Phase 3: cos-cos-co (triple cosine without final sin)
        const phase3 = cosT * cosT * Math.cos(rad * 0.5);
        // Phase 4: sin-sin-sin
        const phase4 = sinT * sinT * sinT;
        // Phase 5: sin-sin-5-sin (fiver on acid)
        const phase5 = sinT * sinT * 5 * sinT;
        // Phase 6: cos-cos with 110/10 over 9/3 = log(9/3) / log(1110)
        const phase6 = cosT * cosT * (Math.log(9 / 3) / Math.log(1110));
        // Combine: SR transform with left/right constants
        const srRaw = (phase1 + phase2 + phase3) * this.srConst.left +
                      (phase4 + phase5 + phase6) * this.srConst.right;
        // Apply exponent constant and multipliers (35x log, 55x sin, 105x cos)
        const srMult = 35 * Math.log(Math.abs(srRaw) + 1e-12) +
                       55 * sinT + 105 * cosT;
        const sr = srRaw * Math.pow(this.srConst.exp, srMult);
        // LoI: intrusion output (imperial, BHP-scaled)
        const bhp = Math.abs(sr) * 1e4 * (distMi / f);
        const loi = bhp / Math.pow(Math.abs(sinT), theta / 75);
        // IC: normalized intrusion coefficient
        const ic = (50 / 100 / 30000) * sinT * Math.abs(sr) / (75 / 300 / 500 / 30 / 30000);
        // Arcus correction: -arccos(cos5*cos5*cos) - arccos(5*cos5*cos*cos*cos*cos)
        const arcCorr = -Math.acos(Math.max(-1, Math.min(1, cosT * cosT * 0.5))) -
                        Math.acos(Math.max(-1, Math.min(1, 0.5 * cosT * cosT * cosT)));
        const loiCorrected = loi * Math.pow(this.srConst.exp, arcCorr / (1 / 0.05));
        return { los, sr, loi: loiCorrected, ic, phase1, phase2, phase3, phase4, phase5, phase6, bhp, arcCorr };
    },

    // 9-phase SR with individual timings inserted
    srNinePhase(sectionTimings) {
        const results = [];
        let cumulative = 0;
        for (let i = 0; i < 9; i++) {
            const t = (sectionTimings[i] || 0.1) / 1000; // ms to seconds
            const w = this.phaseWeights[i];
            const weightedT = t * w;
            cumulative += weightedT;
            const r = this.srCompute(50, Math.max(this.sections[i].distMi, 0.001), 30000, 75, weightedT);
            results.push({ section: i + 1, time: t, weight: w, weightedT, sr: r.sr, loi: r.loi, bhp: r.bhp });
        }
        // Path coefficient: sum of weighted SR / total
        const totalSR = results.reduce((a, r) => a + Math.abs(r.sr), 0);
        const pathCoeff = totalSR / Math.max(cumulative, 1e-12);
        return { results, pathCoeff, totalSR, cumulative };
    },

    // Route table data (routes with dot colors, like train departure board)
    routes: [
        { name: 'Greenwich-NYC',     dotColor: 'red',    target: 'New York',      active: true },
        { name: 'Greenwich-SFO',     dotColor: 'green',  target: 'San Francisco', active: true },
        { name: 'Greenwich-FRA',     dotColor: 'yellow', target: 'Frankfurt',     active: true },
        { name: 'Greenwich-HEL',     dotColor: 'blue',   target: 'Helsinki',      active: true },
        { name: 'Greenwich-TYO',     dotColor: 'purple', target: 'Tokyo',         active: true },
        { name: 'Greenwich-SIN',     dotColor: 'pink',   target: 'Singapore',     active: false },
        { name: 'Greenwich-SYD',     dotColor: 'cyan',   target: 'Sydney',        active: false },
        { name: 'Greenwich-DXB',     dotColor: 'green',  target: 'Dubai',         active: false }
    ],

    init() {
        this.renderPathVisual();
        this.renderRoutingTable();
        this.renderSections();
        this.renderTargets();
        this.renderResults();
        this.renderTransportLayers();
        this.renderStatusIndicators();
        this.renderEndDevice();
        this.renderEnterpriseStorage();
        this.renderDataTracing();
        this.renderUseCases();
        this.renderPipeListing();
        this.drawRouteMap();
    },

    renderDataTracing() {
        const el = document.getElementById('data-tracing');
        if (!el) return;
        const t = this.tracing;
        const routePath = t.routeExample.join(' → ');
        el.innerHTML =
            '<div class="sr-block">' +
                '<div class="formula-block"><div class="formula-title">Split Data of Tracing</div>' +
                '<div class="formula-eq">11+1 = ' + t.splitParts + ' parts | ' + t.kilobits + ' bytes / ' + t.dataParts + ' parts<br>' +
                'First bit: 8 → 7 → 6 after leaving port | Octet ' + t.octet.join(', ') + '</div></div>' +
                '<div class="formula-block"><div class="formula-title">Kilobit Log Sin-Coscos Pattern</div>' +
                '<div class="formula-eq" style="font-size:9px">' + t.kbLog.join('<br>') + '<br>' +
                'Hexa ' + t.hexFormat[0] + ' tai Hexa ' + t.hexFormat[1] + ' format</div></div>' +
            '</div>' +
            '<div class="sr-block" style="margin-top:6px">' +
                '<div class="formula-block"><div class="formula-title">Times Out From Port (3-Step)</div>' +
                '<div class="formula-eq" style="font-size:9px">' + t.portTiming.join('<br>') + '<br>' +
                '→ 0.0000000900% → 0.000000000002 → .. [until last] 0.0000000001<br>' +
                'ms from other end and then slip in return</div></div>' +
                '<div class="formula-block"><div class="formula-title">Signal Slip Comparison</div>' +
                '<div class="formula-eq" style="font-size:9px">' + t.slipCompare + '<br>' +
                t.signalSlip + '</div></div>' +
            '</div>' +
            '<div class="sr-block" style="margin-top:6px">' +
                '<div class="formula-block"><div class="formula-title">' + t.splitPct + '% Split Reference</div>' +
                '<div class="formula-eq">Split ' + t.splitParts + ' parts even, insert same number reversed<br>' +
                'Real number to this reference<br>' +
                t.octetParts + ' octet parts / ' + t.sampleRate + ' = take 5th sample of each</div></div>' +
                '<div class="formula-block"><div class="formula-title">One-Way / Two-Way (' + t.example.target + ' ' + t.example.latency + ')</div>' +
                '<div class="formula-eq">OUT: ' + t.example.out.toFixed(16) + '<br>' +
                'IN:  ' + t.example.in.toFixed(16) + '<br>' +
                'Δ = ' + Math.abs(t.example.in - t.example.out).toFixed(16) + '</div></div>' +
            '</div>' +
            '<div class="sr-block" style="margin-top:6px">' +
                '<div class="formula-block"><div class="formula-title">IP Split Data /' + t.ipSplit.subnet.join(' / ') + '</div>' +
                '<div class="formula-eq">Slip %: ' + t.ipSplit.slipPct.join(', ') + ' of whole bitamount<br>' +
                '4-way split: ' + t.ipSplit.splitValues.join(' / ') + '<br>' +
                'Bittioctet ' + t.ipSplit.bittioctet + ' | Seq ' + t.ipSplit.seq.join(' ') + '<br>' +
                '1 tavu = ' + t.ipSplit.tavuParts.toLocaleString() + ' small parts, multiplies with part</div></div>' +
                '<div class="formula-block"><div class="formula-title">Example Route Path (Helsinki Return)</div>' +
                '<div class="formula-eq" style="font-size:9px">' + routePath + '<br>' +
                'Each hop: time, IP, data, all details | Traffic one way and return<br>' +
                'Visible from phone and on display</div></div>' +
            '</div>';
    },

    renderEndDevice() {
        const el = document.getElementById('end-device');
        if (!el) return;
        const d = this.endDevice;
        // Port grid: 48 RJ45 + 4 SFP+
        let portHtml = '<div class="ed-port-grid">';
        for (let i = 0; i < d.ports.rj45; i++) {
            portHtml += '<div class="ed-port rj45" title="RJ45 ' + (i + 1) + ' (10G)"></div>';
        }
        for (let i = 0; i < d.ports.sfp; i++) {
            portHtml += '<div class="ed-port sfp" title="SFP+ ' + (i + 1) + ' (10G)"></div>';
        }
        portHtml += '</div>';
        // Protocol tags
        const protoHtml = d.protocols.map(p => '<span class="ed-proto-tag">' + p + '</span>').join('');
        // Active routes pushing to device
        const activeRoutes = this.routes.filter(r => r.active).length;
        const pushStatus = activeRoutes > 0 ? 'PUSHING' : 'IDLE';
        const pushColor = activeRoutes > 0 ? 'var(--green)' : 'var(--dim)';
        el.innerHTML =
            '<div class="ed-header">' +
                '<div class="ed-model">' + d.model + '</div>' +
                '<div class="ed-type">' + d.type + '</div>' +
            '</div>' +
            '<div class="ed-specs">' +
                '<div class="ed-spec"><span class="ed-spec-label">RJ45</span><span class="ed-spec-val">' + d.ports.rj45 + ' x ' + d.ports.speedGbps + 'G</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">SFP+</span><span class="ed-spec-val">' + d.ports.sfp + ' x ' + d.ports.speedGbps + 'G</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Total</span><span class="ed-spec-val">' + d.totalPorts + ' ports</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">PSU</span><span class="ed-spec-val">' + d.powerSupply + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">License</span><span class="ed-spec-val">' + d.license + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Routes</span><span class="ed-spec-val">' + activeRoutes + ' active</span></div>' +
            '</div>' +
            portHtml +
            '<div class="ed-protocols">' +
                '<div style="font-size:8px;color:var(--dim);margin-bottom:4px;letter-spacing:0.5px">ROUTING PROTOCOLS</div>' +
                protoHtml +
            '</div>' +
            '<div class="ed-push">' +
                '<div class="ed-push-indicator" style="background:' + pushColor + '"></div>' +
                '<div class="ed-push-label">NetSwitch ' + d.pushConstant + '</div>' +
                '<div class="ed-push-status" style="color:' + pushColor + '">' + pushStatus + '</div>' +
            '</div>' +
            '<div class="ed-formula">' +
                '<span style="color:var(--dim);font-size:9px">Calc: </span>' +
                '<span style="color:var(--cyan);font-size:10px;font-weight:600">' + d.formula + '</span>' +
            '</div>';
    },

    renderPipeListing() {
        const el = document.getElementById('pipe-listing');
        if (!el) return;
        let html = '';
        this.pipes.forEach((pipe, idx) => {
            html += '<div class="pipe-divider"></div>';
            if (pipe.clickToSee) {
                html += '<div class="pipe-entry">' +
                    '<div class="pipe-timestamp">' + pipe.timestamp + '</div>' +
                    '<div class="pipe-click">Click to see traffic</div></div>';
                return;
            }
            if (pipe.status === 'connlines' && pipe.connText) {
                html += '<div class="pipe-entry">' +
                    '<div class="pipe-header-row"><span class="pipe-td-label">Connection Lines</span>' +
                    '<span class="pipe-id">9-Section Path</span></div>' +
                    '<div class="pipe-conn-lines">';
                pipe.connText.forEach(line => {
                    html += '<div class="pipe-conn-line">' + line + '</div>';
                });
                html += '</div></div>';
                return;
            }
            html += '<div class="pipe-entry">';
            if (pipe.timestamp) {
                html += '<div class="pipe-timestamp">' + pipe.timestamp + '</div>';
            }
            html += '<div class="pipe-header-row">';
            html += '<span class="pipe-td-label">Time and Date</span>';
            if (pipe.id) html += '<span class="pipe-id">Pipe [' + pipe.id + ']</span>';
            html += '</div>';
            if (pipe.geo && pipe.target) {
                html += '<div class="pipe-geo">' + pipe.geo + ' >>> ' + pipe.target + ' (' + pipe.ip + ') ' + pipe.location + '</div>';
            }
            // Column headers
            html += '<div class="pipe-col-headers">' +
                '<span class="pipe-col pc-carrier">Carrier</span>' +
                '<span class="pipe-col pc-teleop">Teleoperator</span>' +
                '<span class="pipe-col pc-conn">Connection</span>' +
                '<span class="pipe-col pc-sw">Switch</span>' +
                '<span class="pipe-col pc-router">Router</span>' +
                '<span class="pipe-col pc-time">Time</span></div>';
            // Routes
            if (pipe.routes.length > 0) {
                html += '<div class="pipe-routes">';
                pipe.routes.forEach(r => {
                    html += '<div class="pipe-route-row">' +
                        '<span class="pipe-col pc-carrier">' + r.carrier + '</span>' +
                        '<span class="pipe-col pc-teleop">' + r.teleop + '</span>' +
                        '<span class="pipe-col pc-conn">' + r.conn + '</span>' +
                        '<span class="pipe-col pc-sw">' + r.sw + '</span>' +
                        '<span class="pipe-col pc-router">' + r.router + '</span>' +
                        '<span class="pipe-col pc-time">' + r.time + '</span></div>';
                });
                html += '</div>';
            }
            // Re Shuffle button
            html += '<div class="pipe-reshuffle-wrap">' +
                '<button class="pipe-reshuffle-btn" onclick="RT.reshufflePipe(' + idx + ')">[RETRAFFIC]</button>' +
                '<div class="pipe-reshuffle-desc">Finds new routings<br>for phone residing<br>app in network<br>protocol routing.</div>';
            if (pipe.status === 'active') {
                html += '<span class="pipe-previous">Previous -</span>';
            }
            html += '</div>';
            html += '</div>';
        });
        html += '<div class="pipe-divider"></div>';
        el.innerHTML = html;
    },

    reshufflePipe(idx) {
        const pipe = this.pipes[idx];
        if (!pipe) return;
        const carriers = [
            { carrier: 'VODAFONE UK', teleop: 'UK VOD1', conns: ['4G T2', '5G T3', '3G T1'] },
            { carrier: 'VIRGINMEDIA UK', teleop: 'UK VVEDM1', conns: ['5G-FIXED T2', 'FIBER T3', 'CABLE T2'] },
            { carrier: 'EE UK', teleop: 'UK EE3431', conns: ['T1 T2', '5G T3', '4G T2'] },
            { carrier: 'THREE UK', teleop: 'UK TH3001', conns: ['5G T3', '4G T2', '3G T1'] },
            { carrier: 'O2 UK', teleop: 'UK O2TEL1', conns: ['4G T2', '5G-SA T3', 'LTE T2'] },
            { carrier: 'SKY UK', teleop: 'UK SKY01', conns: ['FIBER T3', 'CABLE T2', 'DSL T1'] }
        ];
        const switches = ['ASPIR035-561', '4353EE-561', '7876VM-665', 'NX9200-442', 'CRS317-881', 'QFX510-223'];
        const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
        const randRouter = () => Math.floor(Math.random() * 65535) + '-' +
            Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 256) +
            '.001.' + Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 100);
        const count = 2 + Math.floor(Math.random() * 3);
        const used = new Set();
        pipe.routes = [];
        for (let i = 0; i < count; i++) {
            let c;
            do { c = pick(carriers); } while (used.has(c.carrier) && used.size < carriers.length);
            used.add(c.carrier);
            pipe.routes.push({
                carrier: c.carrier, teleop: c.teleop,
                conn: pick(c.conns), sw: pick(switches),
                router: randRouter(),
                time: (1 + Math.floor(Math.random() * 12)) + 'ms'
            });
        }
        if (!pipe.timestamp) {
            const now = new Date();
            const d = String(now.getDate()).padStart(2, '0');
            const m = String(now.getMonth() + 1).padStart(2, '0');
            const y = now.getFullYear();
            const h = String(now.getHours()).padStart(2, '0');
            const mi = String(now.getMinutes()).padStart(2, '0');
            const s = String(now.getSeconds()).padStart(2, '0');
            const ampm = now.getHours() >= 12 ? 'pm' : 'am';
            pipe.timestamp = d + '.' + m + '.' + y + ' ' + h + '.' + mi + ':' + s + ' ' + ampm + '. EEST';
        }
        if (!pipe.target) {
            pipe.geo = this.sourceAddr;
            pipe.target = 'RESHUFFLED.NET';
            pipe.ip = '10.' + Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 256);
            pipe.location = 'London, UK';
        }
        pipe.status = 'active';
        this.renderPipeListing();
    },

    renderEnterpriseStorage() {
        const el = document.getElementById('enterprise-storage');
        if (!el) return;
        const s = this.enterpriseStorage;
        // Drive bay grid (show 24 bays as visual)
        let bayHtml = '<div class="es-bay-grid">';
        for (let i = 0; i < 24; i++) {
            const type = i < 12 ? 'ssd' : 'hdd';
            bayHtml += '<div class="es-bay ' + type + '" title="Bay ' + (i + 1) + ' (' + (type === 'ssd' ? 'SSD' : 'HDD') + ')"></div>';
        }
        bayHtml += '</div>';
        // Connectivity tags
        const connHtml = s.connectivity.map(c => '<span class="es-conn-tag">' + c + '</span>').join('');
        // RAID tags
        const raidHtml = s.raidLevels.map(r => '<span class="es-raid-tag">RAID ' + r + '</span>').join('');
        // Feature tags
        const featHtml = s.features.map(f => '<span class="ed-proto-tag">' + f + '</span>').join('');
        el.innerHTML =
            '<div class="es-header">' +
                '<div class="es-model">' + s.model + '</div>' +
                '<div class="es-array">' + s.array + '</div>' +
            '</div>' +
            '<div class="ed-specs">' +
                '<div class="ed-spec"><span class="ed-spec-label">Controllers</span><span class="ed-spec-val">Dual ' + s.controllers.processor + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Cache</span><span class="ed-spec-val">' + s.controllers.cacheGB + ' GB</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Max Capacity</span><span class="ed-spec-val">' + s.maxCapacity + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Max Drives</span><span class="ed-spec-val">' + s.maxDrives + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Power</span><span class="ed-spec-val">' + s.power + '</span></div>' +
                '<div class="ed-spec"><span class="ed-spec-label">Battery</span><span class="ed-spec-val">' + s.battery + '</span></div>' +
            '</div>' +
            bayHtml +
            '<div class="ed-protocols" style="margin-bottom:4px">' +
                '<div style="font-size:8px;color:var(--dim);margin-bottom:4px;letter-spacing:0.5px">HOST CONNECTIVITY</div>' +
                connHtml +
            '</div>' +
            '<div class="ed-protocols" style="margin-bottom:4px">' +
                '<div style="font-size:8px;color:var(--dim);margin-bottom:4px;letter-spacing:0.5px">RAID LEVELS</div>' +
                raidHtml +
            '</div>' +
            '<div class="ed-protocols">' +
                '<div style="font-size:8px;color:var(--dim);margin-bottom:4px;letter-spacing:0.5px">ADVANCED FEATURES</div>' +
                featHtml +
            '</div>';
    },

    renderRoutingTable() {
        const el = document.getElementById('routing-table');
        if (!el) return;
        const secHeaders = this.sections.map(s => s.name.split(' ')[0]);
        let html = '<table class="rt-table"><thead><tr>';
        html += '<th>Route</th>';
        this.sections.forEach((s, i) => {
            html += '<th class="rt-time-col">S' + (i + 1) + '</th>';
        });
        html += '<th>Distance</th></tr></thead><tbody>';
        this.routes.forEach(route => {
            const tgt = this.targets.find(t => t.name === route.target);
            const dist = tgt ? this.haversineMi(this.origin.lat, this.origin.lng, tgt.lat, tgt.lng) : 0;
            html += '<tr class="' + (route.active ? 'rt-active' : '') + '">';
            html += '<td><div class="rt-route-cell"><div class="rt-dot ' + route.dotColor + '"></div><div class="rt-route-name">' + route.name + '</div></div></td>';
            this.sections.forEach(s => {
                if (s.timeMs > 0 && route.active) {
                    const secDist = s.distMi > 0 ? s.distMi : 0;
                    const scaledTime = s.timeMs * (dist / 3670);
                    html += '<td class="rt-time-cell">' + scaledTime.toFixed(2) + '</td>';
                } else if (s.timeMs > 0 && !route.active) {
                    html += '<td class="rt-time-cell empty">--</td>';
                } else {
                    html += '<td class="rt-time-cell empty">-</td>';
                }
            });
            html += '<td class="rt-dist-cell">' + dist.toFixed(0) + ' mi</td>';
            html += '</tr>';
        });
        html += '</tbody></table>';
        el.innerHTML = html;
    },

    reroute() {
        if (this.running) return;
        this.routes.forEach(r => r.active = !r.active);
        this.renderRoutingTable();
        this.renderEndDevice();
        this.drawRouteMap();
        if (this.results.length > 0) {
            this.computeSRTotals();
        }
    },

    renderTransportLayers() {
        const el = document.getElementById('transport-layers');
        if (!el) return;
        el.innerHTML = this.transportLayers.map((t, i) => {
            const width = t.type === 'light' ? 90 : t.type === 'copper' ? 65 : 45;
            return '<div class="tgt-row">' +
                '<div class="tgt-dot" style="background:' + t.color + '"></div>' +
                '<div class="tgt-name">' + t.name + '</div>' +
                '<div style="flex:1;display:flex;align-items:center;gap:4px">' +
                '<div class="sr-vec-bar" style="min-width:30px"><div class="sr-vec-fill" style="width:' + width + '%;background:' + t.color + '"></div></div></div>' +
                '<span class="feat-port-tag">' + t.speed + '</span>' +
                '<span class="feat-port-tag">' + t.latency + '</span>' +
                '<span class="feat-port-tag">P' + t.order + '</span></div>';
        }).join('');
    },

    renderStatusIndicators() {
        const el = document.getElementById('status-indicators');
        if (!el) return;
        el.innerHTML = this.statusCodes.map(s =>
            '<div class="tgt-row">' +
            '<div class="tgt-dot" style="background:' + s.color + '"></div>' +
            '<div class="tgt-name" style="font-family:monospace;letter-spacing:2px">' + s.code + '</div>' +
            '<div style="color:var(--dim);font-size:10px;flex:1">' + s.label + '</div>' +
            '<span class="feat-port-tag" style="background:' + s.color + '20;color:' + s.color + '">' + s.label + '</span></div>'
        ).join('');
    },

    renderUseCases() {
        const el = document.getElementById('use-cases');
        if (!el) return;
        el.innerHTML = this.carriers.map(c => {
            const layerColor = c.type === 'light' ? '#06b6d4' : c.type === 'copper' ? '#f59e0b' : '#8b5cf6';
            return '<div class="tgt-row">' +
                '<div class="tgt-dot" style="background:' + layerColor + '"></div>' +
                '<div class="tgt-name">' + c.name + '</div>' +
                '<div style="color:var(--dim);font-size:9px;flex:1">' + c.region + '</div>' +
                '<span class="feat-port-tag">' + c.type.toUpperCase() + '</span></div>';
        }).join('');
    },

    renderPathVisual() {
        const el = document.getElementById('path-visual');
        if (!el) return;
        let html = '';
        this.sections.forEach((s, i) => {
            html += '<div class="path-node">' +
                '<div class="path-circle ' + s.status + '" id="pc-' + s.id + '">' + s.id + '</div>' +
                '<div class="path-label">' + s.name + '</div></div>';
            if (i < this.sections.length - 1) {
                html += '<div class="path-line" id="pl-' + s.id + '"></div>';
            }
        });
        el.innerHTML = html;
    },

    renderSections() {
        const el = document.getElementById('section-list');
        if (!el) return;
        el.innerHTML = this.sections.map(s => {
            const timeStr = s.timeMs > 0 ? s.timeMs.toFixed(3) + ' ms' : '-';
            const distStr = s.distMi > 0 ? s.distMi.toLocaleString(undefined, { maximumFractionDigits: 3 }) + ' mi' : '0 ft';
            const distFt = s.distMi < 0.01 ? (s.distMi * 5280).toFixed(1) + ' ft' : distStr;
            return '<div class="sec-row ' + s.status + '" id="sr-' + s.id + '">' +
                '<div class="sec-num ' + s.status + '">' + s.id + '</div>' +
                '<div class="sec-name">' + s.name + '</div>' +
                '<div class="sec-desc">' + s.desc + '</div>' +
                '<div class="sec-dist">' + distFt + '</div>' +
                '<div class="sec-time" id="st-' + s.id + '">' + timeStr + '</div>' +
                '<div class="sec-badge ' + s.status + '">' + s.status.toUpperCase() + '</div></div>';
        }).join('');
    },

    renderTargets() {
        const el = document.getElementById('target-list');
        if (!el) return;
        el.innerHTML = this.targets.map(t => {
            const dist = this.haversineMi(this.origin.lat, this.origin.lng, t.lat, t.lng);
            const badgeClass = t.tested ? 'pass' : 'ready';
            const badgeText = t.tested ? 'PASS' : 'READY';
            return '<div class="tgt-row">' +
                '<div class="tgt-dot" style="background:' + t.color + '"></div>' +
                '<div class="tgt-name">' + t.name + '</div>' +
                '<div class="tgt-coord">' + t.lat.toFixed(4) + '°, ' + t.lng.toFixed(4) + '°</div>' +
                '<div class="tgt-dist">' + dist.toFixed(1) + ' mi</div>' +
                '<div class="tgt-badge ' + badgeClass + '">' + badgeText + '</div></div>';
        }).join('');
    },

    renderResults() {
        const el = document.getElementById('results-summary');
        const totEl = document.getElementById('summary-totals');
        if (!el) return;

        if (this.results.length === 0) {
            el.innerHTML = '<div style="text-align:center;color:var(--dim);padding:20px;font-size:11px">Press RUN ALL ROUTING TESTS to begin</div>';
            if (totEl) totEl.innerHTML = '';
            return;
        }

        const totalMs = this.results.reduce((a, r) => a + r.timeMs, 0);
        const maxMs = Math.max(...this.results.map(r => r.timeMs));

        el.innerHTML = this.results.map(r => {
            const pct = (r.timeMs / maxMs) * 100;
            const color = r.timeMs < 1 ? 'var(--green)' : r.timeMs < 10 ? 'var(--cyan)' : r.timeMs < 50 ? 'var(--yellow)' : 'var(--orange)';
            return '<div class="res-row">' +
                '<div class="res-label">' + r.name + '</div>' +
                '<div class="res-val">' + r.timeMs.toFixed(3) + ' ms</div>' +
                '<div class="res-bar"><div class="res-fill" style="width:' + pct + '%;background:' + color + '"></div></div></div>';
        }).join('');

        if (totEl) {
            const totalDist = this.sections.reduce((a, s) => a + s.distMi, 0);
            const srResult = this.srCompute(50, Math.max(totalDist, 0.001), 30000, 75, totalMs / 1000);
            totEl.innerHTML =
                '<div class="sum-box"><div class="sum-label">Total Time</div><div class="sum-val">' + totalMs.toFixed(3) + ' ms</div></div>' +
                '<div class="sum-box"><div class="sum-label">Total Distance</div><div class="sum-val">' + totalDist.toFixed(1) + ' mi</div></div>' +
                '<div class="sum-box"><div class="sum-label">Sections Passed</div><div class="sum-val">' + this.results.length + ' / 9</div></div>';
        }
    },

    drawRouteMap() {
        const canvas = document.getElementById('route-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = '#0a1018';
        ctx.fillRect(0, 0, w, h);

        // Grid
        ctx.strokeStyle = 'rgba(255,255,255,0.03)';
        ctx.lineWidth = 1;
        for (let i = 0; i < 20; i++) {
            ctx.beginPath(); ctx.moveTo(i * w / 20, 0); ctx.lineTo(i * w / 20, h); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i * h / 12); ctx.lineTo(w, i * h / 12); ctx.stroke();
        }

        // Map projection (Mercator-ish)
        const toX = lng => ((lng + 180) / 360) * w;
        const toY = lat => ((90 - lat) / 180) * h;

        // Draw connections from Greenwich to targets
        const ox = toX(this.origin.lng), oy = toY(this.origin.lat);

        this.targets.forEach(t => {
            const tx = toX(t.lng), ty = toY(t.lat);

            // Connection line
            ctx.beginPath();
            ctx.moveTo(ox, oy);
            const cpx = (ox + tx) / 2, cpy = Math.min(oy, ty) - 30;
            ctx.quadraticCurveTo(cpx, cpy, tx, ty);
            ctx.strokeStyle = t.color + (t.tested ? '80' : '30');
            ctx.lineWidth = t.tested ? 2 : 1;
            ctx.stroke();

            // Target node
            ctx.fillStyle = t.color + '20';
            ctx.beginPath(); ctx.arc(tx, ty, 10, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = t.color;
            ctx.beginPath(); ctx.arc(tx, ty, 4, 0, Math.PI * 2); ctx.fill();

            // Label
            ctx.font = '14px monospace';
            ctx.fillStyle = t.color;
            ctx.textAlign = 'center';
            ctx.fillText(t.name, tx, ty + 20);

            // Distance
            const dist = this.haversineMi(this.origin.lat, this.origin.lng, t.lat, t.lng);
            ctx.font = '10px monospace';
            ctx.fillStyle = 'rgba(255,255,255,0.4)';
            ctx.fillText(dist.toFixed(0) + ' mi', tx, ty + 32);
        });

        // Greenwich origin (larger, highlighted)
        ctx.fillStyle = 'rgba(245,158,11,0.15)';
        ctx.beginPath(); ctx.arc(ox, oy, 20, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#f59e0b50';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(ox, oy, 20, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath(); ctx.arc(ox, oy, 6, 0, Math.PI * 2); ctx.fill();
        ctx.font = 'bold 16px monospace';
        ctx.fillStyle = '#f59e0b';
        ctx.textAlign = 'center';
        ctx.fillText('GREENWICH', ox, oy - 26);
        ctx.font = '10px monospace';
        ctx.fillStyle = 'rgba(245,158,11,0.6)';
        ctx.fillText('0° PRIME MERIDIAN', ox, oy - 14);

        // Prime Meridian line
        ctx.strokeStyle = 'rgba(245,158,11,0.1)';
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 6]);
        ctx.beginPath(); ctx.moveTo(ox, 0); ctx.lineTo(ox, h); ctx.stroke();
        ctx.setLineDash([]);
    },

    async runAllTests() {
        if (this.running) return;
        if (!confirm('Run all 9-section routing tests from Greenwich origin?\n\nDiagnostics: ping, traceroute, inv-traceroute, netstat\nFormula: Stacey-Reynolds Modified for Mobile (5th Punch)\nMeasure: Imperial (miles/feet/BHP)\n\nProceed?')) return;
        this.running = true;
        this.results = [];
        this.currentSection = 0;
        this.startTime = performance.now();

        const btn = document.getElementById('btn-run');
        if (btn) { btn.classList.add('running'); btn.textContent = '⏳ TESTING...'; }

        // Reset sections
        this.sections.forEach(s => { s.status = 'idle'; s.timeMs = 0; });
        this.renderPathVisual();
        this.renderRoutingTable();
        this.renderSections();
        this.renderResults();

        // Start elapsed timer
        this.interval = setInterval(() => {
            this.elapsed = (performance.now() - this.startTime) / 1000;
            const el = document.getElementById('t-elapsed');
            if (el) el.textContent = this.elapsed.toFixed(3) + 's';
        }, 50);

        // Run each section sequentially
        for (let i = 0; i < this.sections.length; i++) {
            this.currentSection = i;
            await this.testSection(i);
            const countEl = document.getElementById('t-count');
            if (countEl) countEl.textContent = (i + 1) + ' / 9';
        }

        // Complete
        clearInterval(this.interval);
        this.running = false;
        if (btn) { btn.classList.remove('running'); btn.classList.add('done'); btn.textContent = '✓ COMPLETE'; }

        const stEl = document.getElementById('t-status');
        if (stEl) { stEl.textContent = 'COMPLETE'; stEl.style.color = 'var(--green)'; }

        // Compute SR totals + refresh routing table + populate pipes
        this.computeSRTotals();
        this.populatePipesFromTest();
        this.renderRoutingTable();
        this.drawRouteMap();

        // Reset button after 3s
        setTimeout(() => {
            if (btn) { btn.classList.remove('done'); btn.textContent = '▶ RUN ALL ROUTING TESTS'; }
        }, 3000);
    },

    testSection(idx) {
        return new Promise(resolve => {
            const sec = this.sections[idx];
            sec.status = 'testing';

            // Update UI
            this.updateSectionUI(sec);
            const stEl = document.getElementById('t-status');
            if (stEl) { stEl.textContent = 'SECTION ' + sec.id; stEl.style.color = 'var(--yellow)'; }

            // Simulate timing based on distance (fiber propagation + processing)
            const cMiPerSec = 186282; // speed of light in mi/s
            const fiberFactor = 0.67;
            const propagationMs = (sec.distMi / (cMiPerSec * fiberFactor)) * 1000;
            const processingMs = 0.05 + Math.random() * 0.3; // router/switch processing
            const queuingMs = Math.random() * 0.1;
            const totalMs = propagationMs + processingMs + queuingMs;

            // Animate with delay proportional to simulated time
            const animDelay = Math.max(200, Math.min(800, totalMs * 50 + 150));

            setTimeout(() => {
                sec.status = 'pass';
                sec.timeMs = totalMs;
                this.results.push({ name: sec.name, timeMs: totalMs, distMi: sec.distMi });
                this.updateSectionUI(sec);
                this.renderResults();
                resolve();
            }, animDelay);
        });
    },

    updateSectionUI(sec) {
        // Path circle
        const pc = document.getElementById('pc-' + sec.id);
        if (pc) { pc.className = 'path-circle ' + sec.status; }

        // Path line
        const pl = document.getElementById('pl-' + sec.id);
        if (pl) { pl.className = 'path-line ' + sec.status; }

        // Section row
        const sr = document.getElementById('sr-' + sec.id);
        if (sr) { sr.className = 'sec-row ' + sec.status; }

        // Re-render section list
        this.renderSections();
    },

    computeSRTotals() {
        const totalDist = this.sections.reduce((a, s) => a + s.distMi, 0);
        const totalMs = this.results.reduce((a, r) => a + r.timeMs, 0);
        const timings = this.sections.map(s => s.timeMs);

        // 5th Punch: 9-phase SR with weighted timings
        const ninePhase = this.srNinePhase(timings);
        const r = this.srCompute(50, Math.max(totalDist, 0.001), 30000, 75, Math.max(totalMs / 1000, 0.001));

        const el = (id) => document.getElementById(id);
        if (el('sr-total-los')) el('sr-total-los').textContent = r.los.toExponential(4);
        if (el('sr-total-sr')) el('sr-total-sr').textContent = ninePhase.totalSR.toExponential(4);
        if (el('sr-total-loi')) el('sr-total-loi').textContent = r.loi.toExponential(4);
        if (el('sr-total-pc')) el('sr-total-pc').textContent = ninePhase.pathCoeff.toExponential(4);

        const verdict = r.loi > 1 ? 'HIGH INTRUSION EXPOSURE' : r.loi > 0.01 ? 'MODERATE EXPOSURE' : 'LOW EXPOSURE - ROUTE SECURE';
        const vColor = r.loi > 1 ? 'var(--red)' : r.loi > 0.01 ? 'var(--yellow)' : 'var(--green)';
        if (el('sr-verdict')) {
            el('sr-verdict').textContent = verdict + '  |  LoI = ' + r.loi.toExponential(3) + '  |  BHP = ' + r.bhp.toExponential(3) + '  |  ' + totalDist.toFixed(1) + ' mi';
            el('sr-verdict').style.color = vColor;
        }

        // Render 9-phase breakdown
        this.renderPhaseBreakdown(ninePhase);

        // Mark targets as tested
        this.targets.forEach(t => t.tested = true);
        this.renderTargets();
    },

    renderPhaseBreakdown(ninePhase) {
        const el = document.getElementById('sr-phases');
        if (!el) return;
        const maxSR = Math.max(...ninePhase.results.map(r => Math.abs(r.sr)), 1e-20);
        el.innerHTML = '<div style="font-size:9px;color:var(--dim);margin-bottom:6px">5th Punch: 9-phase weighted SR with sin-cos chain + BHP imperial</div>' +
        ninePhase.results.map(r => {
            const pct = Math.min(100, (Math.abs(r.sr) / maxSR) * 100);
            const color = r.loi > 1 ? 'var(--red)' : r.loi > 0.01 ? 'var(--yellow)' : 'var(--green)';
            return '<div class="sr-vec-row">' +
                '<div class="sr-vec-label">Phase ' + r.section + '</div>' +
                '<div style="color:var(--dim);font-size:9px;min-width:40px">w=' + r.weight + '</div>' +
                '<div class="sr-vec-val">' + r.sr.toExponential(2) + '</div>' +
                '<div class="sr-vec-bar"><div class="sr-vec-fill" style="width:' + pct + '%;background:' + color + '"></div></div>' +
                '<span class="feat-port-tag">' + (r.time * 1000).toFixed(3) + 'ms</span>' +
                '<span class="feat-port-tag">BHP ' + r.bhp.toExponential(1) + '</span></div>';
        }).join('') +
        '<div style="margin-top:6px;font-size:9px;color:var(--dim)">Path Coeff: ' + ninePhase.pathCoeff.toExponential(4) +
        ' | Total SR: ' + ninePhase.totalSR.toExponential(4) +
        ' | Cumulative: ' + (ninePhase.cumulative * 1000).toFixed(3) + 'ms weighted</div>';
    },

    toggleRawView() {
        const el = document.getElementById('pipe-raw');
        if (!el) return;
        if (el.style.display === 'none') {
            el.style.display = 'block';
            this.renderRawView();
        } else {
            el.style.display = 'none';
        }
    },

    renderRawView() {
        const el = document.getElementById('pipe-raw');
        if (!el) return;
        const sep = '----------------------------------------------------------------------------------------------------------------------';
        let raw = 'User interface\n\nStart Pipes End\n\nResults\n\n';
        raw += 'Search engine type of interface to list earlier listing from the button and results available.\n\n';
        raw += 'Approve Yes No No returns to earlier listing. Yes stays with this listing.\n\n';
        raw += 'Insert phone id to list items from phone.\n\n';
        raw += 'Air and landlines Kpbs 00.000,00    T1 - T2 - T3 speeds.\n\n';
        raw += 'Estimated I    P    U\n\n';
        raw += '[       ] Search\n\n';
        this.pipes.forEach(pipe => {
            raw += sep + '\n';
            if (pipe.clickToSee) {
                raw += pipe.timestamp + '          Click to see traffic\n';
                return;
            }
            if (pipe.status === 'connlines') return;
            if (pipe.timestamp) raw += pipe.timestamp + '\n';
            raw += 'Time and Date       Pipe [' + (pipe.id || '????-???') + ']\n';
            if (pipe.geo && pipe.target) {
                raw += '       ' + pipe.geo + ' >>> ' + pipe.target + ' (' + pipe.ip + ') ' + pipe.location + '\n';
            }
            raw += '\n';
            raw += '       Carrier              Teleoperator       Connection       Switch           Router                         Time\n\n';
            if (pipe.routes.length > 0) {
                pipe.routes.forEach(r => {
                    const pad = (s, w) => (s + ' '.repeat(w)).slice(0, w);
                    raw += '[RETRAFFIC]  ' + pad(r.carrier, 20) + pad(r.teleop, 19) + pad(r.conn, 17) + pad(r.sw, 17) + pad(r.router, 31) + r.time + '\n';
                });
                raw += '\nFinds new routings\nfor phone residing\napp in network\nprotocol routing.       Previous -\n';
            } else {
                raw += '[RETRAFFIC]\nFinds new routings\nfor phone residing\napp in network\nprotocol routing.\n';
            }
            raw += '\n';
        });
        raw += sep + '\n';
        el.textContent = raw;
    },

    downloadCSV() {
        let csv = 'Timestamp,Pipe,Source,Target,IP,Location,Carrier,Teleoperator,Connection,Switch,Router,Time\n';
        this.pipes.forEach(pipe => {
            if (pipe.clickToSee || pipe.status === 'connlines') return;
            if (pipe.routes.length > 0) {
                pipe.routes.forEach(r => {
                    csv += '"' + (pipe.timestamp || '') + '","' + (pipe.id || '') + '","' +
                        (pipe.geo || '') + '","' + (pipe.target || '') + '","' +
                        (pipe.ip || '') + '","' + (pipe.location || '') + '","' +
                        r.carrier + '","' + r.teleop + '","' + r.conn + '","' +
                        r.sw + '","' + r.router + '","' + r.time + '"\n';
                });
            } else {
                csv += '"' + (pipe.timestamp || '') + '","' + (pipe.id || '') + '","' +
                    (pipe.geo || '') + '","' + (pipe.target || '') + '","' +
                    (pipe.ip || '') + '","' + (pipe.location || '') + '","","","","","",""\n';
            }
        });
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'netswitch-traffic-' + new Date().toISOString().slice(0, 10) + '.csv';
        a.click();
        URL.revokeObjectURL(url);
    },

    populatePipesFromTest() {
        const activeRoutes = this.routes.filter(r => r.active);
        const carriers = [
            { carrier: 'VODAFONE UK', teleop: 'UK VOD1' },
            { carrier: 'VIRGINMEDIA UK', teleop: 'UK VVEDM1' },
            { carrier: 'EE UK', teleop: 'UK EE3431' },
            { carrier: 'THREE UK', teleop: 'UK TH3001' },
            { carrier: 'O2 UK', teleop: 'UK O2TEL1' },
            { carrier: 'SKY UK', teleop: 'UK SKY01' }
        ];
        const connTypes = ['4G T2', '5G T3', '5G-FIXED T2', 'T1 T2', 'FIBER T3', 'LTE T2', '3G T1'];
        const switches = ['ASPIR035-561', '4353EE-561', '7876VM-665', 'NX9200-442', 'CRS317-881', 'QFX510-223'];
        const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
        const randRouter = () => Math.floor(Math.random() * 65535) + '-' +
            Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 256) +
            '.001.' + Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 100);
        const now = new Date();
        const pad = (n) => String(n).padStart(2, '0');
        const ts = pad(now.getDate()) + '.' + pad(now.getMonth() + 1) + '.' + now.getFullYear() + ' ' +
            pad(now.getHours()) + '.' + pad(now.getMinutes()) + ':' + pad(now.getSeconds()) + ' ' +
            (now.getHours() >= 12 ? 'pm' : 'am') + '. EEST';

        this.pipes = [];
        activeRoutes.forEach((route, idx) => {
            const tgt = this.targets.find(t => t.name === route.target);
            const dist = tgt ? this.haversineMi(this.origin.lat, this.origin.lng, tgt.lat, tgt.lng) : 0;
            const ip = Math.floor(Math.random() * 200 + 10) + '.' + Math.floor(Math.random() * 256) + '.' +
                Math.floor(Math.random() * 256) + '.' + Math.floor(Math.random() * 256);
            const routeCount = 2 + Math.floor(Math.random() * 3);
            const routes = [];
            const used = new Set();
            for (let i = 0; i < routeCount; i++) {
                let c;
                do { c = pick(carriers); } while (used.has(c.carrier) && used.size < carriers.length);
                used.add(c.carrier);
                const secTime = this.sections[Math.min(i + 2, 8)].timeMs;
                routes.push({
                    carrier: c.carrier, teleop: c.teleop,
                    conn: pick(connTypes), sw: pick(switches),
                    router: randRouter(),
                    time: (secTime > 0 ? secTime.toFixed(0) : (1 + Math.floor(Math.random() * 9))) + 'ms'
                });
            }
            const pipeNum = String(idx + 1).padStart(4, '0') + '-' + String(Math.floor(dist) % 1000).padStart(3, '0');
            this.pipes.push({
                id: pipeNum, timestamp: ts,
                geo: this.sourceAddr, target: route.target.toUpperCase().replace(/ /g, '-') + '.NET',
                ip: ip, location: (tgt ? tgt.name : route.target) + ', ' + dist.toFixed(0) + ' mi',
                routes: routes, status: 'active'
            });
        });
        // Add connection lines text listing between sections
        let connLines = { id: '', timestamp: ts, geo: '', ip: '', target: '', location: '',
            routes: [], status: 'connlines', connText: [] };
        for (let i = 0; i < this.sections.length; i++) {
            const s = this.sections[i];
            const next = this.sections[i + 1];
            const line = 'S' + s.id + ' ' + s.name;
            const timeStr = s.timeMs > 0 ? s.timeMs.toFixed(3) + ' ms' : '-';
            const distStr = s.distMi > 0.01 ? s.distMi.toFixed(1) + ' mi' : (s.distMi * 5280).toFixed(1) + ' ft';
            if (next) {
                connLines.connText.push(line + ' --[' + timeStr + ' / ' + distStr + ']--> S' + next.id + ' ' + next.name);
            } else {
                connLines.connText.push(line + ' --[' + timeStr + ' / ' + distStr + ']--> END');
            }
        }
        this.pipes.push(connLines);
        this.renderPipeListing();
    },

    resetAll() {
        if (this.running) return;
        clearInterval(this.interval);
        this.results = [];
        this.elapsed = 0;
        this.currentSection = -1;
        this.sections.forEach(s => { s.status = 'idle'; s.timeMs = 0; });
        this.targets.forEach(t => t.tested = false);

        const el = (id) => document.getElementById(id);
        if (el('t-status')) { el('t-status').textContent = 'IDLE'; el('t-status').style.color = 'var(--cyan)'; }
        if (el('t-count')) el('t-count').textContent = '0 / 9';
        if (el('t-elapsed')) el('t-elapsed').textContent = '0.000s';
        if (el('sr-total-los')) el('sr-total-los').textContent = '-';
        if (el('sr-total-sr')) el('sr-total-sr').textContent = '-';
        if (el('sr-total-loi')) el('sr-total-loi').textContent = '-';
        if (el('sr-total-pc')) el('sr-total-pc').textContent = '-';
        if (el('sr-verdict')) { el('sr-verdict').textContent = '-'; el('sr-verdict').style.color = 'var(--green)'; }

        const btn = document.getElementById('btn-run');
        if (btn) { btn.classList.remove('running', 'done'); btn.textContent = '▶ RUN ALL ROUTING TESTS'; }

        this.renderPathVisual();
        this.renderSections();
        this.renderTargets();
        this.renderResults();
        this.drawRouteMap();
    },

    printResults() {
        window.print();
    }
};

window.addEventListener('load', () => {
    RT.init();
    if (typeof NetSwitchBridge !== 'undefined') RT.loadAndroidData();
});
window.addEventListener('resize', () => RT.drawRouteMap());

RT.loadAndroidData = function() {
    try {
        var data = JSON.parse(NetSwitchBridge.getNetworkData());
        var pas = NetSwitchBridge.getPasNumber();
        var interfaces = JSON.parse(NetSwitchBridge.getInterfaceData());
        this.sourceAddr = data.carrier + ' [' + data.ipAddress + ']';
        var pipe = {
            id: pas.replace('PAS-','').substring(0,4) + '-' + Math.floor(Math.random()*999).toString().padStart(3,'0'),
            timestamp: data.timestamp || '', geo: data.carrier + ' (' + data.deviceBrand + ' ' + data.deviceModel + ') [' + data.ipAddress + ']',
            target: 'NETWORK', ip: data.ipAddress, location: data.connectionType + ' / Android ' + data.androidVersion,
            routes: [], status: 'active'
        };
        if (data.carrier) pipe.routes.push({ carrier: data.carrier, teleop: data.carrierId || '-', conn: data.connectionType, sw: data.deviceModel, router: data.ipAddress, time: '-' });
        for (var i = 0; i < interfaces.length; i++) {
            var iface = interfaces[i];
            if (iface.isLoopback) continue;
            var addrs = [];
            for (var j = 0; j < iface.addresses.length; j++) addrs.push(iface.addresses[j]);
            if (addrs.length > 0) pipe.routes.push({ carrier: iface.displayName || iface.name, teleop: 'MTU ' + iface.mtu, conn: iface.isVirtual ? 'VIRTUAL' : 'PHYSICAL', sw: iface.name, router: addrs.join(', '), time: '-' });
        }
        this.pipes = [pipe];
        this.renderPipeListing();
        var pasEl = document.querySelector('.pipe-app-search');
        if (pasEl) pasEl.textContent = '[' + pas + '] ' + data.carrier + ' | ' + data.connectionType + ' | ' + data.ipAddress;
    } catch (e) { console.log('NetSwitchBridge: ' + e.message); }
};
