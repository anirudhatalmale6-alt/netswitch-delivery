// NetSwitch Stream Tester v3.0.0
// FMA Engineering 2026 - iOS 27 Compatible - Enterprise Bypass

const ST = {
    streaming: false,
    activeTier: null,
    activeMode: 'urban',
    activeFormat: 'mp4',
    interval: null,
    graphInterval: null,
    segmentInterval: null,
    heartbeatInterval: null,
    failoverTimeout: null,
    elapsed: 0,
    totalBytes: 0,
    packetCount: 0,
    segmentCount: 0,
    failoverCount: 0,
    recoveryCount: 0,
    graphData: [],
    maxGraphPoints: 60,
    segments: [],
    bypassEvents: [],
    heartbeats: {},
    originalTierRate: 0,

    // Mode presets
    modes: {
        urban:  { label: 'URBAN',  desc: 'City / High Coverage',  minRate: 96,  maxRate: 1000, defaultTier: 200 },
        rural:  { label: 'RURAL',  desc: 'Rural / Low Coverage',   minRate: 24,  maxRate: 200,  defaultTier: 40 },
        mobile: { label: 'MOBILE', desc: 'Phone / Battery Saver',  minRate: 40,  maxRate: 400,  defaultTier: 96 }
    },

    // Bitrate tiers per mode
    tierSets: {
        urban: [
            { id: 96,  rate: 96,  label: 'BASIC',   quality: 'SD 480p',    color: '#f59e0b' },
            { id: 132, rate: 132, label: 'STREAM',   quality: 'SD+ 720p',   color: '#3b82f6' },
            { id: 200, rate: 200, label: 'CLEAR 4K', quality: '4K Ready',   color: '#10b981' },
            { id: 500, rate: 500, label: 'ULTRA',    quality: '4K Full',    color: '#8b5cf6' }
        ],
        rural: [
            { id: 24,  rate: 24,  label: 'MINIMAL',  quality: 'Audio Only', color: '#ef4444' },
            { id: 40,  rate: 40,  label: 'RURAL',    quality: 'Low Video',  color: '#f59e0b' },
            { id: 56,  rate: 56,  label: 'BASIC',    quality: 'SD 240p',    color: '#3b82f6' },
            { id: 96,  rate: 96,  label: 'GOOD',     quality: 'SD 480p',    color: '#10b981' }
        ],
        mobile: [
            { id: 40,  rate: 40,  label: 'SAVER',    quality: 'Low Power',  color: '#f59e0b' },
            { id: 96,  rate: 96,  label: 'NORMAL',   quality: 'Balanced',   color: '#3b82f6' },
            { id: 132, rate: 132, label: 'QUALITY',   quality: 'HD Ready',   color: '#10b981' },
            { id: 200, rate: 200, label: 'MAX',       quality: 'Full HD',    color: '#8b5cf6' }
        ]
    },

    // Container formats
    formats: {
        mp4:   { label: 'MP4',       ext: '.mp4',  codec: 'H.264',  mime: 'video/mp4',       ios: true,  desc: 'MPEG-4 Part 14' },
        hevc:  { label: 'H.265',     ext: '.mp4',  codec: 'H.265',  mime: 'video/mp4',       ios: true,  desc: 'HEVC High Efficiency' },
        heic:  { label: 'HEIC',      ext: '.heic', codec: 'HEVC',   mime: 'image/heic',      ios: true,  desc: 'High Efficiency Image' },
        heics: { label: 'HEIC-Seq',  ext: '.heics',codec: 'HEVC',   mime: 'image/heic-seq',  ios: true,  desc: 'HEIC Sequence/Live' },
        avci:  { label: 'Apple HEIF',ext: '.heif', codec: 'H.264',  mime: 'image/heif',      ios: true,  desc: 'Apple HEIF Container' }
    },

    // Carrier pipes
    carriers: [
        { name: 'Verizon',  color: '#ef4444', load: 0, active: false, packets: 0, totalBytes: 0 },
        { name: 'Elisa',    color: '#3b82f6', load: 0, active: false, packets: 0, totalBytes: 0 },
        { name: 'DNA',      color: '#10b981', load: 0, active: false, packets: 0, totalBytes: 0 },
        { name: 'T-Mobile', color: '#f59e0b', load: 0, active: false, packets: 0, totalBytes: 0 }
    ],

    // Enterprise security layers
    secLayers: [
        { name: 'Okta SSO',          type: 'Identity',   status: 'clear', technique: 'TLS 1.3 Wrap' },
        { name: 'Microsoft Defender', type: 'Endpoint',   status: 'clear', technique: 'Packet Normalize' },
        { name: 'Google BeyondCorp',  type: 'Zero Trust', status: 'clear', technique: 'DoH Signaling' },
        { name: 'Cisco Umbrella',     type: 'DNS/Proxy',  status: 'clear', technique: 'SNI Masking' },
        { name: 'CrowdStrike',       type: 'EDR',        status: 'clear', technique: 'MTU Conform' },
        { name: 'Cloudflare ZT',     type: 'SASE',       status: 'clear', technique: 'HTTPS Tunnel' },
        { name: 'VMware SASE',       type: 'SD-WAN',     status: 'clear', technique: 'Pipe Rotation' },
        { name: 'APAC VPN Gateway',  type: 'Regional',   status: 'clear', technique: 'Multi-Session' }
    ],

    init() {
        this.setupCanvas();
        this.setupGraph();
        this.setMode('urban');
        this.renderFormats();
        this.renderCarriers();
        this.renderSecLayers();
        this.updateContainerInfo();
        this.updateSegmentDisplay();
        this.updateBypassLog();
        this.updateStatus();
        this.initHeartbeats();
    },

    // Mode switching (Urban / Rural / Mobile)
    setMode(mode) {
        this.activeMode = mode;
        if (this.streaming) this.stopStream();

        this.tiers = this.tierSets[mode];
        document.querySelectorAll('.mode-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.mode === mode);
        });

        const m = this.modes[mode];
        document.getElementById('mode-desc').textContent = m.desc;

        // Update log scale range display
        document.getElementById('scale-min').textContent = m.minRate + ' kbps';
        document.getElementById('scale-max').textContent = m.maxRate + ' kbps';

        this.renderTiers();
        this.selectTier(m.defaultTier);
    },

    // Format switching
    setFormat(fmt) {
        this.activeFormat = fmt;
        document.querySelectorAll('.fmt-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.fmt === fmt);
        });
        this.updateContainerInfo();
    },

    renderFormats() {
        const container = document.getElementById('format-list');
        container.innerHTML = Object.entries(this.formats).map(([key, f]) => `
            <div class="fmt-btn ${key === this.activeFormat ? 'active' : ''}" data-fmt="${key}" onclick="ST.setFormat('${key}')">
                <div class="fmt-label">${f.label}</div>
                <div class="fmt-desc">${f.desc}</div>
                ${f.ios ? '<div class="fmt-ios">iOS 27</div>' : ''}
            </div>
        `).join('');
    },

    // Log scale position - adapts to mode range
    logPosition(kbps) {
        const m = this.modes[this.activeMode];
        const minLog = Math.log(m.minRate);
        const maxLog = Math.log(m.maxRate);
        const clamped = Math.max(m.minRate, Math.min(m.maxRate, kbps));
        return (Math.log(clamped) - minLog) / (maxLog - minLog);
    },

    selectTier(rate) {
        this.activeTier = this.tiers.find(t => t.rate === rate);
        document.querySelectorAll('.tier-btn').forEach(b => {
            b.classList.remove('active');
            if (parseInt(b.dataset.rate) === rate) b.classList.add('active');
        });
        this.updateScaleBar();
        this.updateContainerInfo();
        if (this.streaming) this.redistributeCarriers();
    },

    renderTiers() {
        const grid = document.getElementById('tier-grid');
        grid.innerHTML = this.tiers.map(t => `
            <div class="tier-btn" data-rate="${t.rate}" onclick="ST.selectTier(${t.rate})">
                <div class="tier-rate">${t.rate}</div>
                <div class="tier-unit">kbps</div>
                <div class="tier-label">${t.label}</div>
                <div class="tier-quality" style="background:${t.color}22;color:${t.color}">${t.quality}</div>
            </div>
        `).join('');
    },

    updateScaleBar() {
        if (!this.activeTier) return;
        const pos = this.logPosition(this.activeTier.rate) * 100;
        document.getElementById('scale-fill').style.width = pos + '%';
        document.getElementById('scale-value').textContent = this.activeTier.rate + ' kbps';
    },

    // Carrier management
    renderCarriers() {
        const list = document.getElementById('carrier-list');
        list.innerHTML = this.carriers.map((c, i) => `
            <div class="carrier-pipe" id="carrier-${i}">
                <div class="carrier-indicator" id="carrier-dot-${i}" style="background:${c.color}"></div>
                <div class="carrier-name">${c.name}</div>
                <div class="carrier-bar-track">
                    <div class="carrier-bar-fill" id="carrier-bar-${i}" style="background:${c.color};width:0%"></div>
                </div>
                <div class="carrier-load" id="carrier-load-${i}">0 kbps</div>
            </div>
        `).join('');
    },

    redistributeCarriers() {
        if (!this.activeTier) return;
        const rate = this.activeTier.rate;
        const activeCount = this.activeMode === 'rural' ? 1 + Math.floor(Math.random() * 2) : 2 + Math.floor(Math.random() * 2);
        const shares = [];
        let remaining = rate;

        for (let i = 0; i < this.carriers.length; i++) {
            if (i < activeCount) {
                const share = i === activeCount - 1 ? remaining :
                    Math.floor(remaining * (0.3 + Math.random() * 0.4));
                shares.push(Math.max(share, 0));
                remaining -= share;
            } else {
                shares.push(0);
            }
        }

        this.carriers.forEach((c, i) => {
            c.load = shares[i];
            c.active = shares[i] > 0;
        });
    },

    updateCarrierDisplay() {
        this.carriers.forEach((c, i) => {
            const bar = document.getElementById('carrier-bar-' + i);
            const load = document.getElementById('carrier-load-' + i);
            const dot = document.getElementById('carrier-dot-' + i);

            if (!this.streaming) {
                bar.style.width = '0%';
                load.textContent = '0 kbps';
                dot.classList.remove('active');
                return;
            }

            const jitter = c.load > 0 ? (Math.random() - 0.5) * c.load * 0.15 : 0;
            const current = Math.max(0, c.load + jitter);
            const maxRate = this.activeTier ? this.activeTier.rate : 200;
            const pct = Math.min(100, (current / maxRate) * 100);

            bar.style.width = pct + '%';
            load.textContent = Math.round(current) + ' kbps';
            dot.classList.toggle('active', c.active);
        });
    },

    // Stream control
    startStream() {
        if (this.streaming) return;
        if (!this.activeTier) { this.selectTier(this.tiers[2].rate); }

        this.streaming = true;
        this.elapsed = 0;
        this.totalBytes = 0;
        this.packetCount = 0;
        this.segmentCount = 0;
        this.failoverCount = 0;
        this.recoveryCount = 0;
        this.graphData = [];
        this.segments = [];
        this.bypassEvents = [];
        this.carriers.forEach(c => { c.packets = 0; c.totalBytes = 0; });
        this.initHeartbeats();
        this.secLayers.forEach(l => l.status = 'clear');
        this.renderSecLayers();
        this.originalTierRate = this.activeTier.rate;

        this.redistributeCarriers();
        document.getElementById('btn-start').className = 'ctrl-btn stop';
        document.getElementById('btn-start').textContent = 'STOP STREAM';
        document.getElementById('btn-start').onclick = () => this.stopStream();

        document.querySelectorAll('.tier-btn').forEach(b => {
            if (parseInt(b.dataset.rate) === this.activeTier.rate) b.classList.add('streaming');
        });

        this.interval = setInterval(() => this.tick(), 500);
        this.graphInterval = setInterval(() => this.updateGraph(), 1000);
        this.segmentInterval = setInterval(() => this.generateSegment(), 2000);
        this.heartbeatInterval = setInterval(() => {
            this.tickHeartbeat();
            this.tickSecurityLayers();
            this.tickBitrateFallback();
        }, 1000);
        this.drawStream();
        this.updateStatus();
    },

    stopStream() {
        this.streaming = false;
        clearInterval(this.interval);
        clearInterval(this.graphInterval);
        clearInterval(this.segmentInterval);
        clearInterval(this.heartbeatInterval);
        this.interval = null;
        this.graphInterval = null;
        this.segmentInterval = null;
        this.heartbeatInterval = null;

        document.getElementById('btn-start').className = 'ctrl-btn start';
        document.getElementById('btn-start').textContent = 'START STREAM';
        document.getElementById('btn-start').onclick = () => this.startStream();

        document.querySelectorAll('.tier-btn').forEach(b => b.classList.remove('streaming'));
        this.carriers.forEach(c => { c.load = 0; c.active = false; });
        this.updateCarrierDisplay();
        this.updateStatus();
    },

    tick() {
        if (!this.streaming || !this.activeTier) return;
        this.elapsed += 0.5;

        const bytesPerTick = (this.activeTier.rate * 1000 / 8) * 0.5;
        const jitter = 1 + (Math.random() - 0.5) * 0.1;
        const actualBytes = Math.floor(bytesPerTick * jitter);
        this.totalBytes += actualBytes;
        this.packetCount++;

        const activeCarriers = this.carriers.filter(c => c.active);
        if (activeCarriers.length > 0) {
            const carrier = activeCarriers[Math.floor(Math.random() * activeCarriers.length)];
            carrier.packets++;
            carrier.totalBytes += actualBytes;
        }

        if (this.packetCount % 10 === 0) this.redistributeCarriers();

        this.updateCarrierDisplay();
        this.addPacketLog(actualBytes, activeCarriers);
        this.updateProgress();
        this.updateContainerInfo();
        this.updateStatus();
    },

    // Container segmentation
    generateSegment() {
        if (!this.streaming || !this.activeTier) return;
        this.segmentCount++;
        const fmt = this.formats[this.activeFormat];
        const segBytes = Math.floor((this.activeTier.rate * 1000 / 8) * 2);
        const carrier = this.carriers.filter(c => c.active);
        const pipe = carrier.length > 0 ? carrier[Math.floor(Math.random() * carrier.length)] : { name: 'N/A' };

        const seg = {
            id: this.segmentCount,
            time: this.elapsed,
            size: segBytes,
            format: fmt.label,
            codec: this.getCodecForRate(this.activeTier.rate),
            carrier: pipe.name,
            status: 'delivered'
        };
        this.segments.push(seg);
        if (this.segments.length > 15) this.segments.shift();

        this.updateSegmentDisplay();
    },

    updateSegmentDisplay() {
        const container = document.getElementById('segment-list');
        if (this.segments.length === 0) {
            container.innerHTML = '<div class="seg-empty">No segments yet. Start stream to see container splits.</div>';
            return;
        }

        container.innerHTML = this.segments.map(s => `
            <div class="seg-row">
                <span class="seg-id">#${s.id}</span>
                <span class="seg-format">${s.format}</span>
                <span class="seg-codec">${s.codec}</span>
                <span class="seg-size">${this.formatBytes(s.size)}</span>
                <span class="seg-carrier">${s.carrier}</span>
                <span class="seg-status">${s.status}</span>
            </div>
        `).join('');
        container.scrollTop = container.scrollHeight;
    },

    getCodecForRate(rate) {
        const fmt = this.formats[this.activeFormat];
        if (this.activeFormat === 'hevc' || this.activeFormat === 'heic' || this.activeFormat === 'heics') {
            return rate >= 200 ? 'HEVC Main10' : rate >= 96 ? 'HEVC Main' : 'HEVC Baseline';
        }
        if (this.activeFormat === 'avci') {
            return rate >= 200 ? 'H.264 High' : 'H.264 Baseline';
        }
        return rate >= 200 ? 'H.264 High' : rate >= 96 ? 'H.264 Main' : rate >= 40 ? 'H.264 BP' : 'AAC-LC';
    },

    addPacketLog(bytes, carriers) {
        const log = document.getElementById('packet-log');
        const carrier = carriers.length > 0 ? carriers[Math.floor(Math.random() * carriers.length)] : { name: '-', color: '#666' };
        const fmt = this.formats[this.activeFormat];
        const types = fmt.mime.startsWith('image') ?
            ['HEVC-tile', 'EXIF', 'Alpha', 'Thumb', 'Meta'] :
            ['I-frame', 'P-frame', 'B-frame', 'Audio', 'Meta'];
        const type = types[Math.floor(Math.random() * types.length)];

        const line = document.createElement('div');
        line.className = 'packet-line';
        line.innerHTML = `
            <span class="packet-time">${this.formatTime(this.elapsed)}</span>
            <span class="packet-carrier" style="color:${carrier.color}">${carrier.name}</span>
            <span class="packet-size">${this.formatBytes(bytes)}</span>
            <span class="packet-type">${type}</span>
        `;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
        while (log.children.length > 100) log.removeChild(log.firstChild);
    },

    updateProgress() {
        const duration = 60;
        const pct = Math.min(100, (this.elapsed / duration) * 100);
        document.getElementById('progress-bar').style.width = pct + '%';
        document.getElementById('stream-elapsed').textContent = this.formatTime(this.elapsed);
        document.getElementById('stream-total').textContent = this.formatBytes(this.totalBytes);
        if (this.elapsed >= duration) this.stopStream();
    },

    // Bandwidth graph
    setupGraph() {
        const canvas = document.getElementById('graph-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
    },

    updateGraph() {
        if (!this.streaming || !this.activeTier) return;
        const jitter = 1 + (Math.random() - 0.5) * 0.2;
        this.graphData.push(this.activeTier.rate * jitter);
        if (this.graphData.length > this.maxGraphPoints) this.graphData.shift();
        this.drawGraph();
    },

    drawGraph() {
        const canvas = document.getElementById('graph-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;

        ctx.clearRect(0, 0, w, h);
        if (this.graphData.length < 2) return;

        const m = this.modes[this.activeMode];
        const gridLines = this.activeMode === 'rural' ? [24, 40, 56, 96, 200] : [50, 100, 200, 500, 1000];
        ctx.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx.lineWidth = 1;
        gridLines.forEach(val => {
            if (val < m.minRate || val > m.maxRate) return;
            const y = h - (this.logPosition(val) * h);
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
        });

        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, 'rgba(6,182,212,0.8)');
        grad.addColorStop(1, 'rgba(59,130,246,0.2)');

        ctx.beginPath();
        this.graphData.forEach((val, i) => {
            const x = (i / (this.maxGraphPoints - 1)) * w;
            const y = h - (this.logPosition(val) * h);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 3;
        ctx.stroke();

        const lastX = ((this.graphData.length - 1) / (this.maxGraphPoints - 1)) * w;
        ctx.lineTo(lastX, h);
        ctx.lineTo(0, h);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();

        if (this.graphData.length > 0) {
            const last = this.graphData[this.graphData.length - 1];
            const ly = h - (this.logPosition(last) * h);
            ctx.beginPath();
            ctx.arc(lastX, ly, 6, 0, Math.PI * 2);
            ctx.fillStyle = '#06b6d4';
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
    },

    // Stream visualization
    setupCanvas() {
        const canvas = document.getElementById('stream-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        this.particles = [];
        this.animFrame = null;
    },

    drawStream() {
        const canvas = document.getElementById('stream-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;

        const draw = () => {
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.fillRect(0, 0, w, h);

            if (this.streaming && this.activeTier) {
                const rate = this.activeTier.rate;
                const particleCount = Math.max(1, Math.floor(rate / 20));

                for (let i = 0; i < particleCount; i++) {
                    const active = this.carriers.filter(c => c.active);
                    const c = active.length > 0 ? active[Math.floor(Math.random() * active.length)] : { color: '#3b82f6' };
                    this.particles.push({
                        x: Math.random() * w,
                        y: h + 10,
                        vx: (Math.random() - 0.5) * 3,
                        vy: -(2 + Math.random() * (rate / 40)),
                        size: 2 + Math.random() * 3,
                        color: c.color,
                        alpha: 0.8
                    });
                }

                this.particles.forEach(p => {
                    p.x += p.vx;
                    p.y += p.vy;
                    p.alpha -= 0.008;
                });
                this.particles = this.particles.filter(p => p.alpha > 0 && p.y > -10);

                this.particles.forEach(p => {
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fillStyle = p.color + Math.floor(p.alpha * 255).toString(16).padStart(2, '0');
                    ctx.fill();
                });

                if (rate >= 96) {
                    ctx.strokeStyle = 'rgba(6,182,212,0.1)';
                    ctx.lineWidth = 1;
                    for (let i = 0; i < 5; i++) {
                        const x = w * 0.2 + (w * 0.6 * i / 4);
                        ctx.beginPath();
                        ctx.moveTo(x, h);
                        ctx.lineTo(x + (Math.sin(Date.now() / 500 + i) * 30), 0);
                        ctx.stroke();
                    }
                }

                ctx.font = 'bold 48px monospace';
                ctx.fillStyle = 'rgba(255,255,255,0.06)';
                ctx.textAlign = 'center';
                ctx.fillText(rate + ' kbps', w / 2, h / 2 - 10);
                ctx.font = '20px monospace';
                ctx.fillText(this.formats[this.activeFormat].label + ' | ' + this.modes[this.activeMode].label, w / 2, h / 2 + 25);
            } else {
                ctx.font = 'bold 28px monospace';
                ctx.fillStyle = 'rgba(255,255,255,0.15)';
                ctx.textAlign = 'center';
                ctx.fillText('NETSWITCH STREAM', w / 2, h / 2 - 20);
                ctx.font = '16px monospace';
                ctx.fillStyle = 'rgba(255,255,255,0.1)';
                ctx.fillText('Select mode, format, bitrate and press START', w / 2, h / 2 + 20);
            }

            this.animFrame = requestAnimationFrame(draw);
        };

        if (this.animFrame) cancelAnimationFrame(this.animFrame);
        draw();
    },

    // Container info panel
    updateContainerInfo() {
        const tier = this.activeTier || (this.tiers ? this.tiers[2] : { rate: 132 });
        const rate = tier.rate;
        const fmt = this.formats[this.activeFormat];

        const fps = rate >= 200 ? 30 : rate >= 132 ? 24 : rate >= 96 ? 15 : rate >= 40 ? 10 : 0;
        const resolution = rate >= 500 ? '3840x2160' : rate >= 200 ? '1920x1080' : rate >= 132 ? '1280x720' : rate >= 96 ? '854x480' : rate >= 40 ? '426x240' : 'Audio';
        const codec = this.getCodecForRate(rate);
        const segmentSize = Math.round((rate * 1000 / 8) * 2);
        const audioBitrate = Math.min(rate, 64);
        const videoBitrate = Math.max(0, rate - audioBitrate);

        document.getElementById('info-codec').textContent = codec;
        document.getElementById('info-resolution').textContent = resolution;
        document.getElementById('info-fps').textContent = fps > 0 ? fps + ' fps' : 'N/A';
        document.getElementById('info-segment').textContent = this.formatBytes(segmentSize);
        document.getElementById('info-audio').textContent = audioBitrate + ' kbps';
        document.getElementById('info-video').textContent = videoBitrate + ' kbps';
        document.getElementById('info-container').textContent = fmt.label + ' (' + fmt.ext + ')';
        document.getElementById('info-packets').textContent = this.packetCount;
        document.getElementById('info-segments').textContent = this.segmentCount;
        document.getElementById('info-ios').textContent = fmt.ios ? 'iOS 27 Ready' : 'Not Supported';
    },

    updateStatus() {
        const status = document.getElementById('status-state');
        const dot = document.getElementById('status-dot');

        if (this.streaming) {
            status.textContent = 'STREAMING';
            dot.style.background = '#10b981';
        } else {
            status.textContent = 'IDLE';
            dot.style.background = '#64748b';
        }

        document.getElementById('status-tier').textContent = this.activeTier ? this.activeTier.rate + ' kbps' : '-';
        document.getElementById('status-carriers').textContent = this.carriers.filter(c => c.active).length + '/4';
        document.getElementById('status-transferred').textContent = this.formatBytes(this.totalBytes);
        document.getElementById('status-mode').textContent = this.modes[this.activeMode].label;
        document.getElementById('status-format').textContent = this.formats[this.activeFormat].label;
        const fo = document.getElementById('status-failovers');
        if (fo) fo.textContent = this.failoverCount + '/' + this.recoveryCount;
    },

    // Enterprise Bypass Engine
    initHeartbeats() {
        this.carriers.forEach((c, i) => {
            this.heartbeats[i] = { alive: true, misses: 0, latency: 0, lastPing: 0 };
        });
        this.renderHeartbeats();
    },

    renderSecLayers() {
        const el = document.getElementById('sec-layers');
        if (!el) return;
        el.innerHTML = this.secLayers.map((l, i) => `
            <div class="sec-row" id="sec-${i}">
                <div class="sec-dot" id="sec-dot-${i}" style="background:#10b981"></div>
                <div class="sec-name">${l.name}</div>
                <div class="sec-type">${l.type}</div>
                <div class="sec-technique" id="sec-tech-${i}">${l.technique}</div>
                <div class="sec-status" id="sec-status-${i}">CLEAR</div>
            </div>
        `).join('');
    },

    renderHeartbeats() {
        const el = document.getElementById('heartbeat-grid');
        if (!el) return;
        el.innerHTML = this.carriers.map((c, i) => {
            const hb = this.heartbeats[i] || { alive: true, misses: 0, latency: 0 };
            return `
                <div class="hb-card" id="hb-${i}">
                    <div class="hb-name" style="color:${c.color}">${c.name}</div>
                    <div class="hb-indicator" id="hb-dot-${i}" style="background:${hb.alive ? '#10b981' : '#ef4444'}"></div>
                    <div class="hb-latency" id="hb-lat-${i}">${hb.latency}ms</div>
                    <div class="hb-misses" id="hb-miss-${i}">Miss: ${hb.misses}</div>
                </div>
            `;
        }).join('');
    },

    tickHeartbeat() {
        if (!this.streaming) return;

        this.carriers.forEach((c, i) => {
            const hb = this.heartbeats[i];
            if (!hb) return;

            // Simulate heartbeat with occasional failures
            const failChance = this.activeMode === 'rural' ? 0.12 : 0.04;
            if (c.active && Math.random() < failChance) {
                hb.misses++;
                hb.latency = 999;

                if (hb.misses >= 3) {
                    // Carrier marked dead - trigger failover
                    hb.alive = false;
                    c.active = false;
                    c.load = 0;
                    this.failoverCount++;
                    this.addBypassEvent('FAILOVER', c.name + ' dead (3 missed heartbeats)', 'warn');
                    this.triggerFailover(i);
                }
            } else if (c.active || hb.alive) {
                hb.misses = 0;
                hb.latency = 5 + Math.floor(Math.random() * (this.activeMode === 'rural' ? 80 : 30));
                hb.alive = true;
            }

            // Recovery check - dead carriers can come back
            if (!hb.alive && Math.random() < 0.08) {
                hb.alive = true;
                hb.misses = 0;
                hb.latency = 15 + Math.floor(Math.random() * 40);
                this.recoveryCount++;
                this.addBypassEvent('RECOVERY', c.name + ' reconnected (standby pool)', 'success');
            }

            // Update heartbeat display
            const dot = document.getElementById('hb-dot-' + i);
            const lat = document.getElementById('hb-lat-' + i);
            const miss = document.getElementById('hb-miss-' + i);
            if (dot) dot.style.background = hb.alive ? '#10b981' : '#ef4444';
            if (lat) lat.textContent = hb.latency + 'ms';
            if (miss) miss.textContent = 'Miss: ' + hb.misses;
        });
    },

    triggerFailover(deadIdx) {
        // Find standby carrier to activate
        for (let i = 0; i < this.carriers.length; i++) {
            if (i !== deadIdx && !this.carriers[i].active && this.heartbeats[i] && this.heartbeats[i].alive) {
                this.carriers[i].active = true;
                this.carriers[i].load = this.carriers[deadIdx].load || (this.activeTier ? this.activeTier.rate / 3 : 50);
                this.addBypassEvent('REROUTE', 'Traffic moved to ' + this.carriers[i].name, 'info');
                break;
            }
        }
        this.redistributeCarriers();
    },

    tickSecurityLayers() {
        if (!this.streaming) return;

        this.secLayers.forEach((l, i) => {
            const challengeChance = 0.06;
            const dot = document.getElementById('sec-dot-' + i);
            const status = document.getElementById('sec-status-' + i);
            if (!dot || !status) return;

            if (l.status === 'challenged') {
                // Resolve challenge using bypass technique
                l.status = 'bypassed';
                dot.style.background = '#f59e0b';
                status.textContent = 'BYPASSED';
                status.style.color = '#f59e0b';
                this.addBypassEvent('BYPASS', l.name + ' navigated via ' + l.technique, 'success');

                setTimeout(() => {
                    l.status = 'clear';
                    dot.style.background = '#10b981';
                    status.textContent = 'CLEAR';
                    status.style.color = '#10b981';
                }, 2000 + Math.random() * 3000);
            } else if (l.status === 'clear' && Math.random() < challengeChance) {
                l.status = 'challenged';
                dot.style.background = '#ef4444';
                status.textContent = 'BLOCKED';
                status.style.color = '#ef4444';
                this.addBypassEvent('DETECT', l.name + ' (' + l.type + ') flagged traffic', 'warn');
            }
        });
    },

    tickBitrateFallback() {
        if (!this.streaming || !this.activeTier) return;
        const activeCount = this.carriers.filter(c => c.active).length;

        // Progressive bitrate fallback when carriers drop
        if (activeCount <= 1 && this.activeTier.rate > this.tiers[0].rate) {
            const currentIdx = this.tiers.findIndex(t => t.rate === this.activeTier.rate);
            if (currentIdx > 0) {
                const newTier = this.tiers[currentIdx - 1];
                this.addBypassEvent('FALLBACK', 'Bitrate reduced ' + this.activeTier.rate + 'k -> ' + newTier.rate + 'k', 'warn');
                this.selectTier(newTier.rate);
            }
        }
        // Recovery: step back up when carriers return
        else if (activeCount >= 3 && this.originalTierRate > 0 && this.activeTier.rate < this.originalTierRate) {
            const currentIdx = this.tiers.findIndex(t => t.rate === this.activeTier.rate);
            if (currentIdx < this.tiers.length - 1) {
                const newTier = this.tiers[currentIdx + 1];
                if (newTier.rate <= this.originalTierRate) {
                    this.addBypassEvent('RESTORE', 'Bitrate restored to ' + newTier.rate + 'k', 'success');
                    this.selectTier(newTier.rate);
                }
            }
        }
    },

    addBypassEvent(type, msg, level) {
        const evt = { time: this.elapsed, type: type, msg: msg, level: level };
        this.bypassEvents.push(evt);
        if (this.bypassEvents.length > 50) this.bypassEvents.shift();
        this.updateBypassLog();
    },

    updateBypassLog() {
        const el = document.getElementById('bypass-log');
        if (!el) return;
        if (this.bypassEvents.length === 0) {
            el.innerHTML = '<div class="bypass-empty">No events. Start stream to monitor enterprise bypass.</div>';
            return;
        }
        el.innerHTML = this.bypassEvents.slice(-20).reverse().map(e => {
            const color = e.level === 'warn' ? '#f59e0b' : e.level === 'success' ? '#10b981' : '#3b82f6';
            return `<div class="bypass-line">
                <span class="bypass-time">${this.formatTime(e.time)}</span>
                <span class="bypass-type" style="color:${color}">${e.type}</span>
                <span class="bypass-msg">${e.msg}</span>
            </div>`;
        }).join('');
    },

    // Helpers
    formatBytes(b) {
        if (b < 1024) return b + ' B';
        if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
        return (b / (1024 * 1024)).toFixed(2) + ' MB';
    },

    formatTime(s) {
        const m = Math.floor(s / 60);
        const sec = Math.floor(s % 60);
        const ms = Math.floor((s % 1) * 10);
        return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec + '.' + ms;
    }
};

window.addEventListener('load', () => ST.init());
window.addEventListener('resize', () => {
    ST.setupCanvas();
    ST.setupGraph();
    ST.drawStream();
    if (ST.graphData.length > 0) ST.drawGraph();
});
