// NetSwitch Field Streamer v1.0.0
// FMA Engineering 2026

const FS = {
    mediaMode: 'photo',
    tool: 'pin',
    capturing: false,
    paused: false,
    streaming: false,
    elapsed: 0,
    totalBytes: 0,
    cloudUploaded: 0,
    cloudQueue: 0,
    captureCount: 0,
    zoom: 1.0,
    mapCenter: { lat: 60.17, lng: 24.94 },
    markers: [],
    areaPoints: [],
    routePoints: [],
    events: [],
    intervals: {},
    animFrame: null,

    carriers: [
        { name: 'Elisa 5G',       color: '#3b82f6', active: true,  load: 0, kbps: 0 },
        { name: 'Vodafone UK',     color: '#ec4899', active: true,  load: 0, kbps: 0 },
        { name: 'Verizon US East', color: '#ef4444', active: true,  load: 0, kbps: 0 },
        { name: 'PacBell West US', color: '#06b6d4', active: false, load: 0, kbps: 0 }
    ],

    coverageZones: [
        { lat: 60.19, lng: 24.92, r: 0.015, strength: 'strong' },
        { lat: 60.16, lng: 24.96, r: 0.020, strength: 'strong' },
        { lat: 60.18, lng: 24.98, r: 0.012, strength: 'fair' },
        { lat: 60.15, lng: 24.90, r: 0.018, strength: 'fair' },
        { lat: 60.21, lng: 24.95, r: 0.010, strength: 'weak' },
        { lat: 60.14, lng: 25.00, r: 0.014, strength: 'weak' }
    ],

    pois: [
        { lat: 60.170, lng: 24.938, label: 'HQ',       icon: 'H' },
        { lat: 60.185, lng: 24.960, label: 'Tower A',   icon: 'T' },
        { lat: 60.155, lng: 24.920, label: 'Tower B',   icon: 'T' },
        { lat: 60.175, lng: 24.980, label: 'Relay',     icon: 'R' },
        { lat: 60.195, lng: 24.910, label: 'Gateway',   icon: 'G' },
        { lat: 60.160, lng: 24.955, label: 'Client',    icon: 'C' },
        { lat: 60.200, lng: 24.970, label: 'Edge Node', icon: 'E' },
        { lat: 60.145, lng: 24.940, label: 'Backup',    icon: 'B' }
    ],

    init() {
        this.setupMap();
        this.setupCamera();
        this.renderCarriers();
        this.startAnimLoop();
        this.addEvent('INIT', 'Field Streamer v1.0 ready');
    },

    // Map canvas
    setupMap() {
        const c = document.getElementById('map-canvas');
        const w = c.parentElement;
        c.width = w.clientWidth;
        c.height = w.clientHeight;
        this.mapCtx = c.getContext('2d');
        this.mapW = c.width;
        this.mapH = c.height;

        c.addEventListener('click', e => {
            const rect = c.getBoundingClientRect();
            const x = (e.clientX - rect.left) * (c.width / rect.width);
            const y = (e.clientY - rect.top) * (c.height / rect.height);
            this.handleMapClick(x, y);
        });

        window.addEventListener('resize', () => {
            c.width = w.clientWidth;
            c.height = w.clientHeight;
            this.mapW = c.width;
            this.mapH = c.height;
        });
    },

    latLngToXY(lat, lng) {
        const scale = this.zoom;
        const cx = this.mapCenter.lng;
        const cy = this.mapCenter.lat;
        const degPerPxX = 0.08 / (this.mapW * scale);
        const degPerPxY = 0.04 / (this.mapH * scale);
        const x = this.mapW / 2 + (lng - cx) / degPerPxX;
        const y = this.mapH / 2 - (lat - cy) / degPerPxY;
        return { x, y };
    },

    xyToLatLng(x, y) {
        const scale = this.zoom;
        const cx = this.mapCenter.lng;
        const cy = this.mapCenter.lat;
        const degPerPxX = 0.08 / (this.mapW * scale);
        const degPerPxY = 0.04 / (this.mapH * scale);
        const lng = cx + (x - this.mapW / 2) * degPerPxX;
        const lat = cy - (y - this.mapH / 2) * degPerPxY;
        return { lat, lng };
    },

    drawMap() {
        const ctx = this.mapCtx;
        const w = this.mapW;
        const h = this.mapH;
        ctx.clearRect(0, 0, w, h);

        // Background gradient
        const bg = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, Math.max(w, h) * 0.7);
        bg.addColorStop(0, '#0f1d33');
        bg.addColorStop(1, '#060a12');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, w, h);

        // Grid
        ctx.strokeStyle = 'rgba(30,45,74,0.5)';
        ctx.lineWidth = 0.5;
        const gridStep = 40 * this.zoom;
        for (let x = 0; x < w; x += gridStep) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
        for (let y = 0; y < h; y += gridStep) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }

        // Roads (simulated street grid)
        ctx.strokeStyle = 'rgba(60,90,140,0.3)';
        ctx.lineWidth = 1.5;
        const roads = [
            [{ lat: 60.14, lng: 24.88 }, { lat: 60.22, lng: 24.88 }],
            [{ lat: 60.14, lng: 24.93 }, { lat: 60.22, lng: 24.93 }],
            [{ lat: 60.14, lng: 24.98 }, { lat: 60.22, lng: 24.98 }],
            [{ lat: 60.14, lng: 25.03 }, { lat: 60.22, lng: 25.03 }],
            [{ lat: 60.15, lng: 24.85 }, { lat: 60.15, lng: 25.05 }],
            [{ lat: 60.17, lng: 24.85 }, { lat: 60.17, lng: 25.05 }],
            [{ lat: 60.19, lng: 24.85 }, { lat: 60.19, lng: 25.05 }],
            [{ lat: 60.21, lng: 24.85 }, { lat: 60.21, lng: 25.05 }]
        ];
        roads.forEach(r => {
            const a = this.latLngToXY(r[0].lat, r[0].lng);
            const b = this.latLngToXY(r[1].lat, r[1].lng);
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        });

        // Diagonal roads
        ctx.strokeStyle = 'rgba(60,90,140,0.2)';
        ctx.lineWidth = 1;
        const diags = [
            [{ lat: 60.14, lng: 24.90 }, { lat: 60.20, lng: 25.00 }],
            [{ lat: 60.22, lng: 24.90 }, { lat: 60.16, lng: 25.02 }]
        ];
        diags.forEach(r => {
            const a = this.latLngToXY(r[0].lat, r[0].lng);
            const b = this.latLngToXY(r[1].lat, r[1].lng);
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        });

        // Coverage zones
        this.coverageZones.forEach(z => {
            const p = this.latLngToXY(z.lat, z.lng);
            const rPx = z.r * this.mapW * this.zoom * 8;
            const colors = { strong: '#10b981', fair: '#f59e0b', weak: '#ef4444' };
            const c = colors[z.strength];
            const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rPx);
            grad.addColorStop(0, c + '30');
            grad.addColorStop(0.7, c + '10');
            grad.addColorStop(1, c + '00');
            ctx.fillStyle = grad;
            ctx.beginPath(); ctx.arc(p.x, p.y, rPx, 0, Math.PI * 2); ctx.fill();
        });

        // Area polygon (if marking)
        if (this.areaPoints.length > 1) {
            ctx.strokeStyle = 'rgba(139,92,246,0.7)';
            ctx.fillStyle = 'rgba(139,92,246,0.1)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            this.areaPoints.forEach((p, i) => {
                const xy = this.latLngToXY(p.lat, p.lng);
                if (i === 0) ctx.moveTo(xy.x, xy.y);
                else ctx.lineTo(xy.x, xy.y);
            });
            if (this.areaPoints.length > 2) { ctx.closePath(); ctx.fill(); }
            ctx.stroke();
        }

        // Route line
        if (this.routePoints.length > 1) {
            ctx.strokeStyle = 'rgba(249,115,22,0.8)';
            ctx.lineWidth = 2;
            ctx.setLineDash([6, 4]);
            ctx.beginPath();
            this.routePoints.forEach((p, i) => {
                const xy = this.latLngToXY(p.lat, p.lng);
                if (i === 0) ctx.moveTo(xy.x, xy.y);
                else ctx.lineTo(xy.x, xy.y);
            });
            ctx.stroke();
            ctx.setLineDash([]);
        }

        // POIs
        this.pois.forEach(poi => {
            const p = this.latLngToXY(poi.lat, poi.lng);
            if (p.x < -20 || p.x > w + 20 || p.y < -20 || p.y > h + 20) return;
            ctx.fillStyle = 'rgba(6,182,212,0.15)';
            ctx.beginPath(); ctx.arc(p.x, p.y, 14, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#06b6d4';
            ctx.beginPath(); ctx.arc(p.x, p.y, 5, 0, Math.PI * 2); ctx.fill();
            ctx.font = '600 8px JetBrains Mono';
            ctx.fillStyle = '#94a3b8';
            ctx.textAlign = 'center';
            ctx.fillText(poi.label, p.x, p.y + 20);
        });

        // User markers
        this.markers.forEach((m, i) => {
            const p = this.latLngToXY(m.lat, m.lng);
            if (p.x < -20 || p.x > w + 20 || p.y < -20 || p.y > h + 20) return;
            const colors = { photo: '#10b981', video: '#ef4444', stream: '#06b6d4' };
            const col = colors[m.type] || '#3b82f6';

            // Pin shape
            ctx.fillStyle = col;
            ctx.beginPath();
            ctx.arc(p.x, p.y - 10, 7, Math.PI, 0);
            ctx.lineTo(p.x, p.y);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.arc(p.x, p.y - 10, 3, 0, Math.PI * 2); ctx.fill();

            ctx.font = '600 8px JetBrains Mono';
            ctx.fillStyle = col;
            ctx.textAlign = 'center';
            ctx.fillText('#' + (i + 1), p.x, p.y + 12);
        });

        // Center crosshair
        ctx.strokeStyle = 'rgba(255,255,255,0.15)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(w/2 - 15, h/2); ctx.lineTo(w/2 + 15, h/2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w/2, h/2 - 15); ctx.lineTo(w/2, h/2 + 15); ctx.stroke();

        // Scale bar
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillRect(w - 80, h - 20, 60, 2);
        ctx.font = '500 8px JetBrains Mono';
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.textAlign = 'center';
        const scaleDist = (0.08 / this.zoom * 60 / this.mapW * 111).toFixed(1);
        ctx.fillText(scaleDist + ' km', w - 50, h - 25);
    },

    handleMapClick(x, y) {
        const pos = this.xyToLatLng(x, y);
        if (this.tool === 'pin') {
            this.markers.push({ lat: pos.lat, lng: pos.lng, type: this.mediaMode, time: this.formatTime(Date.now()) });
            this.addEvent('MARKER', 'Pin #' + this.markers.length + ' at ' + pos.lat.toFixed(4) + ', ' + pos.lng.toFixed(4));
            this.renderMarkers();
        } else if (this.tool === 'area') {
            this.areaPoints.push(pos);
            if (this.areaPoints.length === 1) this.addEvent('AREA', 'Started area marking');
        } else if (this.tool === 'route') {
            this.routePoints.push(pos);
            if (this.routePoints.length === 1) this.addEvent('ROUTE', 'Started route drawing');
        } else if (this.tool === 'measure') {
            if (!this._measureStart) {
                this._measureStart = pos;
                this.addEvent('MEASURE', 'Start point set');
            } else {
                const d = this.haversine(this._measureStart.lat, this._measureStart.lng, pos.lat, pos.lng);
                this.addEvent('MEASURE', 'Distance: ' + d.toFixed(2) + ' km');
                this._measureStart = null;
            }
        }
    },

    haversine(lat1, lng1, lat2, lng2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    },

    setTool(t) {
        this.tool = t;
        if (t === 'area') { this.areaPoints = []; }
        if (t === 'route') { this.routePoints = []; }
        this._measureStart = null;
        document.querySelectorAll('.map-tool').forEach(b => b.classList.remove('active'));
        document.getElementById('tool-' + t).classList.add('active');
    },

    zoomIn() { this.zoom = Math.min(this.zoom * 1.3, 5); },
    zoomOut() { this.zoom = Math.max(this.zoom / 1.3, 0.5); },

    // Camera viewfinder
    setupCamera() {
        const c = document.getElementById('cam-canvas');
        const w = c.parentElement;
        c.width = w.clientWidth;
        c.height = w.clientHeight;
        this.camCtx = c.getContext('2d');
        this.camW = c.width;
        this.camH = c.height;
        this.camNoise = [];
        for (let i = 0; i < 200; i++) {
            this.camNoise.push({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random() * 2, v: Math.random() });
        }
        window.addEventListener('resize', () => {
            c.width = w.clientWidth;
            c.height = w.clientHeight;
            this.camW = c.width;
            this.camH = c.height;
        });
    },

    drawCamera(t) {
        const ctx = this.camCtx;
        const w = this.camW;
        const h = this.camH;

        // Scene simulation (urban landscape)
        const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.5);
        skyGrad.addColorStop(0, '#0a1628');
        skyGrad.addColorStop(1, '#162040');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, w, h * 0.5);

        // Ground
        const gndGrad = ctx.createLinearGradient(0, h * 0.5, 0, h);
        gndGrad.addColorStop(0, '#1a2844');
        gndGrad.addColorStop(1, '#0d1320');
        ctx.fillStyle = gndGrad;
        ctx.fillRect(0, h * 0.5, w, h * 0.5);

        // Horizon line
        ctx.strokeStyle = 'rgba(6,182,212,0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, h * 0.5); ctx.lineTo(w, h * 0.5); ctx.stroke();

        // Buildings silhouette
        const buildings = [
            { x: 0.05, w: 0.08, h: 0.35 }, { x: 0.14, w: 0.06, h: 0.25 },
            { x: 0.22, w: 0.10, h: 0.40 }, { x: 0.34, w: 0.07, h: 0.20 },
            { x: 0.43, w: 0.05, h: 0.30 }, { x: 0.50, w: 0.12, h: 0.45 },
            { x: 0.64, w: 0.06, h: 0.22 }, { x: 0.72, w: 0.09, h: 0.38 },
            { x: 0.83, w: 0.07, h: 0.28 }, { x: 0.92, w: 0.08, h: 0.32 }
        ];
        buildings.forEach(b => {
            const bx = b.x * w;
            const bw = b.w * w;
            const bh = b.h * h * 0.5;
            const by = h * 0.5 - bh;
            ctx.fillStyle = '#0d1825';
            ctx.fillRect(bx, by, bw, bh);

            // Windows
            ctx.fillStyle = 'rgba(59,130,246,0.15)';
            const winW = bw * 0.15;
            const winH = bh * 0.05;
            for (let wy = by + 6; wy < by + bh - 4; wy += bh * 0.1) {
                for (let wx = bx + 3; wx < bx + bw - 3; wx += bw * 0.25) {
                    if (Math.sin(wx * 7 + wy * 3 + t * 0.001) > 0.2) {
                        ctx.fillStyle = 'rgba(59,130,246,' + (0.1 + Math.sin(wx + t * 0.002) * 0.1) + ')';
                        ctx.fillRect(wx, wy, winW, winH);
                    }
                }
            }
        });

        // Stars
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        this.camNoise.forEach(n => {
            if (n.y < 0.5) {
                const flicker = 0.2 + Math.sin(t * 0.003 + n.x * 100) * 0.3;
                ctx.globalAlpha = flicker;
                ctx.fillRect(n.x * w, n.y * h, n.s, n.s);
            }
        });
        ctx.globalAlpha = 1;

        // Road lines
        ctx.strokeStyle = 'rgba(100,120,160,0.15)';
        ctx.lineWidth = 1;
        const vanishX = w * 0.5;
        const vanishY = h * 0.5;
        ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(vanishX, vanishY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w, h); ctx.lineTo(vanishX, vanishY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w * 0.3, h); ctx.lineTo(vanishX, vanishY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w * 0.7, h); ctx.lineTo(vanishX, vanishY); ctx.stroke();

        // Recording flash
        if (this.capturing && !this.paused && this.mediaMode === 'video') {
            ctx.strokeStyle = 'rgba(239,68,68,' + (0.3 + Math.sin(t * 0.005) * 0.2) + ')';
            ctx.lineWidth = 3;
            ctx.strokeRect(2, 2, w - 4, h - 4);
        }

        // Streaming indicator
        if (this.streaming && !this.paused) {
            ctx.strokeStyle = 'rgba(6,182,212,' + (0.3 + Math.sin(t * 0.004) * 0.2) + ')';
            ctx.lineWidth = 2;
            ctx.strokeRect(2, 2, w - 4, h - 4);
        }

        // Scan line effect
        if (this.capturing || this.streaming) {
            const scanY = (t * 0.2) % h;
            ctx.strokeStyle = 'rgba(6,182,212,0.08)';
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(0, scanY); ctx.lineTo(w, scanY); ctx.stroke();
        }
    },

    // Media controls
    setMediaMode(mode) {
        if (this.capturing || this.streaming) return;
        this.mediaMode = mode;
        document.querySelectorAll('.cam-btn').forEach(b => b.classList.remove('active'));
        const btnMap = { photo: 'btn-photo', video: 'btn-video', stream: 'btn-stream-mode' };
        document.getElementById(btnMap[mode]).classList.add('active');
        document.getElementById('s-mode').textContent = mode.toUpperCase();

        const ring = document.querySelector('.capture-ring');
        ring.className = 'capture-ring';
        const dot = document.getElementById('capture-dot');
        dot.style.background = '';
        if (mode === 'video') dot.style.background = '#ef4444';
        if (mode === 'stream') dot.style.background = '#06b6d4';

        document.getElementById('vf-fmt').textContent = mode === 'photo' ? 'HEIC' : 'H.265';
        document.getElementById('vf-res').textContent = mode === 'photo' ? '4032x3024' : '1920x1080';
        document.getElementById('vf-fps').textContent = mode === 'photo' ? '-' : '30 fps';
    },

    capture() {
        if (this.mediaMode === 'photo') {
            this.takePhoto();
        } else if (this.mediaMode === 'video') {
            if (!this.capturing) this.startVideo();
            else this.stopCapture();
        } else if (this.mediaMode === 'stream') {
            if (!this.streaming) this.startStream();
            else this.stopCapture();
        }
    },

    takePhoto() {
        this.captureCount++;
        const size = 2048 + Math.floor(Math.random() * 4096);
        this.totalBytes += size * 1024;
        this.cloudQueue++;
        this.addEvent('PHOTO', 'Captured #' + this.captureCount + ' (' + (size / 1024).toFixed(1) + ' MB)');

        // Flash effect
        const ctx = this.camCtx;
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillRect(0, 0, this.camW, this.camH);

        // Auto-tag to current map center
        if (this.markers.length === 0 || this.tool === 'pin') {
            this.markers.push({
                lat: this.mapCenter.lat + (Math.random() - 0.5) * 0.01,
                lng: this.mapCenter.lng + (Math.random() - 0.5) * 0.01,
                type: 'photo',
                time: this.formatTime(Date.now())
            });
            this.renderMarkers();
        }

        // Simulate cloud upload
        setTimeout(() => {
            this.cloudQueue--;
            this.cloudUploaded += size * 1024;
            this.addEvent('CLOUD', 'Photo #' + this.captureCount + ' uploaded');
        }, 1500 + Math.random() * 2000);

        this.updateStatus();
    },

    startVideo() {
        this.capturing = true;
        this.paused = false;
        this.elapsed = 0;
        this.addEvent('VIDEO', 'Recording started');

        document.getElementById('vf-rec').style.display = '';
        document.getElementById('btn-pause').style.display = '';
        document.getElementById('btn-stop').style.display = '';
        document.querySelector('.capture-ring').classList.add('recording');
        document.getElementById('s-dot').style.background = '#ef4444';
        document.getElementById('s-state').textContent = 'RECORDING';

        this.intervals.video = setInterval(() => {
            if (!this.paused) {
                this.elapsed += 100;
                const chunk = 32 + Math.floor(Math.random() * 64);
                this.totalBytes += chunk * 1024;
                this.cloudQueue = Math.max(0, this.cloudQueue + (Math.random() > 0.7 ? 1 : -1));
                this.cloudUploaded += chunk * 512;
                this.updateStatus();
                this.updateCarrierLoads();
            }
        }, 100);
    },

    startStream() {
        this.streaming = true;
        this.paused = false;
        this.elapsed = 0;
        this.addEvent('STREAM', 'Cloud streaming started');

        document.getElementById('vf-stream').style.display = '';
        document.getElementById('btn-pause').style.display = '';
        document.getElementById('btn-stop').style.display = '';
        document.querySelector('.capture-ring').classList.add('streaming');
        document.getElementById('s-dot').style.background = '#06b6d4';
        document.getElementById('s-state').textContent = 'STREAMING';
        document.getElementById('s-cloud').textContent = 'LIVE';
        document.getElementById('cloud-icon').classList.add('uploading');
        document.getElementById('cloud-label').textContent = 'STREAMING LIVE';
        document.getElementById('cloud-sub').textContent = 'Multi-carrier pipe active';

        this.intervals.stream = setInterval(() => {
            if (!this.paused) {
                this.elapsed += 100;
                const chunk = 48 + Math.floor(Math.random() * 96);
                this.totalBytes += chunk * 1024;
                this.cloudUploaded += chunk * 1024;
                this.cloudQueue = Math.floor(Math.random() * 3);
                this.updateStatus();
                this.updateCarrierLoads();
            }
        }, 100);
    },

    pause() {
        this.paused = !this.paused;
        const btn = document.getElementById('btn-pause');
        if (this.paused) {
            btn.querySelector('span').textContent = 'RESUME';
            this.addEvent('PAUSE', 'Capture paused');
            document.getElementById('s-state').textContent = 'PAUSED';
        } else {
            btn.querySelector('span').textContent = 'PAUSE';
            this.addEvent('RESUME', 'Capture resumed');
            document.getElementById('s-state').textContent = this.streaming ? 'STREAMING' : 'RECORDING';
        }
    },

    stopCapture() {
        this.capturing = false;
        this.streaming = false;
        this.paused = false;
        clearInterval(this.intervals.video);
        clearInterval(this.intervals.stream);

        document.getElementById('vf-rec').style.display = 'none';
        document.getElementById('vf-stream').style.display = 'none';
        document.getElementById('btn-pause').style.display = 'none';
        document.getElementById('btn-stop').style.display = 'none';
        document.querySelector('.capture-ring').className = 'capture-ring';
        document.getElementById('s-dot').style.background = '#64748b';
        document.getElementById('s-state').textContent = 'IDLE';
        document.getElementById('s-cloud').textContent = 'READY';
        document.getElementById('cloud-icon').className = 'cloud-icon';
        document.getElementById('cloud-label').textContent = 'CLOUD READY';
        document.getElementById('cloud-sub').textContent = 'Capture complete';

        this.captureCount++;
        this.addEvent('STOP', 'Capture stopped - ' + this.formatBytes(this.totalBytes));

        // Auto-add marker
        this.markers.push({
            lat: this.mapCenter.lat + (Math.random() - 0.5) * 0.01,
            lng: this.mapCenter.lng + (Math.random() - 0.5) * 0.01,
            type: this.mediaMode,
            time: this.formatTime(Date.now())
        });
        this.renderMarkers();
        this.resetCarrierLoads();
    },

    // Carrier management
    renderCarriers() {
        const html = this.carriers.map(c => {
            const dotClass = c.active ? 'carrier-dot active' : 'carrier-dot';
            return '<div class="carrier-row">' +
                '<div class="' + dotClass + '" style="color:' + c.color + ';background:' + c.color + '"></div>' +
                '<div class="carrier-name">' + c.name + '</div>' +
                '<div class="carrier-bar-bg"><div class="carrier-bar" style="width:' + c.load + '%;background:' + c.color + '"></div></div>' +
                '<div class="carrier-kbps">' + c.kbps + ' kbps</div></div>';
        }).join('');
        document.getElementById('carrier-list').innerHTML = html;
    },

    updateCarrierLoads() {
        this.carriers.forEach(c => {
            if (c.active) {
                c.load = Math.min(100, c.load + (Math.random() * 20 - 5));
                c.kbps = Math.floor(100 + Math.random() * 400);
            }
        });
        this.renderCarriers();
    },

    resetCarrierLoads() {
        this.carriers.forEach(c => { c.load = 0; c.kbps = 0; });
        this.renderCarriers();
    },

    // Markers
    renderMarkers() {
        const el = document.getElementById('marker-list');
        if (this.markers.length === 0) {
            el.innerHTML = '<div class="marker-empty">Click map to drop markers. Media auto-tagged to location.</div>';
            return;
        }
        el.innerHTML = this.markers.map((m, i) => {
            const icons = { photo: '&#128247;', video: '&#127909;', stream: '&#128225;' };
            return '<div class="marker-item">' +
                '<div class="marker-icon">' + (icons[m.type] || '&#128205;') + '</div>' +
                '<div class="marker-info"><div class="marker-name">Marker #' + (i + 1) + '</div>' +
                '<div class="marker-pos">' + m.lat.toFixed(4) + ', ' + m.lng.toFixed(4) + '</div></div>' +
                '<div class="marker-type ' + m.type + '">' + m.type.toUpperCase() + '</div></div>';
        }).join('');
    },

    // Events
    addEvent(type, msg) {
        const now = new Date();
        const time = now.getHours().toString().padStart(2, '0') + ':' +
                     now.getMinutes().toString().padStart(2, '0') + '.' +
                     now.getSeconds().toString().padStart(2, '0');
        this.events.unshift({ time, type, msg });
        if (this.events.length > 50) this.events.pop();

        const colors = { PHOTO: 'var(--green)', VIDEO: 'var(--red)', STREAM: 'var(--cyan)',
                         CLOUD: 'var(--blue)', MARKER: 'var(--yellow)', PAUSE: 'var(--yellow)',
                         RESUME: 'var(--green)', STOP: 'var(--dim)', INIT: 'var(--cyan)',
                         AREA: 'var(--purple)', ROUTE: 'var(--orange)', MEASURE: 'var(--cyan)' };

        const el = document.getElementById('capture-log');
        el.innerHTML = this.events.map(e =>
            '<div class="evt-line"><span class="evt-time">' + e.time + '</span>' +
            '<span class="evt-type" style="color:' + (colors[e.type] || 'var(--dim)') + '">' + e.type + '</span>' +
            '<span class="evt-msg">' + e.msg + '</span></div>'
        ).join('');
    },

    // Status
    updateStatus() {
        document.getElementById('s-upload').textContent = this.formatBytes(this.totalBytes);
        document.getElementById('s-elapsed').textContent = this.formatElapsed(this.elapsed);
        document.getElementById('cs-uploaded').textContent = this.formatBytes(this.cloudUploaded);
        document.getElementById('cs-queue').textContent = this.cloudQueue.toString();

        const activePipes = this.carriers.filter(c => c.active).length;
        document.getElementById('s-carrier').textContent = activePipes + ' PIPES';

        if (this.capturing || this.streaming) {
            const totalKbps = this.carriers.reduce((s, c) => s + (c.active ? c.kbps : 0), 0);
            document.getElementById('cs-bitrate').textContent = totalKbps + ' kbps';
            document.getElementById('cs-latency').textContent = (4 + Math.floor(Math.random() * 12)) + ' ms';
            const progress = Math.min(100, (this.elapsed / 30000) * 100);
            document.getElementById('cloud-bar').style.width = progress + '%';
        }
    },

    // Animation
    startAnimLoop() {
        const loop = (t) => {
            this.drawMap();
            this.drawCamera(t);
            this.animFrame = requestAnimationFrame(loop);
        };
        this.animFrame = requestAnimationFrame(loop);
    },

    // Helpers
    formatBytes(b) {
        if (b < 1024) return b + ' B';
        if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
        if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB';
        return (b / 1073741824).toFixed(2) + ' GB';
    },

    formatElapsed(ms) {
        const s = Math.floor(ms / 1000);
        const m = Math.floor(s / 60);
        const sec = s % 60;
        const tenth = Math.floor((ms % 1000) / 100);
        return m.toString().padStart(2, '0') + ':' + sec.toString().padStart(2, '0') + '.' + tenth;
    },

    formatTime(ts) {
        const d = new Date(ts);
        return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
    }
};

document.addEventListener('DOMContentLoaded', () => FS.init());
