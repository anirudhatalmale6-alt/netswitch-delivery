// AI2ORBIT Property Development Cloud v1.0.0
// FMA Engineering 2026 - US Market

const App = {
    properties: [],
    media: [],
    currentProperty: null,
    nextId: 1,
    nextMediaId: 1,

    init() {
        this.loadFromStorage();
        this.bindEvents();
        this.showPage('dashboard');
        this.updateStats();
        this.renderProperties();
    },

    // Navigation
    showPage(page) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        document.getElementById('page-' + page).classList.add('active');
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        if (page === 'dashboard') this.updateStats();
        if (page === 'properties') this.renderProperties();
        if (page === 'gallery') this.renderGallery();
    },

    // Floor Size Conversion (US default: sqft)
    SQM_TO_SQFT: 10.7639,

    convertSqmToSqft(sqm) {
        return Math.round(sqm * this.SQM_TO_SQFT * 100) / 100;
    },

    convertSqftToSqm(sqft) {
        return Math.round(sqft / this.SQM_TO_SQFT * 100) / 100;
    },

    formatSqft(sqft) {
        return new Intl.NumberFormat('en-US').format(Math.round(sqft)) + ' sqft';
    },

    formatSqm(sqm) {
        return sqm.toFixed(1) + ' m²';
    },

    formatUSD(amount) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(amount);
    },

    updateFloorCalc(source) {
        const sqmInput = document.getElementById('calc-sqm');
        const sqftInput = document.getElementById('calc-sqft');
        const resultDiv = document.getElementById('calc-result');

        if (source === 'sqm') {
            const sqm = parseFloat(sqmInput.value) || 0;
            const sqft = this.convertSqmToSqft(sqm);
            sqftInput.value = sqft > 0 ? Math.round(sqft) : '';
            if (sqm > 0) {
                resultDiv.textContent = this.formatSqm(sqm) + ' = ' + this.formatSqft(sqft);
            } else {
                resultDiv.textContent = '';
            }
        } else {
            const sqft = parseFloat(sqftInput.value) || 0;
            const sqm = this.convertSqftToSqm(sqft);
            sqmInput.value = sqm > 0 ? sqm.toFixed(1) : '';
            if (sqft > 0) {
                resultDiv.textContent = this.formatSqft(sqft) + ' = ' + this.formatSqm(sqm);
            } else {
                resultDiv.textContent = '';
            }
        }
    },

    // Dashboard Stats
    updateStats() {
        document.getElementById('stat-properties').textContent = this.properties.length;
        document.getElementById('stat-media').textContent = this.media.length;

        const totalSqft = this.properties.reduce((sum, p) => sum + (p.sqft || 0), 0);
        document.getElementById('stat-sqft').textContent = new Intl.NumberFormat('en-US').format(totalSqft);

        const totalValue = this.properties.reduce((sum, p) => sum + (p.price || 0), 0);
        document.getElementById('stat-value').textContent = this.formatUSD(totalValue);

        this.renderRecentProperties();
        this.renderRecentMedia();
    },

    renderRecentProperties() {
        const container = document.getElementById('recent-properties');
        const recent = this.properties.slice(-5).reverse();
        if (recent.length === 0) {
            container.innerHTML = '<p style="color:var(--text-light);padding:20px;text-align:center">No properties yet. Add your first property.</p>';
            return;
        }
        container.innerHTML = recent.map(p => `
            <div class="property-row" onclick="App.editProperty(${p.id})">
                <div class="property-thumb-small" style="background:linear-gradient(135deg,#dbeafe,#bfdbfe);display:flex;align-items:center;justify-content:center;font-size:20px">
                    ${this.getPropertyMediaThumb(p)}
                </div>
                <div class="property-details">
                    <div class="property-name">${this.escapeHtml(p.name)}</div>
                    <div class="property-address">${this.escapeHtml(p.address || 'No address')}</div>
                </div>
                <div class="property-size">
                    ${this.formatSqft(p.sqft || 0)}<br>
                    <span style="font-size:12px;color:var(--text-light)">${this.formatSqm(p.sqm || 0)}</span>
                </div>
            </div>
        `).join('');
    },

    getPropertyMediaThumb(p) {
        const propMedia = this.media.filter(m => m.propertyId === p.id);
        if (propMedia.length > 0 && propMedia[0].dataUrl) {
            return `<img src="${propMedia[0].dataUrl}" style="width:80px;height:60px;object-fit:cover;border-radius:6px">`;
        }
        return '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>';
    },

    renderRecentMedia() {
        const container = document.getElementById('recent-media');
        const recent = this.media.slice(-6).reverse();
        if (recent.length === 0) {
            container.innerHTML = '<p style="color:var(--text-light);padding:20px;text-align:center">No media uploaded yet.</p>';
            return;
        }
        container.innerHTML = '<div class="gallery">' + recent.map(m => this.renderGalleryItem(m)).join('') + '</div>';
    },

    // Properties CRUD
    showAddProperty() {
        this.currentProperty = null;
        document.getElementById('modal-property-title').textContent = 'Add New Property';
        document.getElementById('prop-name').value = '';
        document.getElementById('prop-address').value = '';
        document.getElementById('prop-city').value = '';
        document.getElementById('prop-state').value = '';
        document.getElementById('prop-zip').value = '';
        document.getElementById('prop-type').value = 'residential';
        document.getElementById('prop-sqft').value = '';
        document.getElementById('prop-sqm').value = '';
        document.getElementById('prop-price').value = '';
        document.getElementById('prop-beds').value = '';
        document.getElementById('prop-baths').value = '';
        document.getElementById('prop-status').value = 'active';
        document.getElementById('prop-notes').value = '';
        document.getElementById('modal-property').classList.add('active');
    },

    editProperty(id) {
        const p = this.properties.find(x => x.id === id);
        if (!p) return;
        this.currentProperty = p;
        document.getElementById('modal-property-title').textContent = 'Edit Property';
        document.getElementById('prop-name').value = p.name || '';
        document.getElementById('prop-address').value = p.address || '';
        document.getElementById('prop-city').value = p.city || '';
        document.getElementById('prop-state').value = p.state || '';
        document.getElementById('prop-zip').value = p.zip || '';
        document.getElementById('prop-type').value = p.type || 'residential';
        document.getElementById('prop-sqft').value = p.sqft || '';
        document.getElementById('prop-sqm').value = p.sqm || '';
        document.getElementById('prop-price').value = p.price || '';
        document.getElementById('prop-beds').value = p.beds || '';
        document.getElementById('prop-baths').value = p.baths || '';
        document.getElementById('prop-status').value = p.status || 'active';
        document.getElementById('prop-notes').value = p.notes || '';
        document.getElementById('modal-property').classList.add('active');
    },

    saveProperty() {
        const data = {
            name: document.getElementById('prop-name').value.trim(),
            address: document.getElementById('prop-address').value.trim(),
            city: document.getElementById('prop-city').value.trim(),
            state: document.getElementById('prop-state').value.trim(),
            zip: document.getElementById('prop-zip').value.trim(),
            type: document.getElementById('prop-type').value,
            sqft: parseFloat(document.getElementById('prop-sqft').value) || 0,
            sqm: parseFloat(document.getElementById('prop-sqm').value) || 0,
            price: parseFloat(document.getElementById('prop-price').value) || 0,
            beds: parseInt(document.getElementById('prop-beds').value) || 0,
            baths: parseFloat(document.getElementById('prop-baths').value) || 0,
            status: document.getElementById('prop-status').value,
            notes: document.getElementById('prop-notes').value.trim()
        };

        if (!data.name) { this.toast('Property name is required', true); return; }

        if (data.sqft > 0 && data.sqm === 0) {
            data.sqm = this.convertSqftToSqm(data.sqft);
        } else if (data.sqm > 0 && data.sqft === 0) {
            data.sqft = this.convertSqmToSqft(data.sqm);
        }

        if (this.currentProperty) {
            Object.assign(this.currentProperty, data);
            this.currentProperty.updated = new Date().toISOString();
            this.toast('Property updated');
        } else {
            data.id = this.nextId++;
            data.created = new Date().toISOString();
            data.updated = data.created;
            this.properties.push(data);
            this.toast('Property added');
        }

        this.closeModal('modal-property');
        this.saveToStorage();
        this.renderProperties();
        this.updateStats();
    },

    deleteProperty(id) {
        if (!confirm('Delete this property and all associated media?')) return;
        this.properties = this.properties.filter(p => p.id !== id);
        this.media = this.media.filter(m => m.propertyId !== id);
        this.saveToStorage();
        this.renderProperties();
        this.updateStats();
        this.toast('Property deleted');
    },

    renderProperties() {
        const container = document.getElementById('property-list');
        if (this.properties.length === 0) {
            container.innerHTML = '<p style="color:var(--text-light);padding:40px;text-align:center">No properties added yet. Click "Add Property" to get started.</p>';
            return;
        }

        container.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Property</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Size (sqft)</th>
                        <th>Size (m2)</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Media</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.properties.map(p => {
                        const mediaCount = this.media.filter(m => m.propertyId === p.id).length;
                        const statusClass = p.status === 'active' ? 'badge-active' : p.status === 'pending' ? 'badge-pending' : 'badge-sold';
                        return `
                            <tr>
                                <td><strong>${this.escapeHtml(p.name)}</strong></td>
                                <td>${this.escapeHtml((p.address ? p.address + ', ' : '') + (p.city || '') + (p.state ? ', ' + p.state : ''))}</td>
                                <td style="text-transform:capitalize">${p.type || '-'}</td>
                                <td>${p.sqft ? new Intl.NumberFormat('en-US').format(Math.round(p.sqft)) : '-'}</td>
                                <td>${p.sqm ? p.sqm.toFixed(1) : '-'}</td>
                                <td>${p.price ? this.formatUSD(p.price) : '-'}</td>
                                <td><span class="badge ${statusClass}">${p.status || 'active'}</span></td>
                                <td>${mediaCount} files</td>
                                <td>
                                    <button class="btn btn-sm btn-outline" onclick="App.editProperty(${p.id})">Edit</button>
                                    <button class="btn btn-sm btn-danger" onclick="App.deleteProperty(${p.id})" style="margin-left:4px">Del</button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
    },

    // Property form sqft/sqm sync
    propSqftChanged() {
        const sqft = parseFloat(document.getElementById('prop-sqft').value) || 0;
        if (sqft > 0) {
            document.getElementById('prop-sqm').value = this.convertSqftToSqm(sqft).toFixed(1);
        }
    },

    propSqmChanged() {
        const sqm = parseFloat(document.getElementById('prop-sqm').value) || 0;
        if (sqm > 0) {
            document.getElementById('prop-sqft').value = Math.round(this.convertSqmToSqft(sqm));
        }
    },

    // Media Upload
    handleFileDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('upload-zone').classList.remove('dragover');
        const files = e.dataTransfer ? e.dataTransfer.files : e.target.files;
        if (files) this.processFiles(files);
    },

    handleDragOver(e) {
        e.preventDefault();
        document.getElementById('upload-zone').classList.add('dragover');
    },

    handleDragLeave() {
        document.getElementById('upload-zone').classList.remove('dragover');
    },

    processFiles(files) {
        const propertyId = parseInt(document.getElementById('upload-property').value) || 0;

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const isImage = file.type.startsWith('image/');
            const isVideo = file.type.startsWith('video/');

            if (!isImage && !isVideo) {
                this.toast('Skipped ' + file.name + ' - only images and videos allowed', true);
                continue;
            }

            if (file.size > 50 * 1024 * 1024) {
                this.toast('Skipped ' + file.name + ' - max 50MB per file', true);
                continue;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const mediaItem = {
                    id: this.nextMediaId++,
                    propertyId: propertyId,
                    name: file.name,
                    type: isImage ? 'photo' : 'video',
                    mimeType: file.type,
                    size: file.size,
                    dataUrl: e.target.result,
                    uploaded: new Date().toISOString(),
                    tags: []
                };
                this.media.push(mediaItem);
                this.saveToStorage();
                this.renderGallery();
                this.updateStats();
                this.toast(file.name + ' uploaded');
            };
            reader.readAsDataURL(file);
        }
    },

    renderGallery() {
        const container = document.getElementById('gallery-grid');
        const filterProp = document.getElementById('gallery-filter-property');
        const filterType = document.getElementById('gallery-filter-type');

        // Populate property filter
        if (filterProp) {
            const current = filterProp.value;
            filterProp.innerHTML = '<option value="all">All Properties</option>' +
                this.properties.map(p => `<option value="${p.id}">${this.escapeHtml(p.name)}</option>`).join('');
            filterProp.value = current || 'all';
        }

        // Populate upload property selector
        const uploadProp = document.getElementById('upload-property');
        if (uploadProp) {
            const current = uploadProp.value;
            uploadProp.innerHTML = '<option value="0">No property (general)</option>' +
                this.properties.map(p => `<option value="${p.id}">${this.escapeHtml(p.name)}</option>`).join('');
            uploadProp.value = current || '0';
        }

        let filtered = [...this.media];
        if (filterProp && filterProp.value !== 'all') {
            filtered = filtered.filter(m => m.propertyId === parseInt(filterProp.value));
        }
        if (filterType && filterType.value !== 'all') {
            filtered = filtered.filter(m => m.type === filterType.value);
        }

        if (filtered.length === 0) {
            container.innerHTML = '<p style="color:var(--text-light);padding:40px;text-align:center;grid-column:1/-1">No media files. Drag and drop photos or videos above.</p>';
            return;
        }

        container.innerHTML = filtered.map(m => this.renderGalleryItem(m)).join('');
    },

    renderGalleryItem(m) {
        const sizeStr = m.size > 1024*1024 ? (m.size/1024/1024).toFixed(1) + ' MB' : Math.round(m.size/1024) + ' KB';
        const propName = m.propertyId ? (this.properties.find(p => p.id === m.propertyId) || {}).name || '' : '';
        const thumb = m.type === 'photo'
            ? `<img class="gallery-thumb" src="${m.dataUrl}" alt="${this.escapeHtml(m.name)}">`
            : `<video class="gallery-thumb" src="${m.dataUrl}" muted></video>`;

        return `
            <div class="gallery-item" onclick="App.openLightbox(${m.id})">
                ${thumb}
                <span class="gallery-badge">${m.type === 'photo' ? 'IMG' : 'VID'}</span>
                <button class="gallery-delete" onclick="event.stopPropagation();App.deleteMedia(${m.id})">x</button>
                <div class="gallery-info">
                    <div class="gallery-name">${this.escapeHtml(m.name)}</div>
                    <div class="gallery-meta">${sizeStr}${propName ? ' | ' + this.escapeHtml(propName) : ''}</div>
                </div>
            </div>
        `;
    },

    deleteMedia(id) {
        this.media = this.media.filter(m => m.id !== id);
        this.saveToStorage();
        this.renderGallery();
        this.updateStats();
        this.toast('Media deleted');
    },

    openLightbox(id) {
        const m = this.media.find(x => x.id === id);
        if (!m) return;
        const lb = document.getElementById('lightbox');
        const content = document.getElementById('lightbox-content');
        if (m.type === 'photo') {
            content.innerHTML = `<img src="${m.dataUrl}" alt="${this.escapeHtml(m.name)}">`;
        } else {
            content.innerHTML = `<video src="${m.dataUrl}" controls autoplay style="max-width:90%;max-height:90vh;border-radius:8px"></video>`;
        }
        lb.classList.add('active');
    },

    closeLightbox() {
        const lb = document.getElementById('lightbox');
        lb.classList.remove('active');
        document.getElementById('lightbox-content').innerHTML = '';
    },

    // Modal
    closeModal(id) {
        document.getElementById(id).classList.remove('active');
    },

    // Storage
    saveToStorage() {
        try {
            localStorage.setItem('propcloud_properties', JSON.stringify(this.properties));
            localStorage.setItem('propcloud_media', JSON.stringify(this.media));
            localStorage.setItem('propcloud_nextId', this.nextId);
            localStorage.setItem('propcloud_nextMediaId', this.nextMediaId);
        } catch(e) {
            console.warn('Storage full or unavailable');
        }
    },

    loadFromStorage() {
        try {
            const props = localStorage.getItem('propcloud_properties');
            const media = localStorage.getItem('propcloud_media');
            if (props) this.properties = JSON.parse(props);
            if (media) this.media = JSON.parse(media);
            this.nextId = parseInt(localStorage.getItem('propcloud_nextId')) || (this.properties.length > 0 ? Math.max(...this.properties.map(p=>p.id)) + 1 : 1);
            this.nextMediaId = parseInt(localStorage.getItem('propcloud_nextMediaId')) || (this.media.length > 0 ? Math.max(...this.media.map(m=>m.id)) + 1 : 1);
        } catch(e) {
            console.warn('Could not load from storage');
        }
    },

    // Load demo data
    loadDemo() {
        this.properties = [
            { id: 1, name: 'Oakwood Residence', address: '1420 Oak Street', city: 'Austin', state: 'TX', zip: '78701', type: 'residential', sqft: 1670, sqm: 155.1, price: 425000, beds: 3, baths: 2, status: 'active', notes: 'Corner lot, recently renovated', created: new Date().toISOString(), updated: new Date().toISOString() },
            { id: 2, name: 'Sunset Commercial Plaza', address: '880 Sunset Blvd', city: 'Los Angeles', state: 'CA', zip: '90028', type: 'commercial', sqft: 4500, sqm: 418.1, price: 1200000, beds: 0, baths: 4, status: 'active', notes: 'Multi-tenant retail space', created: new Date().toISOString(), updated: new Date().toISOString() },
            { id: 3, name: 'Pine Valley Lot', address: '250 Pine Valley Dr', city: 'Denver', state: 'CO', zip: '80202', type: 'land', sqft: 8750, sqm: 812.9, price: 180000, beds: 0, baths: 0, status: 'pending', notes: 'Zoned for residential development', created: new Date().toISOString(), updated: new Date().toISOString() },
            { id: 4, name: 'Harbor View Condo', address: '55 Harbor Way #12', city: 'Miami', state: 'FL', zip: '33130', type: 'residential', sqft: 1200, sqm: 111.5, price: 350000, beds: 2, baths: 2, status: 'active', notes: 'Ocean view, pool access', created: new Date().toISOString(), updated: new Date().toISOString() },
            { id: 5, name: 'Industrial Park B3', address: '4400 Commerce Ave', city: 'Houston', state: 'TX', zip: '77001', type: 'industrial', sqft: 15000, sqm: 1393.5, price: 750000, beds: 0, baths: 2, status: 'sold', notes: 'Warehouse with loading docks', created: new Date().toISOString(), updated: new Date().toISOString() }
        ];
        this.nextId = 6;
        this.media = [];
        this.nextMediaId = 1;
        this.saveToStorage();
        this.showPage('dashboard');
        this.toast('Demo data loaded - 5 properties');
    },

    // Toast notification
    toast(msg, isError) {
        const container = document.getElementById('toast-container');
        const el = document.createElement('div');
        el.className = 'toast' + (isError ? ' error' : '');
        el.textContent = msg;
        container.appendChild(el);
        setTimeout(() => el.remove(), 3000);
    },

    // Utility
    escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    },

    // Export data
    exportData() {
        const data = {
            exported: new Date().toISOString(),
            properties: this.properties,
            mediaCount: this.media.length
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'property-cloud-export.json';
        a.click();
        URL.revokeObjectURL(url);
        this.toast('Data exported');
    }
};

document.addEventListener('DOMContentLoaded', () => App.init());
