// AI2ORBIT SW Tester - ZIP file reader (APK/AAB validation)
#ifndef SW_ZIP_H
#define SW_ZIP_H

#include "sw_types.h"
#include <fstream>
#include <cstring>

namespace swt {

class ZipReader {
    // ZIP local file header signature
    static constexpr uint32_t LOCAL_SIG = 0x04034b50;
    // ZIP central directory signature
    static constexpr uint32_t CENTRAL_SIG = 0x02014b50;
    // ZIP end of central directory signature
    static constexpr uint32_t END_SIG = 0x06054b50;

    static uint16_t read16(const uint8_t* p) { return uint16_t(p[0]) | (uint16_t(p[1]) << 8); }
    static uint32_t read32(const uint8_t* p) { return uint32_t(p[0]) | (uint32_t(p[1])<<8) | (uint32_t(p[2])<<16) | (uint32_t(p[3])<<24); }

public:
    struct ZipInfo {
        std::vector<ZipEntry> entries;
        uint64_t archive_size;
        uint16_t total_entries;
        bool valid;
        std::string error;
    };

    ZipInfo read(const std::string& path) {
        ZipInfo info;
        info.valid = false;

        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f.is_open()) { info.error = "Cannot open file"; return info; }

        info.archive_size = f.tellg();
        if (info.archive_size < 22) { info.error = "Too small for ZIP"; return info; }

        // Find EOCD
        f.seekg(0);
        std::vector<uint8_t> data(info.archive_size);
        f.read(reinterpret_cast<char*>(data.data()), info.archive_size);

        int64_t eocd_pos = -1;
        for (int64_t i = int64_t(info.archive_size) - 22; i >= 0 && i >= int64_t(info.archive_size) - 65557; i--) {
            if (read32(&data[i]) == END_SIG) { eocd_pos = i; break; }
        }

        if (eocd_pos < 0) { info.error = "No EOCD found"; return info; }

        info.total_entries = read16(&data[eocd_pos + 10]);
        uint32_t cd_size = read32(&data[eocd_pos + 12]);
        uint32_t cd_offset = read32(&data[eocd_pos + 16]);

        if (cd_offset + cd_size > info.archive_size) { info.error = "CD offset out of bounds"; return info; }

        // Read central directory
        uint32_t pos = cd_offset;
        for (uint16_t i = 0; i < info.total_entries && pos + 46 <= info.archive_size; i++) {
            if (read32(&data[pos]) != CENTRAL_SIG) break;

            ZipEntry entry;
            entry.compression = read16(&data[pos + 10]);
            entry.crc32 = read32(&data[pos + 16]);
            entry.compressed_size = read32(&data[pos + 20]);
            entry.uncompressed_size = read32(&data[pos + 24]);
            uint16_t name_len = read16(&data[pos + 28]);
            uint16_t extra_len = read16(&data[pos + 30]);
            uint16_t comment_len = read16(&data[pos + 32]);

            if (pos + 46 + name_len <= info.archive_size)
                entry.name = std::string(reinterpret_cast<char*>(&data[pos + 46]), name_len);

            info.entries.push_back(entry);
            pos += 46 + name_len + extra_len + comment_len;
        }

        info.valid = true;
        return info;
    }

    // Check if file is valid ZIP
    bool is_zip(const std::string& path) {
        std::ifstream f(path, std::ios::binary);
        if (!f.is_open()) return false;
        uint8_t sig[4];
        f.read(reinterpret_cast<char*>(sig), 4);
        return f.gcount() == 4 && read32(sig) == LOCAL_SIG;
    }

    // Check if APK (ZIP with AndroidManifest.xml)
    bool is_apk(const ZipInfo& info) {
        for (auto& e : info.entries)
            if (e.name == "AndroidManifest.xml") return true;
        return false;
    }

    // Check if AAB (ZIP with BundleConfig.pb or base/manifest/)
    bool is_aab(const ZipInfo& info) {
        for (auto& e : info.entries) {
            if (e.name == "BundleConfig.pb") return true;
            if (e.name.find("base/manifest/") == 0) return true;
        }
        return false;
    }

    // Find entry by name
    const ZipEntry* find_entry(const ZipInfo& info, const std::string& name) {
        for (auto& e : info.entries)
            if (e.name == name) return &e;
        return nullptr;
    }

    // Check for required APK entries
    struct APKValidation {
        bool has_manifest;
        bool has_dex;
        bool has_resources;
        bool has_meta_inf;
        bool has_res;
        int dex_count;
        int resource_count;
        int lib_count;
        std::vector<std::string> architectures;
    };

    APKValidation validate_apk(const ZipInfo& info) {
        APKValidation v = {};
        for (auto& e : info.entries) {
            if (e.name == "AndroidManifest.xml") v.has_manifest = true;
            if (e.name.find("classes") == 0 && e.name.find(".dex") != std::string::npos)
                { v.has_dex = true; v.dex_count++; }
            if (e.name == "resources.arsc") v.has_resources = true;
            if (e.name.find("META-INF/") == 0) v.has_meta_inf = true;
            if (e.name.find("res/") == 0) { v.has_res = true; v.resource_count++; }
            if (e.name.find("lib/") == 0) {
                v.lib_count++;
                size_t s = 4, e2 = e.name.find('/', 4);
                if (e2 != std::string::npos) {
                    std::string arch = e.name.substr(s, e2 - s);
                    bool found = false;
                    for (auto& a : v.architectures)
                        if (a == arch) { found = true; break; }
                    if (!found) v.architectures.push_back(arch);
                }
            }
        }
        return v;
    }
};

} // namespace swt
#endif
