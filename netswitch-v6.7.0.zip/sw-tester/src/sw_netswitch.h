// AI2ORBIT SW Tester - NetSwitch product verification
#ifndef SW_NETSWITCH_H
#define SW_NETSWITCH_H

#include "sw_types.h"
#include "sw_checksum.h"
#include "sw_zip.h"
#include <filesystem>
#include <algorithm>

namespace swt {
namespace fs = std::filesystem;

class NetSwitchTester {
    std::vector<TestResult> results_;
    ByteAnalyzer analyzer_;
    ZipReader zip_;

    void check(const std::string& cat, const std::string& name, bool cond,
               const std::string& expected = "", const std::string& actual = "", const std::string& detail = "") {
        results_.push_back({Product::NETSWITCH, cat, name,
            cond ? TestStatus::PASS : TestStatus::FAIL, expected, actual, detail});
    }

    void warn(const std::string& cat, const std::string& name, const std::string& detail) {
        results_.push_back({Product::NETSWITCH, cat, name, TestStatus::WARN, "", "", detail});
    }

    void skip(const std::string& cat, const std::string& name, const std::string& detail) {
        results_.push_back({Product::NETSWITCH, cat, name, TestStatus::SKIP, "", "", detail});
    }

public:
    // Test APK structure byte by byte
    void test_apk(const std::string& path) {
        if (!fs::exists(path)) { skip("APK", "File exists", path + " not found"); return; }

        auto stat = analyzer_.analyze_file(path);
        check("APK-BYTE", "File readable", stat.file_size > 0, ">0", std::to_string(stat.file_size));
        check("APK-BYTE", "Size > 1MB", stat.file_size > 1024 * 1024,
              ">1MB", std::to_string(stat.file_size / 1024) + "KB");
        check("APK-BYTE", "CRC32 computed", stat.crc32 != 0);
        check("APK-BYTE", "SHA256 computed", !stat.sha256.empty(), "64 hex chars", stat.sha256);
        check("APK-BYTE", "Has binary content", stat.has_null_bytes);
        check("APK-BYTE", "Entropy > 5.5 (binary)", stat.entropy > 5.5,
              ">5.5", std::to_string(stat.entropy));

        // ZIP structure validation
        auto info = zip_.read(path);
        check("APK-ZIP", "Valid ZIP", info.valid, "true", info.valid ? "true" : info.error);
        if (!info.valid) return;

        check("APK-ZIP", "Entry count > 100", info.entries.size() > 100,
              ">100", std::to_string(info.entries.size()));

        auto apk_v = zip_.validate_apk(info);
        check("APK-STRUCT", "AndroidManifest.xml", apk_v.has_manifest);
        check("APK-STRUCT", "classes.dex present", apk_v.has_dex);
        check("APK-STRUCT", "DEX count", apk_v.dex_count > 0, ">0", std::to_string(apk_v.dex_count));
        check("APK-STRUCT", "resources.arsc", apk_v.has_resources);
        check("APK-STRUCT", "META-INF (signing)", apk_v.has_meta_inf);
        check("APK-STRUCT", "res/ directory", apk_v.has_res);
        check("APK-STRUCT", "Resource count", apk_v.resource_count > 10,
              ">10", std::to_string(apk_v.resource_count));

        // Check for native libs
        if (apk_v.lib_count > 0) {
            std::string arches;
            for (auto& a : apk_v.architectures) arches += a + " ";
            check("APK-STRUCT", "Native libraries", true, "", arches);
        }

        // Check entry CRC integrity
        int crc_ok = 0;
        for (auto& e : info.entries) {
            if (e.uncompressed_size > 0 && e.crc32 != 0) crc_ok++;
        }
        check("APK-BYTE", "Entries with CRC", crc_ok > 0, ">0", std::to_string(crc_ok));

        // Check DEX magic bytes would be 'dex\n035\0' or 'dex\n039\0'
        // We check the entry exists and has reasonable size
        for (auto& e : info.entries) {
            if (e.name.find("classes") == 0 && e.name.find(".dex") != std::string::npos) {
                check("APK-DEX", "DEX " + e.name + " size", e.uncompressed_size > 1000,
                      ">1KB", std::to_string(e.uncompressed_size));
            }
        }
    }

    // Test AAB structure
    void test_aab(const std::string& path) {
        if (!fs::exists(path)) { skip("AAB", "File exists", path + " not found"); return; }

        auto stat = analyzer_.analyze_file(path);
        check("AAB-BYTE", "File readable", stat.file_size > 0);
        check("AAB-BYTE", "SHA256", !stat.sha256.empty(), "64 chars", stat.sha256);
        check("AAB-BYTE", "Entropy > 6", stat.entropy > 6.0, ">6.0", std::to_string(stat.entropy));

        auto info = zip_.read(path);
        check("AAB-ZIP", "Valid ZIP", info.valid, "true", info.valid ? "true" : info.error);
        if (!info.valid) return;

        bool has_bundle_config = false;
        bool has_base = false;
        bool has_base_dex = false;
        bool has_base_manifest = false;
        bool has_base_res = false;

        for (auto& e : info.entries) {
            if (e.name == "BundleConfig.pb") has_bundle_config = true;
            if (e.name.find("base/") == 0) has_base = true;
            if (e.name.find("base/dex/") == 0) has_base_dex = true;
            if (e.name.find("base/manifest/") == 0) has_base_manifest = true;
            if (e.name.find("base/res/") == 0) has_base_res = true;
        }

        check("AAB-STRUCT", "BundleConfig.pb", has_bundle_config);
        check("AAB-STRUCT", "base/ module", has_base);
        check("AAB-STRUCT", "base/dex/", has_base_dex);
        check("AAB-STRUCT", "base/manifest/", has_base_manifest);
        check("AAB-STRUCT", "base/res/", has_base_res);
    }

    // Test source code package
    void test_source(const std::string& path) {
        if (!fs::exists(path)) { skip("SRC", "File exists", path + " not found"); return; }

        auto info = zip_.read(path);
        check("SRC-ZIP", "Valid ZIP", info.valid);
        if (!info.valid) return;

        bool has_java = false, has_kotlin = false, has_xml = false, has_gradle = false;
        int java_count = 0, kotlin_count = 0, xml_count = 0;

        for (auto& e : info.entries) {
            if (e.name.find(".java") != std::string::npos) { has_java = true; java_count++; }
            if (e.name.find(".kt") != std::string::npos) { has_kotlin = true; kotlin_count++; }
            if (e.name.find(".xml") != std::string::npos) { has_xml = true; xml_count++; }
            if (e.name.find("build.gradle") != std::string::npos) has_gradle = true;
        }

        check("SRC-STRUCT", "Java/Kotlin sources", has_java || has_kotlin,
              "Java or Kotlin", has_java ? "Java(" + std::to_string(java_count) + ")" :
                                has_kotlin ? "Kotlin(" + std::to_string(kotlin_count) + ")" : "none");
        check("SRC-STRUCT", "XML resources", has_xml, ">0", std::to_string(xml_count));
        check("SRC-STRUCT", "build.gradle", has_gradle);
    }

    // Version consistency across builds
    void test_version_consistency(const std::vector<std::string>& apk_paths) {
        if (apk_paths.empty()) { skip("VERSION", "APKs available", "No APKs"); return; }

        std::vector<std::pair<std::string, uint64_t>> sizes;
        for (auto& p : apk_paths) {
            if (fs::exists(p)) {
                auto stat = analyzer_.analyze_file(p);
                sizes.push_back({p, stat.file_size});
            }
        }

        check("VERSION", "Multiple versions exist", sizes.size() > 1,
              ">1", std::to_string(sizes.size()));

        // Check that each version has a unique checksum
        std::vector<uint32_t> crcs;
        for (auto& p : apk_paths) {
            if (fs::exists(p)) {
                auto crc = analyzer_.crc32().compute_file(p);
                bool duplicate = false;
                for (auto c : crcs) if (c == crc) duplicate = true;
                crcs.push_back(crc);
                if (duplicate)
                    warn("VERSION", "Duplicate CRC", p);
            }
        }
        check("VERSION", "All versions unique", crcs.size() == sizes.size());
    }

    std::vector<TestResult>& results() { return results_; }
};

} // namespace swt
#endif
