// AI2ORBIT SW Tester - QCV 14.02 assembler verification
#ifndef SW_QCV_H
#define SW_QCV_H

#include "sw_types.h"
#include "sw_checksum.h"
#include "sw_zip.h"
#include <cmath>
#include <cfloat>
#include <climits>
#include <filesystem>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif

namespace swt {
namespace fs = std::filesystem;

class QCVTester {
    std::vector<TestResult> results_;
    ByteAnalyzer analyzer_;
    ZipReader zip_;

    void check(const std::string& cat, const std::string& name, bool cond,
               const std::string& expected = "", const std::string& actual = "") {
        results_.push_back({Product::QCV, cat, name,
            cond ? TestStatus::PASS : TestStatus::FAIL, expected, actual, ""});
    }

    bool approx(double a, double b, double tol = 1e-9) {
        if (std::isnan(a) && std::isnan(b)) return true;
        if (std::isinf(a) && std::isinf(b)) return (a > 0) == (b > 0);
        return std::fabs(a - b) < tol;
    }

    std::string fmt(double v) {
        std::ostringstream s;
        s << std::setprecision(15) << v;
        return s.str();
    }

public:
    // Source package structure verification
    void test_source_package(const std::string& zip_path) {
        if (!fs::exists(zip_path)) { return; }

        auto info = zip_.read(zip_path);
        check("QCV-PKG", "Valid ZIP", info.valid);
        if (!info.valid) return;

        bool has_types = false, has_lexer = false, has_parser = false;
        bool has_codegen = false, has_optimizer = false, has_linker = false;
        bool has_vm = false, has_verify = false, has_compiler = false;
        bool has_cmake = false;
        int test_count = 0;

        for (auto& e : info.entries) {
            if (e.name.find("qcv_types.h") != std::string::npos) has_types = true;
            if (e.name.find("qcv_lexer.h") != std::string::npos) has_lexer = true;
            if (e.name.find("qcv_parser.h") != std::string::npos) has_parser = true;
            if (e.name.find("qcv_codegen.h") != std::string::npos) has_codegen = true;
            if (e.name.find("qcv_optimizer.h") != std::string::npos) has_optimizer = true;
            if (e.name.find("qcv_linker.h") != std::string::npos) has_linker = true;
            if (e.name.find("qcv_vm.h") != std::string::npos) has_vm = true;
            if (e.name.find("qcv_verify.h") != std::string::npos) has_verify = true;
            if (e.name.find("qcv_compiler.cpp") != std::string::npos) has_compiler = true;
            if (e.name.find("CMakeLists.txt") != std::string::npos) has_cmake = true;
            if (e.name.find(".qcv") != std::string::npos) test_count++;
        }

        check("QCV-PKG", "qcv_types.h", has_types);
        check("QCV-PKG", "qcv_lexer.h", has_lexer);
        check("QCV-PKG", "qcv_parser.h", has_parser);
        check("QCV-PKG", "qcv_codegen.h", has_codegen);
        check("QCV-PKG", "qcv_optimizer.h", has_optimizer);
        check("QCV-PKG", "qcv_linker.h", has_linker);
        check("QCV-PKG", "qcv_vm.h", has_vm);
        check("QCV-PKG", "qcv_verify.h", has_verify);
        check("QCV-PKG", "qcv_compiler.cpp", has_compiler);
        check("QCV-PKG", "CMakeLists.txt", has_cmake);
        check("QCV-PKG", "Test programs (>=5)", test_count >= 5, ">=5", std::to_string(test_count));
    }

    // Binary verification of compiled QCV
    void test_binary(const std::string& bin_path) {
        if (!fs::exists(bin_path)) { return; }

        auto stat = analyzer_.analyze_file(bin_path);
        check("QCV-BIN", "Binary size > 100KB", stat.file_size > 100000,
              ">100KB", std::to_string(stat.file_size / 1024) + "KB");
        check("QCV-BIN", "SHA256", !stat.sha256.empty(), "64 chars", stat.sha256);
        check("QCV-BIN", "Has binary content", stat.has_null_bytes);
        check("QCV-BIN", "Entropy > 5", stat.entropy > 5.0, ">5.0", fmt(stat.entropy));

        // Check ELF or PE header
        std::ifstream f(bin_path, std::ios::binary);
        uint8_t magic[4];
        f.read(reinterpret_cast<char*>(magic), 4);
        bool is_elf = (magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F');
        bool is_pe = (magic[0] == 'M' && magic[1] == 'Z');
        check("QCV-BIN", "Valid executable (ELF/PE)", is_elf || is_pe,
              "ELF or PE", is_elf ? "ELF" : is_pe ? "PE" : "unknown");
    }

    // IEEE 754 compliance (independent of QCV verify)
    void test_ieee754() {
        check("QCV-IEEE", "sizeof(double)==8", sizeof(double) == 8, "8", std::to_string(sizeof(double)));
        check("QCV-IEEE", "sizeof(float)==4", sizeof(float) == 4, "4", std::to_string(sizeof(float)));
        check("QCV-IEEE", "sizeof(int64)==8", sizeof(int64_t) == 8, "8", std::to_string(sizeof(int64_t)));
        check("QCV-IEEE", "NaN != NaN", std::isnan(NAN) && !(NAN == NAN));
        check("QCV-IEEE", "Inf arithmetic", std::isinf(INFINITY + 1.0));
        check("QCV-IEEE", "-Inf < Inf", -INFINITY < INFINITY);
        check("QCV-IEEE", "DBL_EPSILON < 1e-15", DBL_EPSILON < 1e-15, "<1e-15", fmt(DBL_EPSILON));
        check("QCV-IEEE", "DBL_MAX > 1e308", DBL_MAX > 1e308);

        volatile double ov = DBL_MAX;
        ov *= 2.0;
        check("QCV-IEEE", "Overflow -> Inf", std::isinf(ov));

        volatile double uv = DBL_MIN;
        uv /= DBL_MAX;
        check("QCV-IEEE", "Underflow -> 0/denorm", uv >= 0.0 && uv < DBL_MIN);

        double a = 1.0 / 3.0;
        check("QCV-IEEE", "1/3 precision", approx(a * 3.0, 1.0, 1e-15), "1.0", fmt(a * 3.0));
    }

    // Trigonometric math verification
    void test_trig() {
        check("QCV-TRIG", "sin(0)=0", approx(std::sin(0.0), 0.0));
        check("QCV-TRIG", "sin(pi/2)=1", approx(std::sin(M_PI/2.0), 1.0));
        check("QCV-TRIG", "sin(pi)=0", approx(std::sin(M_PI), 0.0, 1e-12));
        check("QCV-TRIG", "cos(0)=1", approx(std::cos(0.0), 1.0));
        check("QCV-TRIG", "cos(pi)=-1", approx(std::cos(M_PI), -1.0));
        check("QCV-TRIG", "tan(pi/4)=1", approx(std::tan(M_PI/4.0), 1.0));

        for (double deg = 0; deg <= 360; deg += 30) {
            double r = deg * M_PI / 180.0;
            double s = std::sin(r), c = std::cos(r);
            check("QCV-TRIG", "sin^2+cos^2=1 @" + std::to_string(int(deg)),
                  approx(s*s + c*c, 1.0));
        }

        check("QCV-TRIG", "asin(1)=pi/2", approx(std::asin(1.0), M_PI/2.0));
        check("QCV-TRIG", "atan2(1,1)=pi/4", approx(std::atan2(1.0, 1.0), M_PI/4.0));
        check("QCV-TRIG", "sinh(0)=0", approx(std::sinh(0.0), 0.0));
        check("QCV-TRIG", "cosh(0)=1", approx(std::cosh(0.0), 1.0));
        check("QCV-TRIG", "cosh^2-sinh^2=1", approx(std::cosh(1.0)*std::cosh(1.0) - std::sinh(1.0)*std::sinh(1.0), 1.0));
    }

    // Navigation math
    void test_navigation() {
        // Haversine
        auto haversine = [](double lat1, double lon1, double lat2, double lon2) {
            double R = 6371000.0;
            double dLat = (lat2-lat1)*M_PI/180.0, dLon = (lon2-lon1)*M_PI/180.0;
            double a = std::sin(dLat/2)*std::sin(dLat/2) +
                       std::cos(lat1*M_PI/180.0)*std::cos(lat2*M_PI/180.0)*
                       std::sin(dLon/2)*std::sin(dLon/2);
            return R * 2.0 * std::atan2(std::sqrt(a), std::sqrt(1-a));
        };

        double d = haversine(60.1699, 24.9384, 35.6762, 139.6503);
        check("QCV-NAV", "Helsinki-Tokyo ~7815km", d > 7700000 && d < 7900000,
              "~7815km", fmt(d/1000.0) + "km");
        check("QCV-NAV", "Zero distance", approx(haversine(0,0,0,0), 0.0, 1.0));

        // ISA atmosphere
        double p = 101325.0 * std::pow(1.0 - 2.25577e-5 * 10668.0, 5.25588);
        check("QCV-NAV", "FL350 pressure ~23800Pa", p > 23000 && p < 25000, "~23842Pa", fmt(p));

        // TAS from IAS
        double rho0 = 1.225, T0 = 288.15, L = 0.0065;
        double T = T0 - L * 10668.0;
        double rho = rho0 * std::pow(T / T0, 4.2559);
        double tas = 250.0 * std::sqrt(rho0 / rho);
        check("QCV-NAV", "TAS at FL350", tas > 400 && tas < 500, "~450KTAS", fmt(tas));

        double a_sound = std::sqrt(1.4 * 287.05 * T);
        double mach = (tas * 0.514444) / a_sound;
        check("QCV-NAV", "Mach at FL350", mach > 0.7 && mach < 0.9, "~0.78M", fmt(mach));
    }

    // Flight dynamics
    void test_flight() {
        double g = 9.80665;
        check("QCV-FLIGHT", "Standard gravity", approx(g, 9.80665));

        double a0 = std::sqrt(1.4 * 287.05 * 288.15);
        check("QCV-FLIGHT", "Speed of sound ISA", approx(a0, 340.294, 0.1), "340.294", fmt(a0));

        double T_trop = 288.15 - 0.0065 * 11000;
        check("QCV-FLIGHT", "Tropopause temp", approx(T_trop, 216.65, 0.01), "216.65K", fmt(T_trop));

        double rho = 1.225, V = 70.0, S = 16.0, CL = 1.5;
        double lift = 0.5 * rho * V * V * S * CL;
        check("QCV-FLIGHT", "Lift equation", lift > 70000 && lift < 75000, "~72030N", fmt(lift));

        double xwind = 20.0 * std::sin(30.0 * M_PI / 180.0);
        check("QCV-FLIGHT", "Crosswind component", approx(xwind, 10.0), "10", fmt(xwind));

        double hwind = 20.0 * std::cos(30.0 * M_PI / 180.0);
        check("QCV-FLIGHT", "Headwind component", approx(hwind, 17.3205, 0.001), "17.32", fmt(hwind));

        double descent = 70.0 * std::sin(3.0 * M_PI / 180.0);
        check("QCV-FLIGHT", "3deg glide slope", approx(descent, 3.66, 0.1), "~3.66m/s", fmt(descent));
    }

    // Matrix / quaternion math
    void test_matrix() {
        double theta = M_PI / 6;
        double Ry[3][3] = {
            {std::cos(theta), 0, std::sin(theta)},
            {0, 1, 0},
            {-std::sin(theta), 0, std::cos(theta)}
        };
        double det = Ry[0][0]*(Ry[1][1]*Ry[2][2]-Ry[1][2]*Ry[2][1])
                   - Ry[0][1]*(Ry[1][0]*Ry[2][2]-Ry[1][2]*Ry[2][0])
                   + Ry[0][2]*(Ry[1][0]*Ry[2][1]-Ry[1][1]*Ry[2][0]);
        check("QCV-MATRIX", "Rotation det=1", approx(det, 1.0), "1.0", fmt(det));

        double dot = 1*4 + 2*5 + 3*6;
        check("QCV-MATRIX", "Dot product", approx(dot, 32.0), "32", fmt(dot));

        double cx = 2*6 - 3*5, cy = 3*4 - 1*6, cz = 1*5 - 2*4;
        check("QCV-MATRIX", "Cross product", approx(cx, -3.0) && approx(cy, 6.0) && approx(cz, -3.0));

        double q[] = {0.5, 0.5, 0.5, 0.5};
        double qn = std::sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]);
        check("QCV-MATRIX", "Quaternion norm=1", approx(qn, 1.0), "1.0", fmt(qn));

        double roll=0.1, pitch=0.2, yaw=0.3;
        double cr=std::cos(roll/2), sr=std::sin(roll/2);
        double cp=std::cos(pitch/2), sp=std::sin(pitch/2);
        double cy2=std::cos(yaw/2), sy=std::sin(yaw/2);
        double qw=cr*cp*cy2+sr*sp*sy, qx=sr*cp*cy2-cr*sp*sy;
        double qy=cr*sp*cy2+sr*cp*sy, qz=cr*cp*sy-sr*sp*cy2;
        double qn2 = qw*qw+qx*qx+qy*qy+qz*qz;
        check("QCV-MATRIX", "Euler->Quat norm=1", approx(qn2, 1.0), "1.0", fmt(qn2));
    }

    // Integer boundary tests
    void test_integers() {
        check("QCV-INT", "INT64_MAX", INT64_MAX == 9223372036854775807LL);
        check("QCV-INT", "INT64_MIN", INT64_MIN == -9223372036854775807LL - 1);
        check("QCV-INT", "UINT64_MAX", UINT64_MAX == 18446744073709551615ULL);

        int64_t a = INT64_MAX - 1;
        check("QCV-INT", "MAX-1+1=MAX", a + 1 == INT64_MAX);

        uint64_t ua = 0;
        ua--;
        check("QCV-INT", "Unsigned wrap", ua == UINT64_MAX);
        check("QCV-INT", "Bit shift 1<<63", (1ULL << 63) == 9223372036854775808ULL);
    }

    // Log/exp math
    void test_log_exp() {
        check("QCV-LOGEXP", "log(1)=0", approx(std::log(1.0), 0.0));
        check("QCV-LOGEXP", "log(e)=1", approx(std::log(M_E), 1.0));
        check("QCV-LOGEXP", "log10(100)=2", approx(std::log10(100.0), 2.0));
        check("QCV-LOGEXP", "log2(1024)=10", approx(std::log2(1024.0), 10.0));
        check("QCV-LOGEXP", "exp(0)=1", approx(std::exp(0.0), 1.0));
        check("QCV-LOGEXP", "exp(1)=e", approx(std::exp(1.0), M_E));
        check("QCV-LOGEXP", "exp(log(42))=42", approx(std::exp(std::log(42.0)), 42.0));
        check("QCV-LOGEXP", "pow(2,10)=1024", approx(std::pow(2.0, 10.0), 1024.0));
        check("QCV-LOGEXP", "sqrt(144)=12", approx(std::sqrt(144.0), 12.0));
        check("QCV-LOGEXP", "cbrt(27)=3", approx(std::cbrt(27.0), 3.0));
        check("QCV-LOGEXP", "hypot(3,4)=5", approx(std::hypot(3.0, 4.0), 5.0));
    }

    std::vector<TestResult>& results() { return results_; }
};

} // namespace swt
#endif
