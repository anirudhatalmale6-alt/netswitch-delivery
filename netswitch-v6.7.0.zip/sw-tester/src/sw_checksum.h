// AI2ORBIT SW Tester - SHA-256, CRC32 byte-level verification
#ifndef SW_CHECKSUM_H
#define SW_CHECKSUM_H

#include "sw_types.h"
#include <fstream>
#include <cstring>
#include <cmath>

namespace swt {

class CRC32 {
    uint32_t table_[256];
public:
    CRC32() {
        for (uint32_t i = 0; i < 256; i++) {
            uint32_t c = i;
            for (int j = 0; j < 8; j++)
                c = (c & 1) ? (0xEDB88320 ^ (c >> 1)) : (c >> 1);
            table_[i] = c;
        }
    }

    uint32_t compute(const uint8_t* data, size_t len) const {
        uint32_t crc = 0xFFFFFFFF;
        for (size_t i = 0; i < len; i++)
            crc = table_[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
        return crc ^ 0xFFFFFFFF;
    }

    uint32_t compute_file(const std::string& path) const {
        std::ifstream f(path, std::ios::binary);
        if (!f.is_open()) return 0;
        uint32_t crc = 0xFFFFFFFF;
        uint8_t buf[8192];
        while (f.read(reinterpret_cast<char*>(buf), sizeof(buf)) || f.gcount() > 0) {
            auto n = static_cast<size_t>(f.gcount());
            for (size_t i = 0; i < n; i++)
                crc = table_[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
        }
        return crc ^ 0xFFFFFFFF;
    }
};

class SHA256 {
    static constexpr uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };

    static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
    static uint32_t ch(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (~x & z); }
    static uint32_t maj(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (x & z) ^ (y & z); }
    static uint32_t sig0(uint32_t x) { return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22); }
    static uint32_t sig1(uint32_t x) { return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25); }
    static uint32_t s0(uint32_t x) { return rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3); }
    static uint32_t s1(uint32_t x) { return rotr(x, 17) ^ rotr(x, 19) ^ (x >> 10); }

    void transform(uint32_t state[8], const uint8_t block[64]) {
        uint32_t W[64];
        for (int i = 0; i < 16; i++)
            W[i] = (uint32_t(block[i*4])<<24) | (uint32_t(block[i*4+1])<<16) |
                   (uint32_t(block[i*4+2])<<8) | uint32_t(block[i*4+3]);
        for (int i = 16; i < 64; i++)
            W[i] = s1(W[i-2]) + W[i-7] + s0(W[i-15]) + W[i-16];

        uint32_t a=state[0], b=state[1], c=state[2], d=state[3];
        uint32_t e=state[4], f=state[5], g=state[6], h=state[7];

        for (int i = 0; i < 64; i++) {
            uint32_t t1 = h + sig1(e) + ch(e,f,g) + K[i] + W[i];
            uint32_t t2 = sig0(a) + maj(a,b,c);
            h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        state[0]+=a; state[1]+=b; state[2]+=c; state[3]+=d;
        state[4]+=e; state[5]+=f; state[6]+=g; state[7]+=h;
    }

public:
    std::string compute(const uint8_t* data, size_t len) {
        uint32_t state[8] = {
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
        };

        size_t blocks = len / 64;
        for (size_t i = 0; i < blocks; i++)
            transform(state, data + i * 64);

        uint8_t last[128];
        std::memset(last, 0, sizeof(last));
        size_t rem = len % 64;
        std::memcpy(last, data + blocks * 64, rem);
        last[rem] = 0x80;

        size_t pad_blocks = (rem < 56) ? 1 : 2;
        size_t total = pad_blocks * 64;
        uint64_t bits = uint64_t(len) * 8;
        for (int i = 0; i < 8; i++)
            last[total - 1 - i] = uint8_t(bits >> (i * 8));

        for (size_t i = 0; i < pad_blocks; i++)
            transform(state, last + i * 64);

        std::ostringstream hex;
        for (int i = 0; i < 8; i++)
            hex << std::hex << std::setfill('0') << std::setw(8) << state[i];
        return hex.str();
    }

    std::string compute_file(const std::string& path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f.is_open()) return "";
        auto sz = f.tellg();
        f.seekg(0);
        std::vector<uint8_t> data(sz);
        f.read(reinterpret_cast<char*>(data.data()), sz);
        return compute(data.data(), data.size());
    }

    // Known test vectors
    bool self_test() {
        const uint8_t empty[] = {};
        std::string h = compute(empty, 0);
        return h == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    }
};

class ByteAnalyzer {
    CRC32 crc32_;
    SHA256 sha256_;

public:
    ByteStat analyze_file(const std::string& path) {
        ByteStat stat = {};
        for (int i = 0; i < 256; i++) stat.byte_histogram[i] = 0;

        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f.is_open()) return stat;

        stat.file_size = f.tellg();
        f.seekg(0);

        std::vector<uint8_t> data(stat.file_size);
        f.read(reinterpret_cast<char*>(data.data()), stat.file_size);

        stat.crc32 = crc32_.compute(data.data(), data.size());
        stat.sha256 = sha256_.compute(data.data(), data.size());
        stat.has_null_bytes = false;
        stat.printable_count = 0;
        stat.non_printable_count = 0;

        for (size_t i = 0; i < data.size(); i++) {
            stat.byte_histogram[data[i]]++;
            if (data[i] == 0) stat.has_null_bytes = true;
            if (data[i] >= 32 && data[i] <= 126) stat.printable_count++;
            else stat.non_printable_count++;
        }

        // Shannon entropy
        stat.entropy = 0.0;
        if (stat.file_size > 0) {
            for (int i = 0; i < 256; i++) {
                if (stat.byte_histogram[i] > 0) {
                    double p = double(stat.byte_histogram[i]) / double(stat.file_size);
                    stat.entropy -= p * std::log2(p);
                }
            }
        }
        return stat;
    }

    // Byte-by-byte comparison of two files
    struct DiffResult {
        uint64_t offset;
        uint8_t byte_a;
        uint8_t byte_b;
    };

    std::vector<DiffResult> compare_files(const std::string& a, const std::string& b, size_t max_diffs = 100) {
        std::vector<DiffResult> diffs;
        std::ifstream fa(a, std::ios::binary), fb(b, std::ios::binary);
        if (!fa.is_open() || !fb.is_open()) return diffs;

        uint8_t ba_buf[4096], bb_buf[4096];
        uint64_t offset = 0;

        while (fa && fb && diffs.size() < max_diffs) {
            fa.read(reinterpret_cast<char*>(ba_buf), sizeof(ba_buf));
            fb.read(reinterpret_cast<char*>(bb_buf), sizeof(bb_buf));
            auto na = fa.gcount(), nb = fb.gcount();
            auto n = std::min(na, nb);
            for (std::streamsize i = 0; i < n && diffs.size() < max_diffs; i++) {
                if (ba_buf[i] != bb_buf[i])
                    diffs.push_back({offset + uint64_t(i), ba_buf[i], bb_buf[i]});
            }
            offset += uint64_t(n);
            if (na != nb) {
                diffs.push_back({offset, uint8_t(na > nb ? ba_buf[n] : 0), uint8_t(na < nb ? bb_buf[n] : 0)});
                break;
            }
        }
        return diffs;
    }

    CRC32& crc32() { return crc32_; }
    SHA256& sha256() { return sha256_; }
};

} // namespace swt
#endif
