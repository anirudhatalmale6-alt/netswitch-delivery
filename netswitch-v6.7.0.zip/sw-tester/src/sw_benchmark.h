// AI2ORBIT SW Tester - Benchmark-AI-Constant verification
#ifndef SW_BENCHMARK_H
#define SW_BENCHMARK_H

#include "sw_types.h"
#include "sw_checksum.h"
#include "sw_zip.h"
#include <cmath>
#include <cfloat>
#include <filesystem>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif

namespace swt {
namespace fs = std::filesystem;

class BenchmarkTester {
    std::vector<TestResult> results_;
    ByteAnalyzer analyzer_;
    ZipReader zip_;

    void check(const std::string& cat, const std::string& name, bool cond,
               const std::string& expected = "", const std::string& actual = "") {
        results_.push_back({Product::BENCHMARK, cat, name,
            cond ? TestStatus::PASS : TestStatus::FAIL, expected, actual, ""});
    }

    bool approx(double a, double b, double tol = 1e-9) {
        if (std::isnan(a) && std::isnan(b)) return true;
        return std::fabs(a - b) < tol;
    }

    std::string fmt(double v) {
        std::ostringstream s;
        s << std::setprecision(15) << v;
        return s.str();
    }

public:
    // APK structure test
    void test_apk(const std::string& path) {
        if (!fs::exists(path)) { return; }

        auto stat = analyzer_.analyze_file(path);
        check("BM-BYTE", "File readable", stat.file_size > 0);
        check("BM-BYTE", "Size > 500KB", stat.file_size > 500 * 1024,
              ">500KB", std::to_string(stat.file_size / 1024) + "KB");
        check("BM-BYTE", "SHA256", !stat.sha256.empty(), "64 chars", stat.sha256);
        check("BM-BYTE", "Entropy > 5.5 (binary)", stat.entropy > 5.5, ">5.5", fmt(stat.entropy));

        auto info = zip_.read(path);
        check("BM-ZIP", "Valid ZIP", info.valid);
        if (!info.valid) return;

        bool has_manifest = false, has_dex = false;
        for (auto& e : info.entries) {
            if (e.name == "AndroidManifest.xml") has_manifest = true;
            if (e.name.find("classes") == 0 && e.name.find(".dex") != std::string::npos) has_dex = true;
        }
        check("BM-APK", "AndroidManifest.xml", has_manifest);
        check("BM-APK", "classes.dex", has_dex);
    }

    // Source package
    void test_source(const std::string& path) {
        if (!fs::exists(path)) { return; }

        auto info = zip_.read(path);
        check("BM-SRC", "Valid ZIP", info.valid);
        if (!info.valid) return;

        int java_count = 0, kotlin_count = 0, xml_count = 0;
        bool has_gradle = false;

        for (auto& e : info.entries) {
            if (e.name.find(".java") != std::string::npos) java_count++;
            if (e.name.find(".kt") != std::string::npos) kotlin_count++;
            if (e.name.find(".xml") != std::string::npos) xml_count++;
            if (e.name.find("build.gradle") != std::string::npos) has_gradle = true;
        }

        check("BM-SRC", "Source files", java_count + kotlin_count > 0,
              ">0", std::to_string(java_count + kotlin_count));
        check("BM-SRC", "build.gradle", has_gradle);
    }

    // AI Constants verification - mathematical constants per byte
    void test_ai_constants() {
        // Fundamental mathematical constants
        check("AI-CONST", "Pi 3.14159265358979", approx(M_PI, 3.14159265358979323846, 1e-14),
              "3.14159265358979", fmt(M_PI));
        check("AI-CONST", "e 2.71828182845905", approx(M_E, 2.71828182845904523536, 1e-14),
              "2.71828182845905", fmt(M_E));
        check("AI-CONST", "sqrt(2) 1.41421356237", approx(std::sqrt(2.0), 1.41421356237309504880, 1e-14),
              "1.41421356237", fmt(std::sqrt(2.0)));
        check("AI-CONST", "sqrt(3) 1.73205080757", approx(std::sqrt(3.0), 1.73205080756887729352, 1e-14),
              "1.73205080757", fmt(std::sqrt(3.0)));
        check("AI-CONST", "ln(2) 0.69314718056", approx(std::log(2.0), 0.69314718055994530942, 1e-14),
              "0.69314718056", fmt(std::log(2.0)));
        check("AI-CONST", "ln(10) 2.30258509299", approx(std::log(10.0), 2.30258509299404568402, 1e-14),
              "2.30258509299", fmt(std::log(10.0)));

        // Physical constants
        double c = 299792458.0;       // speed of light m/s
        double h = 6.62607015e-34;    // Planck constant
        double kb = 1.380649e-23;     // Boltzmann constant
        double Na = 6.02214076e23;    // Avogadro number
        double R = 8.314462618;       // Gas constant
        double g = 9.80665;           // Standard gravity

        check("AI-CONST", "Speed of light", approx(c, 299792458.0), "299792458", fmt(c));
        check("AI-CONST", "Planck constant", approx(h, 6.62607015e-34), "6.62607015e-34", fmt(h));
        check("AI-CONST", "Boltzmann", approx(kb, 1.380649e-23), "1.380649e-23", fmt(kb));
        check("AI-CONST", "Avogadro", approx(Na, 6.02214076e23), "6.02214076e23", fmt(Na));
        check("AI-CONST", "Gas constant R", approx(R, 8.314462618, 1e-6), "8.314462618", fmt(R));
        check("AI-CONST", "Standard gravity", approx(g, 9.80665), "9.80665", fmt(g));

        // Derived constant checks
        check("AI-CONST", "R = Na * kb", approx(Na * kb, R, 0.001), fmt(R), fmt(Na * kb));

        // Aviation constants
        double rho0 = 1.225;          // ISA sea level density kg/m3
        double T0 = 288.15;           // ISA sea level temp K
        double P0 = 101325.0;         // ISA sea level pressure Pa
        double a0 = 340.294;          // Speed of sound at SL m/s
        double gamma = 1.4;           // Ratio of specific heats for air

        check("AI-CONST", "ISA rho0", approx(rho0, 1.225), "1.225", fmt(rho0));
        check("AI-CONST", "ISA T0", approx(T0, 288.15), "288.15", fmt(T0));
        check("AI-CONST", "ISA P0", approx(P0, 101325.0), "101325", fmt(P0));
        check("AI-CONST", "Speed of sound SL", approx(a0, 340.294, 0.001), "340.294", fmt(a0));
        check("AI-CONST", "Gamma air", approx(gamma, 1.4), "1.4", fmt(gamma));

        // Verify speed of sound from T0
        double a_calc = std::sqrt(gamma * 287.05 * T0);
        check("AI-CONST", "a0 from sqrt(gamma*R*T)", approx(a_calc, a0, 0.1), fmt(a0), fmt(a_calc));

        // IEEE 754 bit-level constant representation
        union { double d; uint64_t u; } pi_bits;
        pi_bits.d = M_PI;
        check("AI-CONST", "Pi IEEE754 bits", pi_bits.u == 0x400921FB54442D18ULL,
              "400921FB54442D18", ([&](){
                  std::ostringstream s;
                  s << std::hex << std::uppercase << std::setw(16) << std::setfill('0') << pi_bits.u;
                  return s.str();
              })());

        union { double d; uint64_t u; } e_bits;
        e_bits.d = M_E;
        check("AI-CONST", "e IEEE754 bits", e_bits.u == 0x4005BF0A8B145769ULL,
              "4005BF0A8B145769", ([&](){
                  std::ostringstream s;
                  s << std::hex << std::uppercase << std::setw(16) << std::setfill('0') << e_bits.u;
                  return s.str();
              })());

        // Byte-level double precision layout
        check("AI-CONST", "Double is 8 bytes", sizeof(double) == 8, "8", std::to_string(sizeof(double)));
        check("AI-CONST", "Float is 4 bytes", sizeof(float) == 4, "4", std::to_string(sizeof(float)));

        uint8_t pi_bytes[8];
        std::memcpy(pi_bytes, &pi_bits.u, 8);
        // On little-endian: bytes should be 18 2D 44 54 FB 21 09 40
        bool le = (pi_bytes[7] == 0x40);
        bool be = (pi_bytes[0] == 0x40);
        check("AI-CONST", "Endianness detected", le || be, "LE or BE", le ? "Little-Endian" : "Big-Endian");

        // Numerical stability checks for AI operations
        // Sigmoid function
        auto sigmoid = [](double x) { return 1.0 / (1.0 + std::exp(-x)); };
        check("AI-CONST", "sigmoid(0)=0.5", approx(sigmoid(0.0), 0.5));
        check("AI-CONST", "sigmoid(large)->1", sigmoid(100.0) > 0.9999);
        check("AI-CONST", "sigmoid(-large)->0", sigmoid(-100.0) < 0.0001);

        // Softmax stability (log-sum-exp trick)
        double vals[] = {1.0, 2.0, 3.0, 4.0};
        double max_val = 4.0;
        double sum = 0;
        for (int i = 0; i < 4; i++) sum += std::exp(vals[i] - max_val);
        double lse = max_val + std::log(sum);
        check("AI-CONST", "LogSumExp stable", approx(lse, std::log(std::exp(1.0)+std::exp(2.0)+std::exp(3.0)+std::exp(4.0)), 1e-10),
              "stable", fmt(lse));

        // ReLU behavior
        auto relu = [](double x) { return x > 0 ? x : 0.0; };
        check("AI-CONST", "ReLU(1)=1", approx(relu(1.0), 1.0));
        check("AI-CONST", "ReLU(-1)=0", approx(relu(-1.0), 0.0));
        check("AI-CONST", "ReLU(0)=0", approx(relu(0.0), 0.0));

        // Gradient computation
        double eps = 1e-7;
        auto f = [](double x) { return x * x + 2 * x + 1; };
        double grad = (f(3.0 + eps) - f(3.0 - eps)) / (2 * eps);
        check("AI-CONST", "Numerical gradient x^2+2x+1 at 3", approx(grad, 8.0, 1e-5),
              "8.0", fmt(grad));
    }

    // Byte-level binary pattern tests
    void test_byte_patterns() {
        // Test all byte values 0x00-0xFF
        uint8_t all_bytes[256];
        for (int i = 0; i < 256; i++) all_bytes[i] = uint8_t(i);

        CRC32 crc;
        uint32_t c = crc.compute(all_bytes, 256);
        check("BM-BYTE-PAT", "All-byte CRC32", c != 0, "non-zero", std::to_string(c));

        // Alternating bit patterns
        uint8_t pat_aa[] = {0xAA, 0xAA, 0xAA, 0xAA};
        uint8_t pat_55[] = {0x55, 0x55, 0x55, 0x55};
        uint32_t c_aa = crc.compute(pat_aa, 4);
        uint32_t c_55 = crc.compute(pat_55, 4);
        check("BM-BYTE-PAT", "0xAA pattern CRC", c_aa != 0);
        check("BM-BYTE-PAT", "0x55 pattern CRC", c_55 != 0);
        check("BM-BYTE-PAT", "0xAA != 0x55 CRC", c_aa != c_55);

        // Zero block
        uint8_t zeros[1024];
        std::memset(zeros, 0, sizeof(zeros));
        uint32_t c_z = crc.compute(zeros, sizeof(zeros));
        check("BM-BYTE-PAT", "1KB zero CRC", c_z != 0);

        // FF block
        uint8_t ones[1024];
        std::memset(ones, 0xFF, sizeof(ones));
        uint32_t c_o = crc.compute(ones, sizeof(ones));
        check("BM-BYTE-PAT", "1KB 0xFF CRC", c_o != 0);
        check("BM-BYTE-PAT", "Zero != FF CRC", c_z != c_o);

        // Bit manipulation correctness
        for (int bit = 0; bit < 8; bit++) {
            uint8_t v = 1 << bit;
            check("BM-BYTE-PAT", "Bit " + std::to_string(bit) + " set",
                  v == (1 << bit) && (v & (1 << bit)) != 0);
        }

        // Endian conversion
        uint32_t val = 0xDEADBEEF;
        uint8_t bytes[4];
        std::memcpy(bytes, &val, 4);
        uint32_t reconstructed = uint32_t(bytes[0]) | (uint32_t(bytes[1])<<8) |
                                 (uint32_t(bytes[2])<<16) | (uint32_t(bytes[3])<<24);
        check("BM-BYTE-PAT", "LE byte reconstruction",
              reconstructed == val || reconstructed == 0xEFBEADDE);
    }

    // SHA-256 self-verification
    void test_sha256_self() {
        SHA256 sha;
        check("BM-SHA", "SHA256 self-test", sha.self_test());

        // Known test: "abc"
        const uint8_t abc[] = {'a', 'b', 'c'};
        std::string h = sha.compute(abc, 3);
        check("BM-SHA", "SHA256('abc')", h == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
              "ba7816bf...15ad", h);

        // CRC32 determinism
        CRC32 crc;
        const uint8_t data[] = "Hello, AI2ORBIT!";
        uint32_t c1 = crc.compute(data, sizeof(data) - 1);
        uint32_t c2 = crc.compute(data, sizeof(data) - 1);
        check("BM-SHA", "CRC32 deterministic", c1 == c2);
    }

    std::vector<TestResult>& results() { return results_; }
};

} // namespace swt
#endif
