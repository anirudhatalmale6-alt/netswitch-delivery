// AI2ORBIT SW Tester - Report generator (text + HTML)
#ifndef SW_REPORT_H
#define SW_REPORT_H

#include "sw_types.h"
#include <fstream>

namespace swt {

class ReportGenerator {
public:
    static void print_report(const FullReport& report) {
        std::cout << "================================================================\n";
        std::cout << "  AI2ORBIT SOFTWARE TESTER v1.0.0\n";
        std::cout << "  FMA Engineering - Product Verification Suite\n";
        std::cout << "  Per Byte Verification\n";
        std::cout << "================================================================\n\n";

        for (auto& pr : report.products) {
            std::cout << "------------------------------------------------------------\n";
            std::cout << "  PRODUCT: " << pr.product_name;
            if (!pr.version.empty()) std::cout << " " << pr.version;
            std::cout << "\n";
            std::cout << "------------------------------------------------------------\n";

            std::string current_cat;
            for (auto& r : pr.results) {
                if (r.category != current_cat) {
                    current_cat = r.category;
                    std::cout << "\n  [" << current_cat << "]\n";
                }

                std::string marker;
                switch (r.status) {
                    case TestStatus::PASS: marker = "  PASS"; break;
                    case TestStatus::FAIL: marker = "  FAIL"; break;
                    case TestStatus::WARN: marker = "  WARN"; break;
                    case TestStatus::SKIP: marker = "  SKIP"; break;
                }
                std::cout << "    " << marker << ": " << r.name;
                if (r.status == TestStatus::FAIL && !r.expected.empty()) {
                    std::cout << " (expected " << r.expected;
                    if (!r.actual.empty()) std::cout << ", got " << r.actual;
                    std::cout << ")";
                }
                if (r.status == TestStatus::PASS && !r.actual.empty()) {
                    std::cout << " [" << r.actual << "]";
                }
                std::cout << "\n";
            }

            std::cout << "\n  Summary: " << pr.passed << "/" << pr.total << " PASS";
            if (pr.failed > 0) std::cout << ", " << pr.failed << " FAIL";
            if (pr.warnings > 0) std::cout << ", " << pr.warnings << " WARN";
            if (pr.skipped > 0) std::cout << ", " << pr.skipped << " SKIP";
            std::cout << " (" << std::fixed << std::setprecision(2) << pr.elapsed_ms << " ms)\n\n";
        }

        std::cout << "================================================================\n";
        std::cout << "  GRAND TOTAL\n";
        std::cout << "  Tests:   " << report.grand_total << "\n";
        std::cout << "  Passed:  " << report.grand_passed << "\n";
        std::cout << "  Failed:  " << report.grand_failed << "\n";
        std::cout << "  Time:    " << std::fixed << std::setprecision(2) << report.total_elapsed_ms << " ms\n";
        std::cout << "  Status:  " << (report.system_ready ? "ALL SYSTEMS VERIFIED" : "VERIFICATION FAILURES DETECTED") << "\n";
        std::cout << "================================================================\n";
    }

    static void write_html(const FullReport& report, const std::string& path) {
        std::ofstream f(path);
        if (!f.is_open()) return;

        f << "<!DOCTYPE html>\n<html><head><meta charset='utf-8'>\n";
        f << "<title>AI2ORBIT Software Tester Report</title>\n";
        f << "<style>\n";
        f << "body { font-family: 'Consolas', 'Courier New', monospace; background: #0a0a0a; color: #e0e0e0; margin: 20px; }\n";
        f << "h1 { color: #00d4ff; border-bottom: 2px solid #00d4ff; padding-bottom: 10px; }\n";
        f << "h2 { color: #ffa500; margin-top: 30px; }\n";
        f << "h3 { color: #888; margin-top: 20px; }\n";
        f << ".pass { color: #00ff41; }\n";
        f << ".fail { color: #ff3333; font-weight: bold; }\n";
        f << ".warn { color: #ffaa00; }\n";
        f << ".skip { color: #666; }\n";
        f << ".summary { background: #1a1a2e; padding: 15px; border-radius: 8px; margin: 10px 0; }\n";
        f << ".grand { background: #0d2137; padding: 20px; border-radius: 8px; border: 1px solid #00d4ff; margin-top: 30px; }\n";
        f << "table { border-collapse: collapse; width: 100%; }\n";
        f << "td, th { padding: 4px 12px; text-align: left; border-bottom: 1px solid #333; }\n";
        f << "th { color: #00d4ff; }\n";
        f << "</style></head><body>\n";

        f << "<h1>AI2ORBIT Software Tester v1.0.0</h1>\n";
        f << "<p>FMA Engineering - Per Byte Product Verification</p>\n";

        for (auto& pr : report.products) {
            f << "<h2>" << pr.product_name;
            if (!pr.version.empty()) f << " " << pr.version;
            f << "</h2>\n";

            f << "<table><tr><th>Status</th><th>Category</th><th>Test</th><th>Detail</th></tr>\n";

            for (auto& r : pr.results) {
                std::string cls;
                switch (r.status) {
                    case TestStatus::PASS: cls = "pass"; break;
                    case TestStatus::FAIL: cls = "fail"; break;
                    case TestStatus::WARN: cls = "warn"; break;
                    case TestStatus::SKIP: cls = "skip"; break;
                }
                f << "<tr><td class='" << cls << "'>" << status_str(r.status) << "</td>";
                f << "<td>" << r.category << "</td>";
                f << "<td>" << r.name << "</td>";
                f << "<td>";
                if (!r.expected.empty()) f << "exp:" << r.expected;
                if (!r.actual.empty()) f << " got:" << r.actual;
                f << "</td></tr>\n";
            }
            f << "</table>\n";

            f << "<div class='summary'><strong>" << pr.passed << "/" << pr.total << "</strong> PASS";
            if (pr.failed > 0) f << " | <span class='fail'>" << pr.failed << " FAIL</span>";
            f << " | " << std::fixed << std::setprecision(2) << pr.elapsed_ms << " ms</div>\n";
        }

        f << "<div class='grand'><h2>Grand Total</h2>\n";
        f << "<p>Tests: " << report.grand_total << " | Passed: " << report.grand_passed;
        f << " | Failed: " << report.grand_failed << "</p>\n";
        f << "<p>Time: " << std::fixed << std::setprecision(2) << report.total_elapsed_ms << " ms</p>\n";
        f << "<p style='font-size:1.3em;color:" << (report.system_ready ? "#00ff41" : "#ff3333") << "'>";
        f << (report.system_ready ? "ALL SYSTEMS VERIFIED" : "VERIFICATION FAILURES DETECTED") << "</p>\n";
        f << "</div></body></html>\n";
    }

    static void write_text(const FullReport& report, const std::string& path) {
        std::ofstream f(path);
        if (!f.is_open()) return;

        f << "AI2ORBIT SOFTWARE TESTER REPORT v1.0.0\n";
        f << "FMA Engineering - Per Byte Verification\n";
        f << "========================================\n\n";

        for (auto& pr : report.products) {
            f << "--- " << pr.product_name << " ---\n";
            for (auto& r : pr.results) {
                f << status_str(r.status) << ": " << r.category << "/" << r.name;
                if (!r.expected.empty()) f << " [" << r.expected << "]";
                if (!r.actual.empty()) f << " [" << r.actual << "]";
                f << "\n";
            }
            f << "Result: " << pr.passed << "/" << pr.total << "\n\n";
        }

        f << "TOTAL: " << report.grand_passed << "/" << report.grand_total << "\n";
        f << "Status: " << (report.system_ready ? "VERIFIED" : "FAILURES") << "\n";
    }
};

} // namespace swt
#endif
