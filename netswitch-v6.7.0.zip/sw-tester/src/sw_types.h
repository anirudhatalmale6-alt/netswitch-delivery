// AI2ORBIT SW Tester - Core types
#ifndef SW_TYPES_H
#define SW_TYPES_H

#include <string>
#include <vector>
#include <cstdint>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <functional>

namespace swt {

enum class TestStatus { PASS, FAIL, WARN, SKIP };
enum class Product { NETSWITCH, QCV, BENCHMARK, SYSTEM };

struct TestResult {
    Product product;
    std::string category;
    std::string name;
    TestStatus status;
    std::string expected;
    std::string actual;
    std::string detail;
};

struct ByteStat {
    uint64_t file_size;
    uint32_t crc32;
    std::string sha256;
    uint64_t byte_histogram[256];
    double entropy;
    bool has_null_bytes;
    uint64_t printable_count;
    uint64_t non_printable_count;
};

struct FileEntry {
    std::string path;
    uint64_t size;
    uint32_t crc32;
    std::string sha256;
    bool is_binary;
};

struct ZipEntry {
    std::string name;
    uint32_t compressed_size;
    uint32_t uncompressed_size;
    uint32_t crc32;
    uint16_t compression;
};

struct TestReport {
    std::string product_name;
    std::string version;
    std::string timestamp;
    double elapsed_ms;
    int total;
    int passed;
    int failed;
    int warnings;
    int skipped;
    std::vector<TestResult> results;
    bool all_pass;
};

struct FullReport {
    std::vector<TestReport> products;
    int grand_total;
    int grand_passed;
    int grand_failed;
    double total_elapsed_ms;
    bool system_ready;
};

inline std::string status_str(TestStatus s) {
    switch (s) {
        case TestStatus::PASS: return "PASS";
        case TestStatus::FAIL: return "FAIL";
        case TestStatus::WARN: return "WARN";
        case TestStatus::SKIP: return "SKIP";
    }
    return "?";
}

inline std::string product_str(Product p) {
    switch (p) {
        case Product::NETSWITCH: return "NetSwitch";
        case Product::QCV: return "QCV";
        case Product::BENCHMARK: return "Benchmark";
        case Product::SYSTEM: return "System";
    }
    return "?";
}

} // namespace swt
#endif
