// AI2ORBIT SW Tester v1.0.0 - Single Binary
// FMA Engineering 2026
// Tests NetSwitch, QCV 14.02, and Benchmark-AI-Constant per byte
#include "sw_types.h"
#include "sw_checksum.h"
#include "sw_zip.h"
#include "sw_netswitch.h"
#include "sw_qcv.h"
#include "sw_benchmark.h"
#include "sw_report.h"
#include <filesystem>
#include <algorithm>

namespace fs = std::filesystem;

static void print_usage() {
    std::cout << "AI2ORBIT Software Tester v1.0.0\n";
    std::cout << "FMA Engineering 2026\n\n";
    std::cout << "Usage:\n";
    std::cout << "  sw_tester [options]\n\n";
    std::cout << "Options:\n";
    std::cout << "  --all              Run all product tests\n";
    std::cout << "  --netswitch <dir>  Test NetSwitch products in directory\n";
    std::cout << "  --qcv <dir>       Test QCV assembler in directory\n";
    std::cout << "  --benchmark <dir>  Test Benchmark products in directory\n";
    std::cout << "  --file <path>      Analyze single file (byte-level)\n";
    std::cout << "  --compare <a> <b>  Compare two files byte-by-byte\n";
    std::cout << "  --selftest         Run internal verification\n";
    std::cout << "  --html <path>      Write HTML report\n";
    std::cout << "  --text <path>      Write text report\n";
    std::cout << "  -v                 Verbose output\n";
    std::cout << "  -h, --help         Show this help\n";
}

static void print_version() {
    std::cout << "AI2ORBIT Software Tester v1.0.0\n";
    std::cout << "FMA Engineering\n";
    std::cout << "Build: 2026.06.19\n";
}

// Scan directory for product files
struct ProductFiles {
    std::vector<std::string> netswitch_apks;
    std::vector<std::string> netswitch_aabs;
    std::vector<std::string> netswitch_sources;
    std::vector<std::string> benchmark_apks;
    std::vector<std::string> benchmark_aabs;
    std::vector<std::string> benchmark_sources;
    std::string qcv_zip;
    std::string qcv_binary;
};

static ProductFiles scan_directory(const std::string& dir) {
    ProductFiles pf;

    for (auto& entry : fs::directory_iterator(dir)) {
        if (!entry.is_regular_file()) continue;
        std::string name = entry.path().filename().string();
        std::string path = entry.path().string();

        // NetSwitch
        if (name.find("NetSwitch") != std::string::npos || name.find("netswitch") != std::string::npos) {
            if (name.find(".apk") != std::string::npos && name.find(".bin") == std::string::npos)
                pf.netswitch_apks.push_back(path);
            else if (name.find(".aab") != std::string::npos && name.find(".bin") == std::string::npos)
                pf.netswitch_aabs.push_back(path);
            else if (name.find("Source") != std::string::npos && name.find(".zip") != std::string::npos)
                pf.netswitch_sources.push_back(path);
        }

        // Benchmark
        if (name.find("Benchmark") != std::string::npos || name.find("benchmark") != std::string::npos) {
            if (name.find(".apk") != std::string::npos && name.find(".bin") == std::string::npos)
                pf.benchmark_apks.push_back(path);
            else if (name.find(".aab") != std::string::npos && name.find(".bin") == std::string::npos)
                pf.benchmark_aabs.push_back(path);
            else if (name.find("Source") != std::string::npos && name.find(".zip") != std::string::npos)
                pf.benchmark_sources.push_back(path);
        }

        // QCV
        if (name.find("QCV") != std::string::npos || name.find("qcv") != std::string::npos) {
            if (name.find(".zip") != std::string::npos)
                pf.qcv_zip = path;
        }

        // Compiled binary
        if (name == "qcv" || name == "qcv.exe")
            pf.qcv_binary = path;
    }

    // Also check assembler-qcv subdir
    std::string qcv_dir = dir + "/assembler-qcv";
    if (fs::exists(qcv_dir + "/build/qcv"))
        pf.qcv_binary = qcv_dir + "/build/qcv";
    if (fs::exists(qcv_dir + "/build/qcv.exe"))
        pf.qcv_binary = qcv_dir + "/build/qcv.exe";

    return pf;
}

static swt::TestReport build_report(const std::string& name, const std::string& version,
                                     std::vector<swt::TestResult>& results, double elapsed_ms) {
    swt::TestReport report;
    report.product_name = name;
    report.version = version;
    report.elapsed_ms = elapsed_ms;
    report.results = results;
    report.total = results.size();
    report.passed = report.failed = report.warnings = report.skipped = 0;
    for (auto& r : results) {
        switch (r.status) {
            case swt::TestStatus::PASS: report.passed++; break;
            case swt::TestStatus::FAIL: report.failed++; break;
            case swt::TestStatus::WARN: report.warnings++; break;
            case swt::TestStatus::SKIP: report.skipped++; break;
        }
    }
    report.all_pass = (report.failed == 0);
    return report;
}

static void analyze_single_file(const std::string& path) {
    swt::ByteAnalyzer analyzer;
    auto stat = analyzer.analyze_file(path);

    std::cout << "================================================================\n";
    std::cout << "  FILE ANALYSIS: " << path << "\n";
    std::cout << "================================================================\n";
    std::cout << "  Size:           " << stat.file_size << " bytes (" << stat.file_size / 1024 << " KB)\n";
    std::cout << "  CRC32:          " << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << stat.crc32 << std::dec << "\n";
    std::cout << "  SHA256:         " << stat.sha256 << "\n";
    std::cout << "  Entropy:        " << std::fixed << std::setprecision(4) << stat.entropy << " bits/byte\n";
    std::cout << "  Null bytes:     " << (stat.has_null_bytes ? "Yes" : "No") << "\n";
    std::cout << "  Printable:      " << stat.printable_count << " (" << std::setprecision(1)
              << (stat.file_size > 0 ? 100.0 * stat.printable_count / stat.file_size : 0) << "%)\n";
    std::cout << "  Non-printable:  " << stat.non_printable_count << "\n";

    // File type detection
    std::string type = "Unknown";
    double ratio = stat.file_size > 0 ? double(stat.printable_count) / stat.file_size : 0;
    if (ratio > 0.95) type = "Text/Source";
    else if (stat.entropy > 7.5) type = "Compressed/Encrypted";
    else if (stat.has_null_bytes) type = "Binary";

    // Check headers
    std::ifstream f(path, std::ios::binary);
    uint8_t magic[8];
    f.read(reinterpret_cast<char*>(magic), 8);
    if (magic[0] == 0x50 && magic[1] == 0x4B) type = "ZIP/APK/AAB";
    else if (magic[0] == 0x7F && magic[1] == 'E') type = "ELF Executable";
    else if (magic[0] == 'M' && magic[1] == 'Z') type = "PE/Windows Executable";
    else if (magic[0] == 0x89 && magic[1] == 'P') type = "PNG Image";
    else if (magic[0] == 0xFF && magic[1] == 0xD8) type = "JPEG Image";
    else if (magic[0] == '%' && magic[1] == 'P') type = "PDF Document";

    std::cout << "  Type:           " << type << "\n";

    // Byte histogram top 10
    std::cout << "\n  Byte Histogram (top 10):\n";
    struct ByteCount { int byte_val; uint8_t count; };
    std::vector<std::pair<int, int>> histogram;
    for (int i = 0; i < 256; i++)
        histogram.push_back({i, stat.byte_histogram[i]});
    std::sort(histogram.begin(), histogram.end(),
              [](auto& a, auto& b) { return a.second > b.second; });
    for (int i = 0; i < 10 && i < 256; i++) {
        std::cout << "    0x" << std::hex << std::setw(2) << std::setfill('0') << histogram[i].first
                  << std::dec << ": " << histogram[i].second << "\n";
    }

    std::cout << "================================================================\n";
}

static void compare_files(const std::string& a, const std::string& b) {
    swt::ByteAnalyzer analyzer;
    auto diffs = analyzer.compare_files(a, b);

    auto stat_a = analyzer.analyze_file(a);
    auto stat_b = analyzer.analyze_file(b);

    std::cout << "================================================================\n";
    std::cout << "  BYTE COMPARISON\n";
    std::cout << "================================================================\n";
    std::cout << "  File A: " << a << " (" << stat_a.file_size << " bytes)\n";
    std::cout << "  File B: " << b << " (" << stat_b.file_size << " bytes)\n";
    std::cout << "  CRC32 A: " << std::hex << stat_a.crc32 << std::dec << "\n";
    std::cout << "  CRC32 B: " << std::hex << stat_b.crc32 << std::dec << "\n";

    if (stat_a.sha256 == stat_b.sha256) {
        std::cout << "\n  Result: FILES ARE IDENTICAL\n";
    } else {
        std::cout << "\n  Differences found: " << diffs.size();
        if (diffs.size() >= 100) std::cout << "+ (truncated)";
        std::cout << "\n\n";

        for (size_t i = 0; i < diffs.size() && i < 20; i++) {
            std::cout << "    Offset 0x" << std::hex << std::setw(8) << std::setfill('0') << diffs[i].offset
                      << ": A=0x" << std::setw(2) << int(diffs[i].byte_a)
                      << " B=0x" << std::setw(2) << int(diffs[i].byte_b) << std::dec << "\n";
        }
        if (diffs.size() > 20) std::cout << "    ... and " << (diffs.size() - 20) << " more\n";
    }
    std::cout << "================================================================\n";
}

static void run_selftest() {
    std::cout << "Running internal self-tests...\n\n";

    int pass = 0, fail = 0;

    // SHA-256 test
    swt::SHA256 sha;
    bool sha_ok = sha.self_test();
    std::cout << (sha_ok ? "  PASS" : "  FAIL") << ": SHA-256 empty string\n";
    if (sha_ok) pass++; else fail++;

    const uint8_t abc[] = {'a', 'b', 'c'};
    bool sha_abc = sha.compute(abc, 3) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    std::cout << (sha_abc ? "  PASS" : "  FAIL") << ": SHA-256 'abc'\n";
    if (sha_abc) pass++; else fail++;

    // CRC32 test
    swt::CRC32 crc;
    const uint8_t test[] = "123456789";
    uint32_t c = crc.compute(test, 9);
    bool crc_ok = (c == 0xCBF43926);
    std::cout << (crc_ok ? "  PASS" : "  FAIL") << ": CRC32 '123456789' = 0xCBF43926\n";
    if (crc_ok) pass++; else fail++;

    // ZIP reader test
    uint8_t fake_zip[] = {0x50, 0x4B, 0x03, 0x04};
    bool zip_sig = (fake_zip[0] == 0x50 && fake_zip[1] == 0x4B);
    std::cout << (zip_sig ? "  PASS" : "  FAIL") << ": ZIP signature detection\n";
    if (zip_sig) pass++; else fail++;

    // Math constants
    bool pi_ok = std::fabs(M_PI - 3.14159265358979323846) < 1e-15;
    std::cout << (pi_ok ? "  PASS" : "  FAIL") << ": Pi constant precision\n";
    if (pi_ok) pass++; else fail++;

    bool e_ok = std::fabs(M_E - 2.71828182845904523536) < 1e-15;
    std::cout << (e_ok ? "  PASS" : "  FAIL") << ": Euler constant precision\n";
    if (e_ok) pass++; else fail++;

    // ByteAnalyzer
    swt::ByteAnalyzer ba;
    uint8_t pattern[] = {0x00, 0x01, 0x02, 0x03, 0xFF};
    uint32_t pcrc = crc.compute(pattern, sizeof(pattern));
    bool ba_ok = (pcrc != 0);
    std::cout << (ba_ok ? "  PASS" : "  FAIL") << ": ByteAnalyzer CRC computation\n";
    if (ba_ok) pass++; else fail++;

    std::cout << "\nSelf-test: " << pass << "/" << (pass + fail) << " passed\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) { print_usage(); return 1; }

    std::string scan_dir;
    std::string html_output;
    std::string text_output;
    std::string single_file;
    std::string compare_a, compare_b;
    bool run_all = false;
    bool verbose = false;
    bool do_netswitch = false, do_qcv = false, do_benchmark = false;
    std::string ns_dir, qcv_dir, bm_dir;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-h" || arg == "--help") { print_usage(); return 0; }
        if (arg == "--version") { print_version(); return 0; }
        if (arg == "--selftest") { run_selftest(); return 0; }
        if (arg == "-v") { verbose = true; continue; }
        if (arg == "--all" && i + 1 < argc) { run_all = true; scan_dir = argv[++i]; continue; }
        if (arg == "--all") { run_all = true; continue; }
        if (arg == "--netswitch" && i + 1 < argc) { do_netswitch = true; ns_dir = argv[++i]; continue; }
        if (arg == "--qcv" && i + 1 < argc) { do_qcv = true; qcv_dir = argv[++i]; continue; }
        if (arg == "--benchmark" && i + 1 < argc) { do_benchmark = true; bm_dir = argv[++i]; continue; }
        if (arg == "--file" && i + 1 < argc) { single_file = argv[++i]; continue; }
        if (arg == "--compare" && i + 2 < argc) { compare_a = argv[++i]; compare_b = argv[++i]; continue; }
        if (arg == "--html" && i + 1 < argc) { html_output = argv[++i]; continue; }
        if (arg == "--text" && i + 1 < argc) { text_output = argv[++i]; continue; }
        // Treat bare argument as directory
        if (scan_dir.empty()) { scan_dir = arg; run_all = true; }
    }

    // Single file analysis
    if (!single_file.empty()) {
        analyze_single_file(single_file);
        return 0;
    }

    // File comparison
    if (!compare_a.empty()) {
        compare_files(compare_a, compare_b);
        return 0;
    }

    swt::FullReport full_report;
    full_report.grand_total = full_report.grand_passed = full_report.grand_failed = 0;
    full_report.total_elapsed_ms = 0;

    // Determine directories
    if (run_all && !scan_dir.empty()) {
        ns_dir = qcv_dir = bm_dir = scan_dir;
        do_netswitch = do_qcv = do_benchmark = true;
    }

    if (!do_netswitch && !do_qcv && !do_benchmark) {
        std::cerr << "No tests specified. Use --all <dir>, --netswitch <dir>, --qcv <dir>, or --benchmark <dir>\n";
        return 1;
    }

    // Scan files
    ProductFiles pf;
    if (!scan_dir.empty()) pf = scan_directory(scan_dir);
    else {
        if (do_netswitch) {
            auto npf = scan_directory(ns_dir);
            pf.netswitch_apks = npf.netswitch_apks;
            pf.netswitch_aabs = npf.netswitch_aabs;
            pf.netswitch_sources = npf.netswitch_sources;
        }
        if (do_qcv) {
            auto qpf = scan_directory(qcv_dir);
            pf.qcv_zip = qpf.qcv_zip;
            pf.qcv_binary = qpf.qcv_binary;
        }
        if (do_benchmark) {
            auto bpf = scan_directory(bm_dir);
            pf.benchmark_apks = bpf.benchmark_apks;
            pf.benchmark_aabs = bpf.benchmark_aabs;
            pf.benchmark_sources = bpf.benchmark_sources;
        }
    }

    // === NETSWITCH TESTS ===
    if (do_netswitch) {
        auto t0 = std::chrono::high_resolution_clock::now();
        swt::NetSwitchTester ns;

        for (auto& apk : pf.netswitch_apks) {
            if (verbose) std::cout << "Testing APK: " << apk << "\n";
            ns.test_apk(apk);
        }
        for (auto& aab : pf.netswitch_aabs) {
            if (verbose) std::cout << "Testing AAB: " << aab << "\n";
            ns.test_aab(aab);
        }
        for (auto& src : pf.netswitch_sources) {
            if (verbose) std::cout << "Testing Source: " << src << "\n";
            ns.test_source(src);
        }
        ns.test_version_consistency(pf.netswitch_apks);

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count() / 1000.0;

        auto report = build_report("NetSwitch", "v2.6.0", ns.results(), ms);
        full_report.products.push_back(report);
    }

    // === QCV TESTS ===
    if (do_qcv) {
        auto t0 = std::chrono::high_resolution_clock::now();
        swt::QCVTester qcv;

        if (!pf.qcv_zip.empty()) {
            if (verbose) std::cout << "Testing QCV package: " << pf.qcv_zip << "\n";
            qcv.test_source_package(pf.qcv_zip);
        }
        if (!pf.qcv_binary.empty()) {
            if (verbose) std::cout << "Testing QCV binary: " << pf.qcv_binary << "\n";
            qcv.test_binary(pf.qcv_binary);
        }

        qcv.test_ieee754();
        qcv.test_trig();
        qcv.test_navigation();
        qcv.test_flight();
        qcv.test_matrix();
        qcv.test_integers();
        qcv.test_log_exp();

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count() / 1000.0;

        auto report = build_report("QCV Assembler", "14.02", qcv.results(), ms);
        full_report.products.push_back(report);
    }

    // === BENCHMARK TESTS ===
    if (do_benchmark) {
        auto t0 = std::chrono::high_resolution_clock::now();
        swt::BenchmarkTester bm;

        for (auto& apk : pf.benchmark_apks) {
            if (verbose) std::cout << "Testing Benchmark APK: " << apk << "\n";
            bm.test_apk(apk);
        }
        for (auto& src : pf.benchmark_sources) {
            if (verbose) std::cout << "Testing Benchmark Source: " << src << "\n";
            bm.test_source(src);
        }

        bm.test_ai_constants();
        bm.test_byte_patterns();
        bm.test_sha256_self();

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count() / 1000.0;

        auto report = build_report("Benchmark-AI-Constant", "v1.7.0", bm.results(), ms);
        full_report.products.push_back(report);
    }

    // Aggregate
    for (auto& pr : full_report.products) {
        full_report.grand_total += pr.total;
        full_report.grand_passed += pr.passed;
        full_report.grand_failed += pr.failed;
        full_report.total_elapsed_ms += pr.elapsed_ms;
    }
    full_report.system_ready = (full_report.grand_failed == 0);

    // Output
    swt::ReportGenerator::print_report(full_report);

    if (!html_output.empty()) {
        swt::ReportGenerator::write_html(full_report, html_output);
        std::cout << "\nHTML report: " << html_output << "\n";
    }

    if (!text_output.empty()) {
        swt::ReportGenerator::write_text(full_report, text_output);
        std::cout << "Text report: " << text_output << "\n";
    }

    return full_report.system_ready ? 0 : 1;
}
