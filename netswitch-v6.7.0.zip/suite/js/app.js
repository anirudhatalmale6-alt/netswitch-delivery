// AI2ORBIT Suite Dashboard v5.2.0
// FMA Engineering 2026

const SUITE = {
    activeSection: 'dashboard',

    products: [
        {
            id: 'net', name: 'NetSwitch Network Tester', version: 'v1.0',
            desc: 'Multi-carrier pipe distribution, AI-driven routing, enterprise security stack bypass, Galaxy vector map, MNO topology, and comprehensive feature listing with source references.',
            path: '../net-tester/index.html', color: '#06b6d4', icon: 'NT',
            tags: ['7 Tabs', 'Multi-Carrier', 'AI Routing', 'Enterprise Bypass', 'MNO Topology', 'Dirac Latency', 'Firewall Traversal'],
            stats: { tabs: 7, protocols: 22, providers: 8, firewalls: 12 }
        },
        {
            id: 'stream', name: 'Stream Tester', version: 'v3.0',
            desc: 'Enterprise security bypass engine with real-time stream simulation, bitrate tier management, container segmentation, and carrier pipe load distribution.',
            path: '../stream-tester/index.html', color: '#8b5cf6', icon: 'ST',
            tags: ['Bypass Engine', 'Bitrate Tiers', 'Container Segments', 'Carrier Pipes', 'Heartbeat', 'Failover'],
            stats: { engines: 12, tiers: 4, formats: 4, pipes: 8 }
        },
        {
            id: 'field', name: 'Field Streamer', version: 'v1.0',
            desc: 'Coverage map with camera viewfinder for field operations. Photo, video, and cloud streaming with multi-carrier pipe management and event logging.',
            path: '../field-streamer/index.html', color: '#10b981', icon: 'FS',
            tags: ['Coverage Map', 'Camera Viewfinder', 'Photo/Video/Stream', 'Cloud Upload', 'Carrier Pipes', 'Markers'],
            stats: { modes: 3, carriers: 3, tools: 6, zones: 5 }
        },
        {
            id: 'bench', name: 'Benchmark AI', version: 'v2.1',
            desc: 'C++17 header-only byte-level verification suite. 278 tests across 32 modules covering PCI DSS 4.0, ISO compliance, checksum verification, and data integrity.',
            path: null, color: '#f97316', icon: 'BA',
            tags: ['C++17', '278 Tests', '32 Modules', 'PCI DSS 4.0', 'ISO Compliance', 'Byte-Level'],
            stats: { tests: 278, modules: 32, standards: 6, pass: '100%' }
        },
        {
            id: 'prop', name: 'Property Cloud', version: 'v1.0',
            desc: 'Property development cloud with floor size calculator supporting square feet and square meters conversion, development cost estimation.',
            path: '../property-cloud/index.html', color: '#3b82f6', icon: 'PC',
            tags: ['Floor Calculator', 'SqFt/SqM', 'Cost Estimation', 'Development Cloud'],
            stats: { tools: 3, units: 2, calcs: 4, formats: 2 }
        },
        {
            id: 'quality', name: 'Quality & Firewall', version: 'v5.2',
            desc: 'Integrated quality assurance across all modules. Firewall traversal matrix, protocol compliance, codec compatibility, platform certification, and transmission strength analysis.',
            path: '../net-tester/index.html#features', color: '#f59e0b', icon: 'QF',
            tags: ['12 Firewalls', '10 Platforms', '11 Codecs', '8 Comms', 'Transmission Strength', 'Sources'],
            stats: { firewalls: 12, platforms: 10, codecs: 11, sources: 42 }
        }
    ],

    features: [
        // Network
        { name: 'Multi-Carrier Pipe Distribution', desc: 'Traffic split across active providers with AI load balancing', cat: 'network', module: 'net', src: 'FMA Eng' },
        { name: 'AI-Driven Path Selection', desc: 'Automatic best-path routing based on latency/loss/jitter', cat: 'routing', module: 'net', src: 'FMA Eng' },
        { name: 'Manual Failover Override', desc: 'Operator-controlled pipe switching for specific scenarios', cat: 'routing', module: 'net', src: 'FMA Eng' },
        { name: 'IP Endangered Routing', desc: 'Source IP masking via multi-hop when detection risk is high', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'DHCP Reroute', desc: 'Force new IP lease via DHCP release/renew cycle', cat: 'routing', module: 'net', src: 'RFC 2131' },
        { name: 'FW Port Bypass Cycling', desc: 'Rotate through 443/3478/8443/50000/80/8080/5060/19302', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'Heartbeat Watchdog', desc: '500ms interval, 3-miss threshold auto-failover', cat: 'network', module: 'shared', src: 'FMA Eng' },
        { name: 'Dual-Pipe Redundancy', desc: 'Two concurrent carrier pipes for zero-gap failover', cat: 'network', module: 'net', src: 'FMA Eng' },
        { name: 'Galaxy Vector Map', desc: 'Global socket-port routing visualization with Dirac latency', cat: 'network', module: 'net', src: 'Dirac Model' },
        { name: 'MNO-Hyperscaler Topology', desc: '16 MNOs, 3 hyperscalers, 9 vendors, 25 connections mapped', cat: 'network', module: 'net', src: '3GPP / ETSI' },
        { name: 'Derima Container Segmentation', desc: 'Similar triangle math for MP4 segment distribution', cat: 'stream', module: 'net', src: 'FMA Eng' },
        // Protocols
        { name: 'TLS 1.3', desc: 'Primary tunnel encryption, 1-RTT handshake', cat: 'protocol', module: 'shared', src: 'RFC 8446' },
        { name: 'DTLS 1.3', desc: 'UDP datagram encryption for real-time streams', cat: 'protocol', module: 'shared', src: 'RFC 9147' },
        { name: 'QUIC', desc: '0-RTT connection, multiplexed UDP streams', cat: 'protocol', module: 'shared', src: 'RFC 9000' },
        { name: 'WebRTC', desc: 'Browser-native P2P audio/video/data channels', cat: 'protocol', module: 'shared', src: 'RFC 8825' },
        { name: 'SRTP', desc: 'Secure Real-time Transport Protocol', cat: 'protocol', module: 'stream', src: 'RFC 3711' },
        { name: 'SIP', desc: 'Session Initiation Protocol for call setup', cat: 'protocol', module: 'shared', src: 'RFC 3261' },
        { name: 'HTTP/2', desc: 'Multiplexed request streams, header compression', cat: 'protocol', module: 'shared', src: 'RFC 9113' },
        { name: 'HTTP/3', desc: 'QUIC-based HTTP, 0-RTT resume', cat: 'protocol', module: 'shared', src: 'RFC 9114' },
        { name: 'WebSocket', desc: 'Full-duplex persistent connection over HTTP', cat: 'protocol', module: 'shared', src: 'RFC 6455' },
        { name: 'WireGuard', desc: 'Modern kernel-level VPN tunnel', cat: 'protocol', module: 'net', src: 'Donenfeld 2017' },
        { name: 'DNS-over-HTTPS', desc: 'Encrypted DNS queries via HTTPS', cat: 'protocol', module: 'net', src: 'RFC 8484' },
        { name: 'TURN / STUN / ICE', desc: 'NAT traversal relay, binding, connectivity', cat: 'protocol', module: 'shared', src: 'RFC 8656/8489/8445' },
        // Stream
        { name: 'Bitrate Tier Management', desc: 'Rural 40k / Basic 96k / Clear 200k / Ultra 500k', cat: 'stream', module: 'stream', src: 'FMA Eng' },
        { name: 'Container Format Engine', desc: 'MP4, H.265/HEVC, HEIC, Apple HEIF encoding', cat: 'stream', module: 'stream', src: 'ISO 14496-12' },
        { name: 'Logarithmic Bandwidth Scaling', desc: '3.5:1 ratio, 50-1000 kbps adaptive range', cat: 'stream', module: 'stream', src: 'FMA Eng' },
        { name: 'Real-time Stream Canvas', desc: 'Particle visualization of data flow across carriers', cat: 'stream', module: 'stream', src: 'FMA Eng' },
        { name: 'Bandwidth Graph', desc: 'Live 60-second rolling bandwidth chart', cat: 'stream', module: 'stream', src: 'FMA Eng' },
        // Security
        { name: 'Okta SSO Bypass', desc: 'TLS 1.3 wrap around identity provider', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'MS Defender Bypass', desc: 'Packet normalization for endpoint detection', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'Cloudflare ZT Bypass', desc: 'HTTPS tunnel with pipe rotation', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'CrowdStrike Bypass', desc: 'MTU conformance for EDR evasion', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'Cisco Umbrella Bypass', desc: 'SNI masking for DNS/proxy bypass', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'FortiGate Traversal', desc: 'HTTPS tunnel + MTU conform + DPI evasion', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'Check Point FW-1 Traversal', desc: 'TLS 1.3 + SNI masking + port cycling', cat: 'security', module: 'net', src: 'FMA Eng' },
        // Codecs
        { name: 'H.264 / MP4', desc: 'Universal baseline, hardware decode everywhere', cat: 'codec', module: 'shared', src: 'ITU-T H.264' },
        { name: 'H.265 / HEVC', desc: '50% smaller than H.264 at same quality', cat: 'codec', module: 'shared', src: 'ITU-T H.265' },
        { name: 'HEIC / HEIF', desc: 'Apple native still image, 50% smaller than JPEG', cat: 'codec', module: 'shared', src: 'ISO 23008-12' },
        { name: 'VP9', desc: 'Google/YouTube standard, royalty-free', cat: 'codec', module: 'shared', src: 'Google WebM' },
        { name: 'AV1', desc: 'Next-gen royalty-free, 30% improvement over HEVC', cat: 'codec', module: 'shared', src: 'AOMedia' },
        { name: 'Opus', desc: 'WebRTC default audio codec, 6-510 kbps', cat: 'codec', module: 'shared', src: 'RFC 6716' },
        { name: 'HLS / DASH', desc: 'Adaptive bitrate streaming protocols', cat: 'codec', module: 'shared', src: 'RFC 8216 / ISO 23009' },
        // Routing
        { name: 'Dirac Line Length Calculator', desc: 'Fiber propagation at c * 0.67 + socket-port delay', cat: 'routing', module: 'net', src: 'Dirac Model' },
        { name: 'SNI Domain Masking', desc: 'Server Name Indication camouflage for DPI evasion', cat: 'routing', module: 'net', src: 'RFC 6066' },
        { name: 'Warm Standby Pool', desc: '2 pre-authenticated backup connections ready', cat: 'routing', module: 'net', src: 'FMA Eng' },
        // Platform
        { name: 'iOS 15+ Full Support', desc: 'Safari WebRTC, HEIF/HEVC native, Network Extension API', cat: 'platform', module: 'shared', src: 'Apple' },
        { name: 'Android 12+ Full Support', desc: 'Chrome WebRTC, VPN service API, H.265 decode', cat: 'platform', module: 'shared', src: 'Google' },
        { name: 'Windows/macOS/Linux Desktop', desc: 'Native app + browser, all protocols supported', cat: 'platform', module: 'shared', src: 'Multi-platform' },
        { name: 'Smart TV Support', desc: 'WebOS/Tizen HLS/DASH streaming, limited WebRTC', cat: 'platform', module: 'shared', src: 'LG/Samsung' },
        // Field
        { name: 'Coverage Map', desc: 'Grid-based coverage zone visualization with POIs', cat: 'network', module: 'field', src: 'FMA Eng' },
        { name: 'Camera Viewfinder', desc: 'Photo/Video/Stream modes with cloud upload', cat: 'stream', module: 'field', src: 'FMA Eng' },
        { name: 'Haversine Distance', desc: 'Great-circle distance calculation between markers', cat: 'routing', module: 'field', src: 'Haversine Formula' },
        // Benchmark
        { name: 'PCI DSS 4.0 Compliance', desc: 'Payment Card Industry Data Security Standard tests', cat: 'security', module: 'bench', src: 'PCI SSC' },
        { name: 'Byte-Level Verification', desc: 'Checksum, parity, CRC, SHA-256 integrity tests', cat: 'security', module: 'bench', src: 'FIPS / NIST' },
        // TCP/IP Stack (from PDF reference)
        { name: 'DNS', desc: 'Domain Name System - A/AAAA/CNAME/MX/PTR record resolution', cat: 'protocol', module: 'shared', src: 'RFC 1035' },
        { name: 'DHCP', desc: 'Dynamic Host Configuration - IP lease, subnet, gateway, DNS', cat: 'protocol', module: 'net', src: 'RFC 2131' },
        { name: 'FTP / SFTP', desc: 'File Transfer Protocol, command + data channel, secure variant', cat: 'protocol', module: 'shared', src: 'RFC 959' },
        { name: 'SMTP', desc: 'Simple Mail Transfer Protocol - email delivery', cat: 'protocol', module: 'shared', src: 'RFC 5321' },
        { name: 'SNMP', desc: 'Network management - manager/agent model, MIB database', cat: 'protocol', module: 'net', src: 'RFC 3416' },
        { name: 'SSH v1-3', desc: 'Secure Shell - encrypted admin, tunneling, port forwarding', cat: 'protocol', module: 'shared', src: 'RFC 4253' },
        { name: 'ARP', desc: 'Address Resolution Protocol - IPv4 to MAC mapping', cat: 'protocol', module: 'net', src: 'RFC 826' },
        { name: 'ICMP', desc: 'Internet Control Message Protocol - ping, traceroute, errors', cat: 'protocol', module: 'net', src: 'RFC 792' },
        { name: 'BGP', desc: 'Border Gateway Protocol - inter-AS routing, iBGP/eBGP', cat: 'routing', module: 'net', src: 'RFC 4271' },
        { name: 'OSPF', desc: 'Open Shortest Path First - link-state routing, SPF algorithm', cat: 'routing', module: 'net', src: 'RFC 2328' },
        { name: 'GRE', desc: 'Generic Routing Encapsulation - IP Protocol 47 tunneling', cat: 'protocol', module: 'net', src: 'RFC 2784' },
        { name: 'IKE v1/v2', desc: 'Internet Key Exchange - IPsec tunnel negotiation', cat: 'protocol', module: 'net', src: 'RFC 7296' },
        { name: 'PPTP VPN', desc: 'Point-to-Point Tunneling - legacy VPN, TCP 1723 + GRE', cat: 'protocol', module: 'net', src: 'RFC 2637' },
        { name: 'IPv4 / IPv6 Sockets', desc: 'AF_INET (32-bit) and AF_INET6 (128-bit) addressing', cat: 'network', module: 'shared', src: 'RFC 791/8200' },
        { name: 'CIDR Subnet Calculator', desc: '/27, /24, /16 subnet masks, usable host calculation', cat: 'network', module: 'net', src: 'RFC 4632' },
        { name: 'DNS Resolver Comparison', desc: 'Cloudflare 1.1.1.1 vs Google 8.8.8.8 vs Quad9 9.9.9.9', cat: 'network', module: 'net', src: 'Anycast DNS' },
        { name: 'Cisco Aruba Traversal', desc: 'Wireless NGFW broadcast-safe encapsulation, 802.1X', cat: 'security', module: 'net', src: 'FMA Eng' },
        { name: 'Aircraft/Offline Mode', desc: 'All imports bundled for airplane network operation', cat: 'platform', module: 'shared', src: 'FMA Eng' }
    ],

    sources: {
        ietf: [
            { ref: 'RFC 8446', title: 'TLS 1.3 Protocol', year: 2018 },
            { ref: 'RFC 9147', title: 'DTLS 1.3', year: 2022 },
            { ref: 'RFC 9000', title: 'QUIC Transport Protocol', year: 2021 },
            { ref: 'RFC 8825', title: 'WebRTC Overview', year: 2021 },
            { ref: 'RFC 3711', title: 'Secure Real-time Transport Protocol', year: 2004 },
            { ref: 'RFC 3261', title: 'SIP Session Initiation Protocol', year: 2002 },
            { ref: 'RFC 3550', title: 'RTP Real-time Transport Protocol', year: 2003 },
            { ref: 'RFC 9293', title: 'TCP Transmission Control Protocol', year: 2022 },
            { ref: 'RFC 768', title: 'UDP User Datagram Protocol', year: 1980 },
            { ref: 'RFC 9260', title: 'SCTP Stream Control Transmission', year: 2022 },
            { ref: 'RFC 9113', title: 'HTTP/2', year: 2022 },
            { ref: 'RFC 9114', title: 'HTTP/3', year: 2022 },
            { ref: 'RFC 6455', title: 'WebSocket Protocol', year: 2011 },
            { ref: 'RFC 8656', title: 'TURN Traversal Using Relays', year: 2020 },
            { ref: 'RFC 8489', title: 'STUN Session Traversal Utilities', year: 2020 },
            { ref: 'RFC 8445', title: 'ICE Interactive Connectivity', year: 2018 },
            { ref: 'RFC 8484', title: 'DNS-over-HTTPS', year: 2018 },
            { ref: 'RFC 7252', title: 'CoAP Constrained Application Protocol', year: 2014 },
            { ref: 'RFC 6716', title: 'Opus Interactive Audio Codec', year: 2012 },
            { ref: 'RFC 8216', title: 'HTTP Live Streaming (HLS)', year: 2017 },
            { ref: 'RFC 2131', title: 'DHCP Dynamic Host Configuration', year: 1997 },
            { ref: 'RFC 6066', title: 'TLS Extensions (SNI)', year: 2011 },
            { ref: 'RFC 7413', title: 'TCP Fast Open', year: 2014 },
            { ref: 'RFC 4787', title: 'NAT Behavioral Requirements for UDP', year: 2007 }
        ],
        itu: [
            { ref: 'ITU-T H.323', title: 'Packet-Based Multimedia Communications', year: 2022 },
            { ref: 'ITU-T H.264', title: 'AVC Advanced Video Coding', year: 2003 },
            { ref: 'ITU-T H.265', title: 'HEVC High Efficiency Video Coding', year: 2013 },
            { ref: 'ISO 14496-10', title: 'MPEG-4 Part 10: AVC', year: 2003 },
            { ref: 'ISO 14496-12', title: 'ISO Base Media File Format (MP4)', year: 2022 },
            { ref: 'ISO 23008-2', title: 'MPEG-H Part 2: HEVC', year: 2013 },
            { ref: 'ISO 23008-12', title: 'HEIF High Efficiency Image Format', year: 2017 },
            { ref: 'ISO 23009-1', title: 'MPEG-DASH', year: 2022 },
            { ref: '3GPP TS 23.501', title: '5G System Architecture', year: 2024 },
            { ref: '3GPP TS 23.502', title: '5G System Procedures', year: 2024 },
            { ref: '3GPP TS 38.300', title: 'NR/5G RAN Overall Description', year: 2024 },
            { ref: 'ETSI MEC 003', title: 'Multi-access Edge Computing Framework', year: 2022 }
        ],
        industry: [
            { ref: 'OASIS MQTT v5.0', title: 'Message Queuing Telemetry Transport', year: 2019 },
            { ref: 'W3C WebRTC', title: 'Real-Time Communication in Browsers', year: 2024 },
            { ref: 'O-RAN WG', title: 'Open RAN Architecture', year: 2024 },
            { ref: 'WireGuard', title: 'Fast Modern Secure VPN', year: 2017 },
            { ref: 'gRPC / Protobuf', title: 'HTTP/2-Based RPC Framework', year: 2015 },
            { ref: 'WebTransport', title: 'W3C/IETF Bidirectional Transport', year: 2024 },
            { ref: 'WebCodecs', title: 'W3C Low-Level Codec Access API', year: 2024 }
        ],
        codec: [
            { ref: 'VP9', title: 'Google VP9 Video Codec', year: 2013 },
            { ref: 'AV1', title: 'Alliance for Open Media Video 1', year: 2018 },
            { ref: 'Opus', title: 'Xiph.Org Interactive Audio Codec', year: 2012 },
            { ref: 'ISO 14496-3', title: 'AAC Advanced Audio Coding', year: 1997 },
            { ref: 'NIST SP 800-113', title: 'SSL/TLS VPN Guidelines', year: 2008 },
            { ref: 'NIST SP 800-77r1', title: 'IPsec VPN Guidelines', year: 2020 },
            { ref: 'IEEE 802.1X', title: 'Port-Based Network Access Control', year: 2020 },
            { ref: 'FIPS 197', title: 'AES Advanced Encryption Standard', year: 2001 },
            { ref: 'PCI DSS 4.0', title: 'Payment Card Industry Data Security', year: 2022 }
        ]
    },

    deps: [
        { from: 'Suite Dashboard', to: 'All Modules', desc: 'Unified launcher and feature index', color: '#06b6d4' },
        { from: 'Network Tester', to: 'Stream Tester', desc: 'Shared carrier pipe engine and heartbeat', color: '#3b82f6' },
        { from: 'Network Tester', to: 'Field Streamer', desc: 'Shared carrier management and events', color: '#10b981' },
        { from: 'Stream Tester', to: 'Field Streamer', desc: 'Shared codec/format/bitrate engine', color: '#8b5cf6' },
        { from: 'Benchmark AI', to: 'All Modules', desc: 'Byte-level verification baseline', color: '#f97316' },
        { from: 'Quality & FW', to: 'Network Tester', desc: 'Firewall traversal and protocol compliance', color: '#f59e0b' }
    ],

    stack: [
        { name: 'HTML5 / CSS3', type: 'Frontend', desc: 'Semantic markup, CSS Grid/Flexbox, custom properties' },
        { name: 'Vanilla JavaScript', type: 'Logic', desc: 'Zero dependencies, Canvas 2D, localStorage' },
        { name: 'C++17', type: 'Core Engine', desc: 'Header-only library, constexpr, std::array' },
        { name: 'Canvas 2D API', type: 'Visualization', desc: 'Galaxy map, topology, coverage, derima diagrams' },
        { name: 'JetBrains Mono', type: 'Typography', desc: 'Monospace font optimized for code/data display' },
        { name: 'WebRTC APIs', type: 'Real-time', desc: 'getUserMedia, RTCPeerConnection, MediaRecorder' },
        { name: 'Web Crypto API', type: 'Security', desc: 'AES-GCM, SHA-256, PBKDF2 key derivation' },
        { name: 'Service Workers', type: 'Offline', desc: 'Cache-first strategy for offline operation' }
    ],

    init() {
        this.renderProducts();
        this.renderStats();
        this.renderFeatures();
        this.renderArchitecture();
        this.renderSources();
    },

    show(section) {
        this.activeSection = section;
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.snav').forEach(n => n.classList.remove('active'));
        document.getElementById('sec-' + section).classList.add('active');
        document.querySelector('[data-section="' + section + '"]').classList.add('active');
        if (section === 'architecture') this.drawArchCanvas();
    },

    renderProducts() {
        const el = document.getElementById('product-grid');
        el.innerHTML = this.products.map(p => {
            const statsHtml = Object.entries(p.stats).map(([k, v]) =>
                '<div class="prod-stat"><div class="prod-stat-label">' + k + '</div><div class="prod-stat-value" style="color:' + p.color + '">' + v + '</div></div>'
            ).join('');
            const tagsHtml = p.tags.map(t => '<span class="prod-tag">' + t + '</span>').join('');
            const launchAttr = p.path ? 'onclick="window.open(\'' + p.path + '\', \'_blank\')"' : 'onclick="alert(\'C++ module - no web UI. See sw-tester/ directory.\')"';
            return '<div class="product-card ' + p.id + '">' +
                '<div class="prod-header"><div class="prod-icon" style="background:' + p.color + '">' + p.icon + '</div>' +
                '<div><div class="prod-name">' + p.name + '</div><div class="prod-version">' + p.version + '</div></div></div>' +
                '<div class="prod-desc">' + p.desc + '</div>' +
                '<div class="prod-features">' + tagsHtml + '</div>' +
                '<div class="prod-stats">' + statsHtml + '</div>' +
                '<button class="prod-launch" ' + launchAttr + '>LAUNCH</button></div>';
        }).join('');
    },

    renderStats() {
        const el = document.getElementById('stats-bar');
        const stats = [
            { n: 6, l: 'Modules', c: '#06b6d4' },
            { n: 40, l: 'Protocols', c: '#3b82f6' },
            { n: 60, l: 'Sources', c: '#8b5cf6' },
            { n: 13, l: 'Firewalls', c: '#f59e0b' },
            { n: 11, l: 'Codecs', c: '#10b981' },
            { n: 278, l: 'Tests', c: '#f97316' }
        ];
        el.innerHTML = stats.map(s =>
            '<div class="stat-card"><div class="stat-number" style="color:' + s.c + '">' + s.n + '</div><div class="stat-label">' + s.l + '</div></div>'
        ).join('');
    },

    renderFeatures() {
        this.filterFeats('all');
    },

    filterFeats(cat) {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.toggle('active', b.textContent.toLowerCase() === cat));
        const filtered = cat === 'all' ? this.features : this.features.filter(f => f.cat === cat);
        const el = document.getElementById('feat-index');
        const cats = {};
        filtered.forEach(f => { if (!cats[f.cat]) cats[f.cat] = []; cats[f.cat].push(f); });
        let html = '';
        for (const [c, feats] of Object.entries(cats)) {
            html += '<div class="feat-section-title">' + c.toUpperCase() + ' (' + feats.length + ')</div>';
            html += feats.map(f =>
                '<div class="feat-row"><div class="feat-dot" style="background:' + (this.products.find(p => p.id === f.module) || {color:'#3b82f6'}).color + '"></div>' +
                '<div class="feat-name">' + f.name + '</div>' +
                '<div class="feat-desc">' + f.desc + '</div>' +
                '<span class="feat-module ' + f.module + '">' + f.module.toUpperCase() + '</span>' +
                '<span class="feat-src">' + f.src + '</span></div>'
            ).join('');
        }
        el.innerHTML = html;
    },

    renderArchitecture() {
        const depsEl = document.getElementById('arch-deps');
        depsEl.innerHTML = this.deps.map(d =>
            '<div class="arch-row"><div class="arch-dot" style="background:' + d.color + '"></div>' +
            '<div class="arch-name">' + d.from + '</div>' +
            '<span style="color:var(--dim);font-size:12px">&#8594;</span>' +
            '<div class="arch-name">' + d.to + '</div>' +
            '<div class="arch-desc">' + d.desc + '</div></div>'
        ).join('');

        const stackEl = document.getElementById('arch-stack');
        stackEl.innerHTML = this.stack.map(s =>
            '<div class="arch-row"><div class="arch-dot" style="background:var(--cyan)"></div>' +
            '<div class="arch-name">' + s.name + '</div>' +
            '<div class="arch-desc">' + s.desc + '</div>' +
            '<span class="arch-badge">' + s.type + '</span></div>'
        ).join('');
    },

    drawArchCanvas() {
        const canvas = document.getElementById('arch-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = 800;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        // Grid
        ctx.strokeStyle = 'rgba(255,255,255,0.02)';
        ctx.lineWidth = 1;
        for (let i = 0; i < 30; i++) {
            ctx.beginPath(); ctx.moveTo(i * w / 30, 0); ctx.lineTo(i * w / 30, h); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i * h / 15); ctx.lineTo(w, i * h / 15); ctx.stroke();
        }

        const modules = [
            { name: 'SUITE DASHBOARD', x: w * 0.5, y: 60, color: '#06b6d4', r: 35 },
            { name: 'NETWORK TESTER', x: w * 0.2, y: 220, color: '#06b6d4', r: 30 },
            { name: 'STREAM TESTER', x: w * 0.5, y: 220, color: '#8b5cf6', r: 30 },
            { name: 'FIELD STREAMER', x: w * 0.8, y: 220, color: '#10b981', r: 30 },
            { name: 'BENCHMARK AI', x: w * 0.3, y: 380, color: '#f97316', r: 28 },
            { name: 'PROPERTY CLOUD', x: w * 0.7, y: 380, color: '#3b82f6', r: 28 }
        ];

        // Connections from suite to all
        modules.slice(1).forEach(m => {
            ctx.beginPath();
            ctx.moveTo(modules[0].x, modules[0].y + modules[0].r);
            ctx.quadraticCurveTo((modules[0].x + m.x) / 2, (modules[0].y + m.y) / 2 - 20, m.x, m.y - m.r);
            ctx.strokeStyle = modules[0].color + '30';
            ctx.lineWidth = 2;
            ctx.stroke();
        });

        // Cross-connections
        const conns = [[1, 2], [1, 3], [2, 3], [4, 1], [4, 2]];
        conns.forEach(([a, b]) => {
            ctx.beginPath();
            ctx.moveTo(modules[a].x + modules[a].r, modules[a].y);
            ctx.quadraticCurveTo((modules[a].x + modules[b].x) / 2, (modules[a].y + modules[b].y) / 2 + 15, modules[b].x - modules[b].r, modules[b].y);
            ctx.strokeStyle = modules[a].color + '25';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        });

        // Nodes
        modules.forEach(m => {
            ctx.beginPath();
            ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2);
            ctx.fillStyle = m.color + '15';
            ctx.fill();
            ctx.strokeStyle = m.color + '50';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(m.x, m.y, 8, 0, Math.PI * 2);
            ctx.fillStyle = m.color;
            ctx.fill();

            ctx.font = 'bold 16px monospace';
            ctx.fillStyle = m.color;
            ctx.textAlign = 'center';
            ctx.fillText(m.name, m.x, m.y + m.r + 20);
        });

        // Title
        ctx.font = 'bold 18px monospace';
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.textAlign = 'center';
        ctx.fillText('AI2ORBIT SUITE ARCHITECTURE', w / 2, h - 20);
    },

    renderSources() {
        const render = (id, items) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.innerHTML = items.map(s =>
                '<div class="src-row"><div class="src-ref">' + s.ref + '</div>' +
                '<div class="src-title">' + s.title + '</div>' +
                '<span class="src-year">' + s.year + '</span></div>'
            ).join('');
        };
        render('src-ietf', this.sources.ietf);
        render('src-itu', this.sources.itu);
        render('src-industry', this.sources.industry);
        render('src-codec', this.sources.codec);
    }
};

window.addEventListener('load', () => SUITE.init());
window.addEventListener('resize', () => { if (SUITE.activeSection === 'architecture') SUITE.drawArchCanvas(); });
