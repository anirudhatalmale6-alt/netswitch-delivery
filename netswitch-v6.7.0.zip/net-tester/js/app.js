// NetSwitch Network Tester v1.0.0
// FMA Engineering 2026 - Windows Desktop

const NT = {
    activePage: 'network',
    streaming: false,
    stillMode: false,
    activeTier: null,
    activeFormat: 'mp4',
    elapsed: 0,
    totalBytes: 0,
    packetCount: 0,
    segmentCount: 0,
    failoverCount: 0,
    recoveryCount: 0,
    graphData: [],
    segments: [],
    events: [],
    intervals: {},
    heartbeats: {},
    particles: [],
    animFrame: null,
    aiMode: true,
    manualFailover: false,
    dhcpReroute: false,
    ipEndangered: false,
    fwBypassPorts: [443, 3478, 8443, 50000],

    // Network providers with devices
    providers: [
        { id: 'elisa5g',   name: 'Elisa 5G',           type: 'Carrier',    device: '5G SA n78',            region: 'EU-FI',   color: '#3b82f6', active: true,  latencyBase: 8 },
        { id: 'ee-se',     name: 'EE Sweden',           type: 'Carrier',    device: '5G n78/n258',          region: 'EU-SE',   color: '#8b5cf6', active: true,  latencyBase: 11 },
        { id: 'vodafone',  name: 'Vodafone UK',         type: 'Lightcable', device: 'FTTP 1Gbps',           region: 'UK',      color: '#ec4899', active: true,  latencyBase: 6 },
        { id: 'verizon',   name: 'Verizon US East',     type: 'Carrier',    device: '5G UW mmWave',         region: 'US-East', color: '#ef4444', active: true,  latencyBase: 12 },
        { id: 'ms-dc',     name: 'MS DC Kansas',        type: 'Datacenter', device: 'Azure Midwest',        region: 'US-MW',   color: '#f59e0b', active: false, latencyBase: 4 },
        { id: 'pacbell',   name: 'PacBell West US',     type: 'Carrier',    device: 'Fiber GPON',           region: 'US-West', color: '#06b6d4', active: false, latencyBase: 10 },
        { id: 'sfgate-fb', name: 'SFGate FB',           type: 'Cable',      device: 'Facebook Data Cable',  region: 'US-West', color: '#f97316', active: false, latencyBase: 3 },
        { id: 'fb-goog',   name: 'FB-Google DC',        type: 'Datacenter', device: 'Interconnect 100G',    region: 'US-West', color: '#10b981', active: false, latencyBase: 2 }
    ],

    // Enterprise security stack
    secStack: [
        { name: 'Okta SSO',          type: 'Identity',  bypass: 'TLS 1.3 Wrap',     status: 'clear' },
        { name: 'Microsoft Defender', type: 'Endpoint',  bypass: 'Packet Normalize',  status: 'clear' },
        { name: 'Microsoft Teams',   type: 'Comms',     bypass: 'WebRTC Tunnel',     status: 'clear' },
        { name: 'Skype',             type: 'Comms',     bypass: 'TURN Relay',        status: 'clear' },
        { name: 'Google Workspace',  type: 'Cloud',     bypass: 'gRPC Multiplex',    status: 'clear' },
        { name: 'AWS CloudFront',    type: 'CDN',       bypass: 'Edge Cache',        status: 'clear' },
        { name: 'MS OneDrive',       type: 'Storage',   bypass: 'Chunk Upload',      status: 'clear' },
        { name: 'Cisco Umbrella',    type: 'DNS/Proxy', bypass: 'SNI Masking',       status: 'clear' },
        { name: 'CrowdStrike',      type: 'EDR',       bypass: 'MTU Conform',       status: 'clear' },
        { name: 'Cloudflare ZT',    type: 'SASE',      bypass: 'HTTPS Tunnel',      status: 'clear' },
        { name: 'VMware SASE',      type: 'SD-WAN',    bypass: 'Pipe Rotation',     status: 'clear' },
        { name: 'APAC VPN Gateway', type: 'Regional',  bypass: 'Multi-Session',     status: 'clear' }
    ],

    // Global socket-port latency points (Dirac model: 0.002 - 2 ns)
    worldPoints: [
        { name: 'New York',    lat: 40.7, lng: -74.0,   ns: 0.003, socketPort: 443 },
        { name: 'London',      lat: 51.5, lng: -0.1,    ns: 0.008, socketPort: 443 },
        { name: 'Frankfurt',   lat: 50.1, lng: 8.7,     ns: 0.005, socketPort: 8443 },
        { name: 'Helsinki',    lat: 60.2, lng: 24.9,    ns: 0.012, socketPort: 443 },
        { name: 'Tokyo',       lat: 35.7, lng: 139.7,   ns: 0.004, socketPort: 443 },
        { name: 'Singapore',   lat: 1.3,  lng: 103.8,   ns: 0.007, socketPort: 8080 },
        { name: 'Sydney',      lat: -33.9,lng: 151.2,   ns: 0.015, socketPort: 443 },
        { name: 'Sao Paulo',   lat: -23.5,lng: -46.6,   ns: 0.045, socketPort: 443 },
        { name: 'Mumbai',      lat: 19.1, lng: 72.9,    ns: 0.035, socketPort: 443 },
        { name: 'Seoul',       lat: 37.6, lng: 127.0,   ns: 0.006, socketPort: 443 },
        { name: 'Dubai',       lat: 25.2, lng: 55.3,    ns: 0.022, socketPort: 8443 },
        { name: 'Los Angeles', lat: 34.1, lng: -118.2,  ns: 0.005, socketPort: 443 }
    ],

    // Bitrate tiers
    tiers: [
        { rate: 40,  label: 'RURAL',   quality: 'Low', color: '#f59e0b' },
        { rate: 96,  label: 'BASIC',   quality: 'SD',  color: '#3b82f6' },
        { rate: 200, label: 'CLEAR',   quality: '4K',  color: '#10b981' },
        { rate: 500, label: 'ULTRA',   quality: 'Max', color: '#8b5cf6' }
    ],

    formats: {
        mp4:  { label: 'MP4',       codec: 'H.264' },
        hevc: { label: 'H.265',     codec: 'HEVC' },
        heic: { label: 'HEIC',      codec: 'HEVC-Still' },
        heif: { label: 'Apple HEIF',codec: 'H.264-Still' }
    },

    // MNO-Hyperscaler-Vendor Topology
    mnos: [
        { name: 'AT&T',             region: 'US',   color: '#00a8e0' },
        { name: 'Verizon',          region: 'US',   color: '#cd040b' },
        { name: 'Vodafone',         region: 'EU',   color: '#e60000' },
        { name: 'SK Telecom',       region: 'APAC', color: '#ea002c' },
        { name: 'KDDI',             region: 'APAC', color: '#ff6100' },
        { name: 'Telefonica',       region: 'EU',   color: '#0066ff' },
        { name: 'Telstra',          region: 'APAC', color: '#0d54ff' },
        { name: 'Rogers',           region: 'NA',   color: '#da291c' },
        { name: 'NTT Comms',        region: 'APAC', color: '#1f5ea8' },
        { name: 'Proximus',         region: 'EU',   color: '#6b2fa0' },
        { name: 'Etisalat',         region: 'MEA',  color: '#5ca829' },
        { name: 'Telkomsel',        region: 'APAC', color: '#ed1c24' },
        { name: 'LG U+',            region: 'APAC', color: '#e6007e' },
        { name: 'Orange',           region: 'EU',   color: '#ff7900' },
        { name: 'Telecom Italia',   region: 'EU',   color: '#009fdf' },
        { name: 'Wind/3',           region: 'EU',   color: '#ff6600' }
    ],
    hyperscalers: [
        { name: 'AWS',          services: ['Wavelength', 'Outpost', 'Edge Computing'], color: '#ff9900' },
        { name: 'Azure',        services: ['Edge Zone', 'Private Edge', 'Carrier Edge'], color: '#0078d4' },
        { name: 'Google Cloud', services: ['5G Core', 'MEC', 'Anthos'], color: '#4285f4' }
    ],
    vendors: [
        { name: 'Ericsson',     type: 'Core/RAN',  color: '#0082c9' },
        { name: 'NEC',          type: 'Core/RAN',  color: '#1414a0' },
        { name: 'Athonet',      type: '5G Core',   color: '#00b4d8' },
        { name: 'Mavenir',      type: 'OpenRAN',   color: '#e63946' },
        { name: 'Metaswitch',   type: 'vCore',     color: '#2d6a4f' },
        { name: 'Affirmed',     type: 'vCore',     color: '#7209b7' },
        { name: 'Nokia NDAC',   type: 'Core/RAN',  color: '#124191' },
        { name: 'Fujitsu',      type: '5G RAN',    color: '#e4002b' },
        { name: 'Samsung',      type: 'Core/RAN',  color: '#1428a0' }
    ],
    topoConnections: [
        { from: 'AT&T',      to: 'AWS',          via: 'Edge Computing' },
        { from: 'Verizon',    to: 'AWS',          via: 'Edge Computing' },
        { from: 'Vodafone',   to: 'AWS',          via: 'Edge Computing' },
        { from: 'SK Telecom', to: 'AWS',          via: 'Edge Computing' },
        { from: 'KDDI',       to: 'AWS',          via: 'Edge Computing' },
        { from: 'Telefonica', to: 'Azure',        via: 'Edge Computing' },
        { from: 'Telstra',    to: 'Azure',        via: 'Edge Computing' },
        { from: 'Rogers',     to: 'Azure',        via: 'Edge Computing' },
        { from: 'NTT Comms',  to: 'Azure',        via: 'Edge Computing' },
        { from: 'Proximus',   to: 'Azure',        via: 'Edge Computing' },
        { from: 'Etisalat',   to: 'Google Cloud', via: 'Edge Computing' },
        { from: 'Telkomsel',  to: 'Google Cloud', via: 'Edge Computing' },
        { from: 'LG U+',      to: 'Google Cloud', via: 'Edge Computing' },
        { from: 'Orange',     to: 'Google Cloud', via: 'Edge Computing' },
        { from: 'Telecom Italia', to: 'AWS',      via: 'Edge Computing' },
        { from: 'Wind/3',     to: 'Google Cloud', via: 'Edge Computing' },
        { from: 'Ericsson',   to: 'AWS',          via: '5G Core on AWS' },
        { from: 'NEC',        to: 'AWS',          via: '5G Core on AWS' },
        { from: 'Athonet',    to: 'AWS',          via: '5G Core on AWS' },
        { from: 'Mavenir',    to: 'AWS',          via: '5G RAN, 5G Core' },
        { from: 'Metaswitch', to: 'Azure',        via: '5G Core on Azure' },
        { from: 'Affirmed',   to: 'Azure',        via: '5G Core on Azure' },
        { from: 'Nokia NDAC', to: 'Google Cloud', via: '5G Core on GCP' },
        { from: 'Fujitsu',    to: 'Azure',        via: '5G RAN, MEC' },
        { from: 'Samsung',    to: 'Google Cloud', via: '5G Core on GCP' }
    ],

    init() {
        this.showPage('network');
        this.renderProviders();
        this.renderSecStack();
        this.renderWorldPoints();
        this.renderTiers();
        this.renderFormats();
        this.renderCarriers();
        this.initHeartbeats();
        this.updateControlPanel();
        this.renderTopology();
        this.renderFeatures();
        this.selectTier(200);
        this.setupCanvas();
        this.setupGraph();
        this.drawStream();
        this.updateAll();
    },

    // Page navigation
    showPage(page) {
        this.activePage = page;
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.getElementById('page-' + page).classList.add('active');
        document.querySelector('[data-page="' + page + '"]').classList.add('active');
        if (page === 'galaxy') this.drawGalaxy();
        if (page === 'topology') this.drawTopologyMap();
    },

    // Network Providers
    renderProviders() {
        const el = document.getElementById('provider-grid');
        el.innerHTML = this.providers.map((p, i) => `
            <div class="provider-card ${p.active ? 'active' : ''}" id="prov-${i}" onclick="NT.toggleProvider(${i})">
                <div class="prov-header">
                    <span class="prov-name">${p.name}</span>
                    <div class="prov-dot" style="background:${p.active ? p.color : '#333'}"></div>
                </div>
                <div class="prov-type">${p.type} | ${p.region}</div>
                <div class="prov-device">${p.device}</div>
                <div class="prov-latency" style="color:${p.color}">${p.latencyBase}ms base</div>
            </div>
        `).join('');
    },

    toggleProvider(idx) {
        this.providers[idx].active = !this.providers[idx].active;
        this.renderProviders();
        this.renderCarriers();
        this.initHeartbeats();
        this.updateAll();
    },

    getActiveProviders() {
        return this.providers.filter(p => p.active);
    },

    // Enterprise Security Stack
    renderSecStack() {
        const el = document.getElementById('sec-stack');
        el.innerHTML = this.secStack.map((s, i) => `
            <div class="stack-item" id="stack-${i}">
                <div class="stack-name">${s.name}</div>
                <div class="stack-type">${s.type} | ${s.bypass}</div>
                <div class="stack-status clear" id="stack-status-${i}">CLEAR</div>
            </div>
        `).join('');
    },

    tickSecStack() {
        if (!this.streaming) return;
        this.secStack.forEach((s, i) => {
            const el = document.getElementById('stack-status-' + i);
            if (!el) return;
            if (s.status === 'challenged') {
                s.status = 'bypassed';
                el.textContent = 'BYPASSED';
                el.className = 'stack-status bypassed';
                this.addEvent('BYPASS', s.name + ' via ' + s.bypass, 'success');
                setTimeout(() => { s.status = 'clear'; el.textContent = 'CLEAR'; el.className = 'stack-status clear'; }, 2000 + Math.random() * 3000);
            } else if (s.status === 'clear' && Math.random() < 0.05) {
                s.status = 'challenged';
                el.textContent = 'BLOCKED';
                el.className = 'stack-status blocked';
                this.addEvent('DETECT', s.name + ' (' + s.type + ') flagged', 'warn');
            }
        });
    },

    // World Latency Points
    renderWorldPoints() {
        const html = this.worldPoints.map(p => `
            <div class="world-pt">
                <div class="world-pt-name">${p.name}</div>
                <div class="world-pt-lat" style="color:${p.ns < 0.01 ? 'var(--green)' : p.ns < 0.03 ? 'var(--yellow)' : 'var(--orange)'}">${p.ns.toFixed(3)} ns</div>
                <div class="world-pt-ns">Port ${p.socketPort} | Dirac ${(p.ns * 1000).toFixed(1)} ps</div>
            </div>
        `).join('');
        document.querySelectorAll('#world-points, #world-points-lat').forEach(el => { el.innerHTML = html; });
    },

    // Latency calculator: line length -> delay
    calcLatency() {
        const km = parseFloat(document.getElementById('calc-km').value) || 0;
        const c = 299792.458; // speed of light km/s
        const fiberFactor = 0.67; // fiber refractive index
        const delayMs = (km / (c * fiberFactor)) * 1000;
        const delayNs = delayMs * 1e6;
        const delayPs = delayNs * 1000;
        const sockets = parseInt(document.getElementById('calc-sockets').value) || 1;
        const perSocketNs = 0.002 + Math.random() * 1.998; // 0.002 - 2 ns per socket
        const totalSocketNs = perSocketNs * sockets;

        document.getElementById('calc-ms').textContent = delayMs.toFixed(4) + ' ms';
        document.getElementById('calc-ns').textContent = delayNs.toFixed(2) + ' ns';
        document.getElementById('calc-ps').textContent = delayPs.toFixed(0) + ' ps';
        document.getElementById('calc-socket-ns').textContent = totalSocketNs.toFixed(3) + ' ns';
        document.getElementById('calc-total').textContent = (delayNs + totalSocketNs).toFixed(2) + ' ns total';
    },

    // Carrier Pipes (from active providers)
    renderCarriers() {
        const active = this.getActiveProviders();
        const html = active.map((p, i) => `
            <div class="carrier-row">
                <div class="carrier-dot" id="cdot-${i}" style="background:${p.color}"></div>
                <div class="carrier-name">${p.name}</div>
                <div class="carrier-bar-bg"><div class="carrier-bar" id="cbar-${i}" style="background:${p.color};width:0%"></div></div>
                <div class="carrier-kbps" id="ckbps-${i}">0 kbps</div>
            </div>
        `).join('');
        document.querySelectorAll('#carrier-list, [id="carrier-list"]').forEach(el => { el.innerHTML = html; });
    },

    // Heartbeat
    initHeartbeats() {
        this.heartbeats = {};
        this.getActiveProviders().forEach((p, i) => {
            this.heartbeats[i] = { alive: true, misses: 0, latency: p.latencyBase };
        });
        this.renderHeartbeats();
    },

    renderHeartbeats() {
        const active = this.getActiveProviders();
        const html = active.map((p, i) => {
            const hb = this.heartbeats[i] || { alive: true, misses: 0, latency: 0 };
            return `<div class="hb-item"><div class="hb-name" style="color:${p.color}">${p.name}</div>
                <div class="hb-dot" id="hbdot-${i}" style="background:${hb.alive ? '#10b981' : '#ef4444'}"></div>
                <div class="hb-ms" id="hbms-${i}">${hb.latency}ms</div>
                <div class="hb-miss" id="hbmiss-${i}">Miss: ${hb.misses}</div></div>`;
        }).join('');
        document.querySelectorAll('[id="hb-grid"]').forEach(el => { el.innerHTML = html; });
    },

    tickHeartbeat() {
        if (!this.streaming) return;
        const active = this.getActiveProviders();
        active.forEach((p, i) => {
            const hb = this.heartbeats[i];
            if (!hb) return;
            if (Math.random() < 0.06) {
                hb.misses++;
                hb.latency = 999;
                if (hb.misses >= 3) {
                    hb.alive = false;
                    this.failoverCount++;
                    this.addEvent('FAILOVER', p.name + ' dead (3 misses)', 'warn');
                }
            } else {
                hb.misses = 0;
                hb.latency = p.latencyBase + Math.floor(Math.random() * 20);
                hb.alive = true;
            }
            if (!hb.alive && Math.random() < 0.1) {
                hb.alive = true; hb.misses = 0;
                hb.latency = p.latencyBase + 5;
                this.recoveryCount++;
                this.addEvent('RECOVERY', p.name + ' back online', 'success');
            }
            const dot = document.getElementById('hbdot-' + i);
            const ms = document.getElementById('hbms-' + i);
            const miss = document.getElementById('hbmiss-' + i);
            if (dot) dot.style.background = hb.alive ? '#10b981' : '#ef4444';
            if (ms) ms.textContent = hb.latency + 'ms';
            if (miss) miss.textContent = 'Miss: ' + hb.misses;
        });
    },

    // Reset Switch / AI Toggle / IP-DHCP-Port controls
    resetSwitch() {
        if (this.streaming) this.stopStream();
        this.providers.forEach(p => { p.active = false; });
        this.providers[0].active = true;
        this.failoverCount = 0;
        this.recoveryCount = 0;
        this.events = [];
        this.segments = [];
        this.manualFailover = false;
        this.ipEndangered = false;
        this.dhcpReroute = false;
        this.secStack.forEach(s => s.status = 'clear');
        this.renderProviders();
        this.renderCarriers();
        this.renderSecStack();
        this.initHeartbeats();
        this.renderEvents();
        this.addEvent('RESET', 'Switch routing reset to default', 'info');
        this.updateAll();
        this.updateControlPanel();
    },

    toggleAI() {
        this.aiMode = !this.aiMode;
        this.addEvent('MODE', 'AI mode ' + (this.aiMode ? 'ENABLED' : 'DISABLED'), this.aiMode ? 'success' : 'warn');
        this.updateControlPanel();
    },

    toggleManualFailover() {
        this.manualFailover = !this.manualFailover;
        this.addEvent('FAILOVER', 'Manual failover mode ' + (this.manualFailover ? 'ON' : 'OFF'), 'info');
        this.updateControlPanel();
    },

    toggleIpEndangered() {
        this.ipEndangered = !this.ipEndangered;
        if (this.ipEndangered) {
            this.addEvent('IP-PROTECT', 'IP endangered routing ACTIVE - masking source IP', 'warn');
        } else {
            this.addEvent('IP-PROTECT', 'IP endangered routing OFF', 'info');
        }
        this.updateControlPanel();
    },

    toggleDhcpReroute() {
        this.dhcpReroute = !this.dhcpReroute;
        if (this.dhcpReroute) {
            this.addEvent('DHCP', 'DHCP reroute ACTIVE - requesting new lease', 'warn');
        } else {
            this.addEvent('DHCP', 'DHCP reroute OFF', 'info');
        }
        this.updateControlPanel();
    },

    cycleFwPort() {
        const portSets = [
            [443, 'HTTPS standard'],
            [3478, 'Skype/TURN relay'],
            [8443, 'Alt HTTPS'],
            [50000, 'Skype high port'],
            [80, 'HTTP fallback'],
            [8080, 'Proxy port'],
            [5060, 'SIP signaling'],
            [19302, 'Google STUN']
        ];
        const currentIdx = portSets.findIndex(p => p[0] === this.fwBypassPorts[0]);
        const next = portSets[(currentIdx + 1) % portSets.length];
        this.fwBypassPorts = [next[0]];
        this.addEvent('FW-PORT', 'Switched to port ' + next[0] + ' (' + next[1] + ')', 'info');
        this.updateControlPanel();
    },

    updateControlPanel() {
        const el = document.getElementById('ctrl-panel');
        if (!el) return;
        el.innerHTML = `
            <div class="ctrl-grid">
                <div class="ctrl-item">
                    <div class="ctrl-label">AI MODE</div>
                    <button class="ctrl-toggle ${this.aiMode ? 'on' : 'off'}" onclick="NT.toggleAI()">${this.aiMode ? 'AI ON' : 'NON-AI'}</button>
                </div>
                <div class="ctrl-item">
                    <div class="ctrl-label">FAILOVER</div>
                    <button class="ctrl-toggle ${this.manualFailover ? 'on warn' : 'off'}" onclick="NT.toggleManualFailover()">${this.manualFailover ? 'MANUAL' : 'AUTO'}</button>
                </div>
                <div class="ctrl-item">
                    <div class="ctrl-label">IP PROTECT</div>
                    <button class="ctrl-toggle ${this.ipEndangered ? 'on warn' : 'off'}" onclick="NT.toggleIpEndangered()">${this.ipEndangered ? 'ACTIVE' : 'OFF'}</button>
                </div>
                <div class="ctrl-item">
                    <div class="ctrl-label">DHCP REROUTE</div>
                    <button class="ctrl-toggle ${this.dhcpReroute ? 'on warn' : 'off'}" onclick="NT.toggleDhcpReroute()">${this.dhcpReroute ? 'ACTIVE' : 'OFF'}</button>
                </div>
                <div class="ctrl-item">
                    <div class="ctrl-label">FW PORT</div>
                    <button class="ctrl-toggle on" onclick="NT.cycleFwPort()">${this.fwBypassPorts[0]}</button>
                </div>
                <div class="ctrl-item">
                    <div class="ctrl-label">RESET</div>
                    <button class="ctrl-toggle reset" onclick="NT.resetSwitch()">RESET</button>
                </div>
            </div>
        `;
    },

    // Tiers and Formats
    renderTiers() {
        const el = document.getElementById('tier-row');
        el.innerHTML = this.tiers.map(t => `
            <div class="tier-btn" data-rate="${t.rate}" onclick="NT.selectTier(${t.rate})">
                <div class="tier-rate">${t.rate}</div>
                <div class="tier-unit">kbps</div>
                <div class="tier-label">${t.label} ${t.quality}</div>
            </div>
        `).join('');
    },

    selectTier(rate) {
        this.activeTier = this.tiers.find(t => t.rate === rate);
        document.querySelectorAll('.tier-btn').forEach(b => {
            b.classList.toggle('active', parseInt(b.dataset.rate) === rate);
        });
        this.updateAll();
    },

    renderFormats() {
        const el = document.getElementById('fmt-row');
        el.innerHTML = Object.entries(this.formats).map(([k, f]) =>
            `<button class="fmt-btn ${k === this.activeFormat ? 'active' : ''}" data-fmt="${k}" onclick="NT.setFormat('${k}')">${f.label}</button>`
        ).join('');
    },

    setFormat(f) {
        this.activeFormat = f;
        document.querySelectorAll('.fmt-btn').forEach(b => b.classList.toggle('active', b.dataset.fmt === f));
        this.updateAll();
    },

    // Stream / Stills control
    startStream() {
        if (this.streaming) return;
        this.streaming = true;
        this.stillMode = false;
        this.elapsed = 0;
        this.totalBytes = 0;
        this.packetCount = 0;
        this.segmentCount = 0;
        this.failoverCount = 0;
        this.recoveryCount = 0;
        this.graphData = [];
        this.segments = [];
        this.events = [];
        this.secStack.forEach(s => s.status = 'clear');
        this.renderSecStack();
        this.initHeartbeats();

        document.getElementById('btn-stream').className = 'ctrl-btn stop';
        document.getElementById('btn-stream').textContent = 'STOP';
        document.getElementById('btn-stream').onclick = () => this.stopStream();

        this.intervals.tick = setInterval(() => this.tick(), 500);
        this.intervals.graph = setInterval(() => this.tickGraph(), 1000);
        this.intervals.seg = setInterval(() => this.tickSegment(), 2000);
        this.intervals.hb = setInterval(() => { this.tickHeartbeat(); this.tickSecStack(); }, 1000);
        this.drawStream();
        this.updateAll();
    },

    startStills() {
        if (this.streaming) return;
        this.streaming = true;
        this.stillMode = true;
        this.elapsed = 0;
        this.totalBytes = 0;
        this.packetCount = 0;
        this.segmentCount = 0;
        this.failoverCount = 0;
        this.recoveryCount = 0;
        this.graphData = [];
        this.segments = [];
        this.events = [];
        this.setFormat(this.activeFormat.startsWith('he') ? this.activeFormat : 'heic');

        document.getElementById('btn-stills').className = 'ctrl-btn stop';
        document.getElementById('btn-stills').textContent = 'STOP';
        document.getElementById('btn-stills').onclick = () => this.stopStream();

        this.intervals.tick = setInterval(() => this.tick(), 500);
        this.intervals.graph = setInterval(() => this.tickGraph(), 1000);
        this.intervals.seg = setInterval(() => this.tickSegment(), 3000);
        this.intervals.hb = setInterval(() => { this.tickHeartbeat(); this.tickSecStack(); }, 1000);
        this.drawStream();
        this.updateAll();
    },

    stopStream() {
        this.streaming = false;
        Object.values(this.intervals).forEach(i => clearInterval(i));
        this.intervals = {};

        document.getElementById('btn-stream').className = 'ctrl-btn start';
        document.getElementById('btn-stream').textContent = 'STREAM';
        document.getElementById('btn-stream').onclick = () => this.startStream();
        document.getElementById('btn-stills').className = 'ctrl-btn';
        document.getElementById('btn-stills').textContent = 'STILLS';
        document.getElementById('btn-stills').onclick = () => this.startStills();

        document.querySelectorAll('.tier-btn').forEach(b => b.classList.remove('streaming'));
        this.updateAll();
    },

    tick() {
        if (!this.streaming || !this.activeTier) return;
        this.elapsed += 0.5;
        const rate = this.stillMode ? this.activeTier.rate * 0.4 : this.activeTier.rate;
        const bytesPerTick = (rate * 1000 / 8) * 0.5;
        const jitter = 1 + (Math.random() - 0.5) * 0.1;
        const actualBytes = Math.floor(bytesPerTick * jitter);
        this.totalBytes += actualBytes;
        this.packetCount++;

        // Distribute to carriers
        const active = this.getActiveProviders();
        const alive = active.filter((p, i) => this.heartbeats[i] && this.heartbeats[i].alive);
        if (alive.length > 0) {
            alive.forEach((p, i) => {
                const idx = active.indexOf(p);
                const share = rate / alive.length;
                const el = document.getElementById('cbar-' + idx);
                const kbps = document.getElementById('ckbps-' + idx);
                const dot = document.getElementById('cdot-' + idx);
                if (el) el.style.width = Math.min(100, (share / rate) * 100 + (Math.random() - 0.5) * 20) + '%';
                if (kbps) kbps.textContent = Math.round(share + (Math.random() - 0.5) * share * 0.2) + ' kbps';
                if (dot) dot.classList.add('active');
            });
        }

        this.updateAll();
    },

    tickGraph() {
        if (!this.streaming || !this.activeTier) return;
        const jitter = 1 + (Math.random() - 0.5) * 0.2;
        this.graphData.push(this.activeTier.rate * jitter);
        if (this.graphData.length > 60) this.graphData.shift();
        this.drawGraph();
    },

    tickSegment() {
        if (!this.streaming || !this.activeTier) return;
        this.segmentCount++;
        const fmt = this.formats[this.activeFormat];
        const active = this.getActiveProviders();
        const pipe = active.length > 0 ? active[Math.floor(Math.random() * active.length)] : { name: 'N/A' };
        const segBytes = Math.floor((this.activeTier.rate * 1000 / 8) * (this.stillMode ? 0.5 : 2));

        this.segments.push({ id: this.segmentCount, fmt: fmt.label, codec: fmt.codec, size: segBytes, carrier: pipe.name });
        if (this.segments.length > 20) this.segments.shift();
        this.renderSegments();
    },

    renderSegments() {
        const el = document.getElementById('seg-list');
        if (!el) return;
        el.innerHTML = this.segments.map(s =>
            `<div class="seg-row"><span class="seg-id">#${s.id}</span><span class="seg-fmt">${s.fmt}</span><span class="seg-codec">${s.codec}</span><span class="seg-size">${this.fmtBytes(s.size)}</span><span class="seg-carrier">${s.carrier}</span><span class="seg-ok">OK</span></div>`
        ).join('');
        el.scrollTop = el.scrollHeight;
    },

    // Event log
    addEvent(type, msg, level) {
        this.events.push({ time: this.elapsed, type, msg, level });
        if (this.events.length > 50) this.events.shift();
        this.renderEvents();
    },

    renderEvents() {
        const els = document.querySelectorAll('[id="event-log"]');
        if (els.length === 0) return;
        if (this.events.length === 0) { els.forEach(el => el.innerHTML = '<div class="evt-empty">No events yet.</div>'); return; }
        const html = this.events.slice(-15).reverse().map(e => {
            const color = e.level === 'warn' ? '#f59e0b' : e.level === 'success' ? '#10b981' : '#3b82f6';
            return `<div class="evt-line"><span class="evt-time">${this.fmtTime(e.time)}</span><span class="evt-type" style="color:${color}">${e.type}</span><span class="evt-msg">${e.msg}</span></div>`;
        }).join('');
        els.forEach(el => { el.innerHTML = html; });
    },

    // Galaxy Vector Map
    drawGalaxy() {
        const canvas = document.getElementById('galaxy-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        // Draw grid
        ctx.strokeStyle = 'rgba(255,255,255,0.03)';
        ctx.lineWidth = 1;
        for (let i = 0; i < 20; i++) {
            ctx.beginPath(); ctx.moveTo(i * w / 20, 0); ctx.lineTo(i * w / 20, h); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i * h / 20); ctx.lineTo(w, i * h / 20); ctx.stroke();
        }

        // Map world points to canvas (Mercator-like)
        const pts = this.worldPoints.map(p => ({
            ...p,
            x: ((p.lng + 180) / 360) * w,
            y: ((90 - p.lat) / 180) * h
        }));

        // Draw vectors between active providers' regions and world points
        const activeProviders = this.getActiveProviders();
        const provPoints = activeProviders.map(p => {
            const wp = pts.find(pt => {
                if (p.region === 'US') return pt.name === 'New York' || pt.name === 'Los Angeles';
                if (p.region === 'EU-FI') return pt.name === 'Helsinki';
                if (p.region === 'EU') return pt.name === 'London' || pt.name === 'Frankfurt';
                if (p.region === 'APAC') return pt.name === 'Tokyo' || pt.name === 'Singapore';
                return false;
            });
            return wp ? { ...wp, color: p.color, provName: p.name } : null;
        }).filter(Boolean);

        // Draw connection vectors
        provPoints.forEach(from => {
            pts.forEach(to => {
                if (from.name === to.name) return;
                ctx.beginPath();
                ctx.moveTo(from.x, from.y);
                // Curved line
                const cx = (from.x + to.x) / 2;
                const cy = Math.min(from.y, to.y) - 30;
                ctx.quadraticCurveTo(cx, cy, to.x, to.y);
                ctx.strokeStyle = from.color + '30';
                ctx.lineWidth = 1;
                ctx.stroke();
            });
        });

        // Draw world points
        pts.forEach(p => {
            const nsColor = p.ns < 0.01 ? '#10b981' : p.ns < 0.03 ? '#f59e0b' : '#f97316';
            ctx.beginPath();
            ctx.arc(p.x, p.y, 8, 0, Math.PI * 2);
            ctx.fillStyle = nsColor + '40';
            ctx.fill();
            ctx.beginPath();
            ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
            ctx.fillStyle = nsColor;
            ctx.fill();

            ctx.font = '18px monospace';
            ctx.fillStyle = 'rgba(255,255,255,0.7)';
            ctx.textAlign = 'center';
            ctx.fillText(p.name, p.x, p.y - 14);
            ctx.font = '14px monospace';
            ctx.fillStyle = nsColor;
            ctx.fillText(p.ns.toFixed(3) + 'ns', p.x, p.y + 22);
        });

        // Draw active provider markers
        provPoints.forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 12, 0, Math.PI * 2);
            ctx.strokeStyle = p.color;
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(p.x, p.y, 6, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.fill();
        });
    },

    // Stream visualization
    setupCanvas() {
        const canvas = document.getElementById('stream-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        this.particles = [];
    },

    drawStream() {
        const canvas = document.getElementById('stream-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        const draw = () => {
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.fillRect(0, 0, w, h);

            if (this.streaming && this.activeTier) {
                const rate = this.activeTier.rate;
                const count = Math.max(1, Math.floor(rate / 25));
                const active = this.getActiveProviders();

                for (let i = 0; i < count; i++) {
                    const p = active.length > 0 ? active[Math.floor(Math.random() * active.length)] : { color: '#3b82f6' };
                    this.particles.push({
                        x: Math.random() * w, y: h + 5,
                        vx: (Math.random() - 0.5) * 3, vy: -(2 + Math.random() * (rate / 40)),
                        size: 2 + Math.random() * 3, color: p.color, alpha: 0.8
                    });
                }

                this.particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.alpha -= 0.008; });
                this.particles = this.particles.filter(p => p.alpha > 0 && p.y > -10);
                this.particles.forEach(p => {
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fillStyle = p.color + Math.floor(p.alpha * 255).toString(16).padStart(2, '0');
                    ctx.fill();
                });

                ctx.font = 'bold 36px monospace';
                ctx.fillStyle = 'rgba(255,255,255,0.05)';
                ctx.textAlign = 'center';
                ctx.fillText((this.stillMode ? 'STILLS' : 'STREAM') + ' ' + rate + 'k', w / 2, h / 2);
            } else {
                ctx.font = 'bold 24px monospace';
                ctx.fillStyle = 'rgba(255,255,255,0.1)';
                ctx.textAlign = 'center';
                ctx.fillText('NETSWITCH READY', w / 2, h / 2);
            }
            this.animFrame = requestAnimationFrame(draw);
        };
        if (this.animFrame) cancelAnimationFrame(this.animFrame);
        draw();
    },

    // Bandwidth graph
    setupGraph() {
        const canvas = document.getElementById('graph-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
    },

    drawGraph() {
        const canvas = document.getElementById('graph-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;
        ctx.clearRect(0, 0, w, h);
        if (this.graphData.length < 2) return;

        ctx.beginPath();
        this.graphData.forEach((v, i) => {
            const x = (i / 59) * w;
            const y = h - (v / 600) * h;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 2;
        ctx.stroke();

        const lx = ((this.graphData.length - 1) / 59) * w;
        ctx.lineTo(lx, h); ctx.lineTo(0, h); ctx.closePath();
        const g = ctx.createLinearGradient(0, 0, 0, h);
        g.addColorStop(0, 'rgba(6,182,212,0.4)'); g.addColorStop(1, 'rgba(6,182,212,0)');
        ctx.fillStyle = g; ctx.fill();
    },

    updateAll() {
        const el = (id) => document.getElementById(id);
        if (el('s-state')) el('s-state').textContent = this.streaming ? (this.stillMode ? 'STILLS' : 'STREAMING') : 'IDLE';
        if (el('s-dot')) el('s-dot').style.background = this.streaming ? '#10b981' : '#64748b';
        if (el('s-tier')) el('s-tier').textContent = this.activeTier ? this.activeTier.rate + 'k' : '-';
        if (el('s-fmt')) el('s-fmt').textContent = this.formats[this.activeFormat].label;
        if (el('s-carriers')) el('s-carriers').textContent = this.getActiveProviders().length;
        if (el('s-bytes')) el('s-bytes').textContent = this.fmtBytes(this.totalBytes);
        if (el('s-fo')) el('s-fo').textContent = this.failoverCount + '/' + this.recoveryCount;
        if (el('s-elapsed')) el('s-elapsed').textContent = this.fmtTime(this.elapsed);
    },

    fmtBytes(b) {
        if (b < 1024) return b + 'B';
        if (b < 1048576) return (b / 1024).toFixed(1) + 'KB';
        return (b / 1048576).toFixed(2) + 'MB';
    },

    fmtTime(s) {
        const m = Math.floor(s / 60), sec = Math.floor(s % 60), ms = Math.floor((s % 1) * 10);
        return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec + '.' + ms;
    },

    // MNO Topology
    renderTopology() {
        // MNO list
        const mnoEl = document.getElementById('topo-mnos');
        if (mnoEl) mnoEl.innerHTML = this.mnos.map(m =>
            `<div class="topo-node"><div class="topo-node-dot" style="background:${m.color}"></div><div class="topo-node-name">${m.name}</div><div class="topo-node-type">${m.region}</div></div>`
        ).join('');

        // Hyperscaler list
        const hyperEl = document.getElementById('topo-hyper');
        if (hyperEl) hyperEl.innerHTML = this.hyperscalers.map(h =>
            `<div class="topo-node"><div class="topo-node-dot" style="background:${h.color}"></div><div class="topo-node-name">${h.name}</div><div class="topo-node-type">${h.services.join(', ')}</div></div>`
        ).join('');

        // Vendor list
        const vendorEl = document.getElementById('topo-vendors');
        if (vendorEl) vendorEl.innerHTML = this.vendors.map(v =>
            `<div class="topo-node"><div class="topo-node-dot" style="background:${v.color}"></div><div class="topo-node-name">${v.name}</div><div class="topo-node-type">${v.type}</div></div>`
        ).join('');

        // Connection list
        const listEl = document.getElementById('topo-list');
        if (listEl) listEl.innerHTML = this.topoConnections.map(c => {
            const fromObj = this.mnos.find(m => m.name === c.from) || this.vendors.find(v => v.name === c.from);
            const toObj = this.hyperscalers.find(h => h.name === c.to);
            const fc = fromObj ? fromObj.color : '#fff';
            const tc = toObj ? toObj.color : '#fff';
            return `<div class="topo-conn"><span class="topo-from" style="color:${fc}">${c.from}</span><span class="topo-arrow">&rarr;</span><span class="topo-to" style="color:${tc}">${c.to}</span><span class="topo-via">${c.via}</span></div>`;
        }).join('');
    },

    drawTopologyMap() {
        const canvas = document.getElementById('topo-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        // Grid
        ctx.strokeStyle = 'rgba(255,255,255,0.02)';
        ctx.lineWidth = 1;
        for (let i = 0; i < 30; i++) {
            ctx.beginPath(); ctx.moveTo(i * w / 30, 0); ctx.lineTo(i * w / 30, h); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i * h / 30); ctx.lineTo(w, i * h / 30); ctx.stroke();
        }

        // Column headers
        ctx.font = 'bold 20px monospace';
        ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillText('MOBILE OPERATORS', w * 0.15, 30);
        ctx.fillText('HYPERSCALERS', w * 0.5, 30);
        ctx.fillText('CORE/RAN VENDORS', w * 0.85, 30);

        // Place MNOs on left
        const mnoPositions = this.mnos.map((m, i) => ({
            ...m, x: w * 0.15, y: 55 + i * ((h - 70) / this.mnos.length)
        }));

        // Place Hyperscalers in center
        const hyperPositions = this.hyperscalers.map((h, i) => ({
            ...h, x: w * 0.5, y: h.name === 'AWS' ? h * 0.25 : h.name === 'Azure' ? h * 0.5 : h * 0.75
        }));
        // Fix positions
        hyperPositions[0].y = h * 0.25;
        hyperPositions[1].y = h * 0.50;
        hyperPositions[2].y = h * 0.75;

        // Place Vendors on right
        const vendorPositions = this.vendors.map((v, i) => ({
            ...v, x: w * 0.85, y: 55 + i * ((h - 70) / this.vendors.length)
        }));

        // Draw connections
        this.topoConnections.forEach(conn => {
            const fromMNO = mnoPositions.find(m => m.name === conn.from);
            const fromVendor = vendorPositions.find(v => v.name === conn.from);
            const from = fromMNO || fromVendor;
            const to = hyperPositions.find(h => h.name === conn.to);
            if (!from || !to) return;

            ctx.beginPath();
            ctx.moveTo(from.x + 60, from.y);
            const cpx = (from.x + to.x) / 2;
            ctx.quadraticCurveTo(cpx, (from.y + to.y) / 2, to.x - 40, to.y);
            ctx.strokeStyle = from.color + '40';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        });

        // Draw MNO nodes
        mnoPositions.forEach(m => {
            ctx.fillStyle = m.color + '20';
            ctx.beginPath(); ctx.arc(m.x, m.y, 12, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = m.color;
            ctx.beginPath(); ctx.arc(m.x, m.y, 5, 0, Math.PI * 2); ctx.fill();
            ctx.font = '14px monospace';
            ctx.fillStyle = m.color;
            ctx.textAlign = 'left';
            ctx.fillText(m.name, m.x + 18, m.y + 5);
        });

        // Draw Hyperscaler nodes (larger)
        hyperPositions.forEach(hs => {
            ctx.fillStyle = hs.color + '15';
            ctx.beginPath(); ctx.arc(hs.x, hs.y, 30, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = hs.color + '50';
            ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(hs.x, hs.y, 30, 0, Math.PI * 2); ctx.stroke();
            ctx.fillStyle = hs.color;
            ctx.beginPath(); ctx.arc(hs.x, hs.y, 8, 0, Math.PI * 2); ctx.fill();
            ctx.font = 'bold 18px monospace';
            ctx.fillStyle = hs.color;
            ctx.textAlign = 'center';
            ctx.fillText(hs.name, hs.x, hs.y + 48);
            ctx.font = '11px monospace';
            ctx.fillStyle = 'rgba(255,255,255,0.4)';
            ctx.fillText(hs.services[0], hs.x, hs.y + 62);
        });

        // Draw Vendor nodes
        vendorPositions.forEach(v => {
            ctx.fillStyle = v.color + '20';
            ctx.beginPath(); ctx.arc(v.x, v.y, 12, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = v.color;
            ctx.beginPath(); ctx.arc(v.x, v.y, 5, 0, Math.PI * 2); ctx.fill();
            ctx.font = '14px monospace';
            ctx.fillStyle = v.color;
            ctx.textAlign = 'right';
            ctx.fillText(v.name, v.x - 18, v.y + 5);
        });

        // Draw derima triangle
        this.drawDerima();
    },

    // Features & Compatibility Data
    featureProtocols: [
        { name: 'TLS 1.3',    cat: 'Encryption',   desc: 'Primary tunnel encryption, handshake 1-RTT', ports: [443, 8443], src: 'RFC 8446' },
        { name: 'DTLS 1.3',   cat: 'Encryption',   desc: 'UDP datagram encryption for real-time streams', ports: [443], src: 'RFC 9147' },
        { name: 'QUIC',       cat: 'Transport',     desc: '0-RTT connection, multiplexed UDP streams', ports: [443], src: 'RFC 9000' },
        { name: 'WebRTC',     cat: 'Real-time',     desc: 'Browser-native P2P audio/video/data channels', ports: [3478, 19302], src: 'W3C / IETF RFC 8825' },
        { name: 'SRTP',       cat: 'Media',         desc: 'Secure Real-time Transport Protocol for AV', ports: [5004], src: 'RFC 3711' },
        { name: 'SIP',        cat: 'Signaling',     desc: 'Session Initiation Protocol for call setup', ports: [5060, 5061], src: 'RFC 3261' },
        { name: 'H.323',      cat: 'Signaling',     desc: 'ITU-T multimedia signaling standard', ports: [1720], src: 'ITU-T H.323' },
        { name: 'RTP/RTCP',   cat: 'Media',         desc: 'Real-time Transport + control feedback', ports: [5004, 5005], src: 'RFC 3550' },
        { name: 'TCP',        cat: 'Transport',     desc: 'Reliable ordered delivery, flow control', ports: [80, 443], src: 'RFC 9293' },
        { name: 'UDP',        cat: 'Transport',     desc: 'Low-latency datagram delivery', ports: [53, 443], src: 'RFC 768' },
        { name: 'SCTP',       cat: 'Transport',     desc: 'Multi-stream reliable transport (WebRTC data)', ports: [9899], src: 'RFC 9260' },
        { name: 'HTTP/2',     cat: 'Application',   desc: 'Multiplexed request streams, header compression', ports: [443], src: 'RFC 9113' },
        { name: 'HTTP/3',     cat: 'Application',   desc: 'QUIC-based HTTP, 0-RTT resume', ports: [443], src: 'RFC 9114' },
        { name: 'WebSocket',  cat: 'Application',   desc: 'Full-duplex persistent connection over HTTP', ports: [80, 443], src: 'RFC 6455' },
        { name: 'MQTT',       cat: 'IoT',           desc: 'Lightweight pub/sub messaging for telemetry', ports: [1883, 8883], src: 'OASIS MQTT v5.0' },
        { name: 'CoAP',       cat: 'IoT',           desc: 'Constrained Application Protocol for sensors', ports: [5683], src: 'RFC 7252' },
        { name: 'gRPC',       cat: 'Application',   desc: 'HTTP/2-based RPC framework (protobuf)', ports: [443], src: 'CNCF / Google' },
        { name: 'TURN',       cat: 'Relay',         desc: 'Traversal Using Relays around NAT', ports: [3478, 5349], src: 'RFC 8656' },
        { name: 'STUN',       cat: 'Discovery',     desc: 'Session Traversal Utilities for NAT binding', ports: [3478, 19302], src: 'RFC 8489' },
        { name: 'ICE',        cat: 'NAT Traversal', desc: 'Interactive Connectivity Establishment', ports: [], src: 'RFC 8445' },
        { name: 'DNS-over-HTTPS', cat: 'DNS',       desc: 'Encrypted DNS queries via HTTPS', ports: [443], src: 'RFC 8484' },
        { name: 'WireGuard',  cat: 'VPN',           desc: 'Modern kernel-level VPN tunnel', ports: [51820], src: 'Donenfeld 2017' },
        { name: 'DNS',        cat: 'Application',   desc: 'Domain Name System - A/AAAA/CNAME/MX/PTR records, FQDN resolution', ports: [53], src: 'RFC 1035' },
        { name: 'DHCP',       cat: 'Application',   desc: 'Dynamic Host Configuration - IP lease, subnet mask, gateway, DNS assignment', ports: [67, 68], src: 'RFC 2131' },
        { name: 'FTP/SFTP',   cat: 'Application',   desc: 'File Transfer Protocol (command + data channel), Secure FTP over SSH', ports: [20, 21, 22], src: 'RFC 959 / RFC 4253' },
        { name: 'HTTP/1.1',   cat: 'Application',   desc: 'Hypertext Transfer Protocol, client-server web communication', ports: [80, 443], src: 'RFC 9112' },
        { name: 'SMTP',       cat: 'Application',   desc: 'Simple Mail Transfer Protocol - email delivery between servers', ports: [25, 587], src: 'RFC 5321' },
        { name: 'SNMP',       cat: 'Network Mgmt',  desc: 'Simple Network Management Protocol - manager/agent device monitoring', ports: [161, 162], src: 'RFC 3416' },
        { name: 'SSH',        cat: 'Encryption',     desc: 'Secure Shell v1-3 - encrypted remote administration, tunneling, port forwarding', ports: [22], src: 'RFC 4253' },
        { name: 'Telnet',     cat: 'Legacy',         desc: 'Remote terminal protocol (deprecated, plaintext, connectivity testing only)', ports: [23], src: 'RFC 854' },
        { name: 'ARP',        cat: 'Link Layer',     desc: 'Address Resolution Protocol - IPv4 to MAC address mapping on LAN', ports: [], src: 'RFC 826' },
        { name: 'ICMP',       cat: 'Network',        desc: 'Internet Control Message Protocol - ping, traceroute, error reporting', ports: [], src: 'RFC 792' },
        { name: 'IP (v4/v6)', cat: 'Network',        desc: 'Internet Protocol - packet routing, IPv4 (32-bit) and IPv6 (128-bit) addressing', ports: [], src: 'RFC 791 / RFC 8200' },
        { name: 'BGP',        cat: 'Routing',        desc: 'Border Gateway Protocol - inter-AS routing, iBGP/eBGP path selection', ports: [179], src: 'RFC 4271' },
        { name: 'OSPF',       cat: 'Routing',        desc: 'Open Shortest Path First - link-state routing, SPF algorithm, fast convergence', ports: [], src: 'RFC 2328' },
        { name: 'GRE',        cat: 'Tunneling',      desc: 'Generic Routing Encapsulation - IP Protocol 47, tunnel any protocol over IP', ports: [], src: 'RFC 2784' },
        { name: 'IKE v1/v2',  cat: 'VPN',            desc: 'Internet Key Exchange - IPsec tunnel negotiation and key management', ports: [500, 4500], src: 'RFC 7296' },
        { name: 'PPTP',       cat: 'VPN',            desc: 'Point-to-Point Tunneling Protocol - legacy VPN, TCP 1723 + GRE', ports: [1723], src: 'RFC 2637' },
        { name: 'IEEE 802.11',cat: 'Wireless',       desc: 'Wi-Fi standard - wireless LAN data link layer, WPA2/WPA3 security', ports: [], src: 'IEEE 802.11ax' },
        { name: 'IPMI',       cat: 'Hardware Mgmt',  desc: 'Intelligent Platform Management Interface - BMC server monitoring, remote power/console', ports: [623], src: 'IPMI v2.0' },
        { name: 'Redfish',    cat: 'Hardware Mgmt',  desc: 'RESTful API for server/platform management, DMTF standard, replaces IPMI', ports: [443], src: 'DMTF DSP0266' },
        { name: 'RS-232',     cat: 'Serial',         desc: 'Serial communication interface, console/debug port, 115200 baud typical', ports: [], src: 'TIA-232-F' },
        { name: 'I2C',        cat: 'Serial Bus',     desc: 'Inter-Integrated Circuit - 2-wire serial bus for sensors/EEPROM/RTC', ports: [], src: 'NXP UM10204' },
        { name: 'SPI',        cat: 'Serial Bus',     desc: 'Serial Peripheral Interface - full-duplex 4-wire bus, flash/display/ADC', ports: [], src: 'Motorola' },
        { name: 'CAN',        cat: 'Serial Bus',     desc: 'Controller Area Network - automotive/industrial bus, fault-tolerant', ports: [], src: 'ISO 11898' },
        { name: 'USB',        cat: 'Serial Bus',     desc: 'Universal Serial Bus - host/device topology, USB4 40Gbps', ports: [], src: 'USB-IF' },
        { name: 'PCIe',       cat: 'System Bus',     desc: 'PCI Express - high-speed serial bus for GPU/NIC/NVMe, Gen5 32GT/s', ports: [], src: 'PCI-SIG' },
        { name: 'NVMe',       cat: 'Storage',        desc: 'Non-Volatile Memory Express - PCIe SSD protocol, 64K queues, 64K cmds/queue', ports: [], src: 'NVM Express 2.0' },
        { name: 'NAT',        cat: 'Network',        desc: 'Network Address Translation - SNAT/DNAT/PAT, private-to-public IP mapping', ports: [], src: 'RFC 3022' },
        { name: 'Signal Protocol', cat: 'E2E Crypto', desc: 'Double Ratchet E2E encryption - Curve25519, ECDH, HKDF, forward secrecy', ports: [], src: 'Signal.org' },
        { name: 'AES-256-CBC', cat: 'E2E Crypto',    desc: 'Symmetric block cipher, 256-bit key, CBC mode with HMAC-SHA256 auth', ports: [], src: 'FIPS 197' },
        { name: 'Curve25519', cat: 'E2E Crypto',     desc: 'Elliptic Curve Diffie-Hellman key exchange, 128-bit security level', ports: [], src: 'RFC 7748' },
        { name: 'HKDF',       cat: 'E2E Crypto',     desc: 'HMAC-based Key Derivation Function - RK=HKDF(a||b||c||d), MK=HKDF(CK)', ports: [], src: 'RFC 5869' },
        { name: 'GSM SMS',    cat: 'Cellular',        desc: 'Short Message Service - TPDU, SMS-DELIVER/SUBMIT/STATUS, PLMN routing', ports: [], src: 'ETSI GSM 03.40' },
        { name: '802.1Q VLAN',cat: 'Switching',       desc: 'VLAN tagging, trunk/access ports, tagged/untagged frames', ports: [], src: 'IEEE 802.1Q' },
        { name: 'MSTP',       cat: 'Switching',       desc: 'Multiple Spanning Tree Protocol - loop prevention, VLAN-aware instances', ports: [], src: 'IEEE 802.1s' },
        { name: 'LACP',       cat: 'Switching',       desc: 'Link Aggregation Control Protocol - Etherchannel/trunk bonding', ports: [], src: 'IEEE 802.3ad' },
        { name: 'LLDP',       cat: 'Switching',       desc: 'Link Layer Discovery Protocol - neighbor/topology discovery', ports: [], src: 'IEEE 802.1AB' },
        { name: 'VRRP',       cat: 'Redundancy',      desc: 'Virtual Router Redundancy Protocol - gateway failover', ports: [], src: 'RFC 5798' },
        { name: 'EIGRP',      cat: 'Routing',         desc: 'Enhanced Interior Gateway Routing - Cisco hybrid distance-vector/link-state', ports: [], src: 'RFC 7868' },
        { name: 'HSRP',       cat: 'Redundancy',      desc: 'Hot Standby Router Protocol - Cisco first-hop redundancy', ports: [], src: 'RFC 2281' }
    ],

    featureSources: [
        { cat: 'IETF RFC Standards', items: [
            { ref: 'RFC 8446', title: 'TLS 1.3 Protocol', year: 2018, org: 'IETF' },
            { ref: 'RFC 9147', title: 'DTLS 1.3', year: 2022, org: 'IETF' },
            { ref: 'RFC 9000', title: 'QUIC Transport Protocol', year: 2021, org: 'IETF' },
            { ref: 'RFC 3711', title: 'Secure Real-time Transport Protocol', year: 2004, org: 'IETF' },
            { ref: 'RFC 3261', title: 'SIP Session Initiation Protocol', year: 2002, org: 'IETF' },
            { ref: 'RFC 3550', title: 'RTP Real-time Transport Protocol', year: 2003, org: 'IETF' },
            { ref: 'RFC 9293', title: 'TCP Transmission Control Protocol', year: 2022, org: 'IETF' },
            { ref: 'RFC 768',  title: 'UDP User Datagram Protocol', year: 1980, org: 'IETF' },
            { ref: 'RFC 9260', title: 'SCTP Stream Control Transmission', year: 2022, org: 'IETF' },
            { ref: 'RFC 9113', title: 'HTTP/2', year: 2022, org: 'IETF' },
            { ref: 'RFC 9114', title: 'HTTP/3', year: 2022, org: 'IETF' },
            { ref: 'RFC 6455', title: 'WebSocket Protocol', year: 2011, org: 'IETF' },
            { ref: 'RFC 8656', title: 'TURN Traversal Using Relays', year: 2020, org: 'IETF' },
            { ref: 'RFC 8489', title: 'STUN Session Traversal Utilities', year: 2020, org: 'IETF' },
            { ref: 'RFC 8445', title: 'ICE Interactive Connectivity', year: 2018, org: 'IETF' },
            { ref: 'RFC 8484', title: 'DNS-over-HTTPS', year: 2018, org: 'IETF' },
            { ref: 'RFC 7252', title: 'CoAP Constrained Application Protocol', year: 2014, org: 'IETF' },
            { ref: 'RFC 8825', title: 'WebRTC Overview', year: 2021, org: 'IETF' },
            { ref: 'RFC 1035', title: 'DNS Domain Name System', year: 1987, org: 'IETF' },
            { ref: 'RFC 2131', title: 'DHCP Dynamic Host Configuration', year: 1997, org: 'IETF' },
            { ref: 'RFC 959',  title: 'FTP File Transfer Protocol', year: 1985, org: 'IETF' },
            { ref: 'RFC 9112', title: 'HTTP/1.1 Message Syntax', year: 2022, org: 'IETF' },
            { ref: 'RFC 5321', title: 'SMTP Simple Mail Transfer', year: 2008, org: 'IETF' },
            { ref: 'RFC 3416', title: 'SNMPv2 Protocol Operations', year: 2002, org: 'IETF' },
            { ref: 'RFC 4253', title: 'SSH Transport Layer Protocol', year: 2006, org: 'IETF' },
            { ref: 'RFC 854',  title: 'Telnet Protocol Specification', year: 1983, org: 'IETF' },
            { ref: 'RFC 826',  title: 'ARP Address Resolution Protocol', year: 1982, org: 'IETF' },
            { ref: 'RFC 792',  title: 'ICMP Internet Control Message', year: 1981, org: 'IETF' },
            { ref: 'RFC 791',  title: 'Internet Protocol (IPv4)', year: 1981, org: 'IETF' },
            { ref: 'RFC 8200', title: 'Internet Protocol Version 6', year: 2017, org: 'IETF' },
            { ref: 'RFC 4271', title: 'BGP Border Gateway Protocol', year: 2006, org: 'IETF' },
            { ref: 'RFC 2328', title: 'OSPF Open Shortest Path First', year: 1998, org: 'IETF' },
            { ref: 'RFC 2784', title: 'GRE Generic Routing Encapsulation', year: 2000, org: 'IETF' },
            { ref: 'RFC 7296', title: 'IKEv2 Internet Key Exchange', year: 2014, org: 'IETF' },
            { ref: 'RFC 2637', title: 'PPTP Point-to-Point Tunneling', year: 1999, org: 'IETF' },
            { ref: 'RFC 3022', title: 'IP Network Address Translator (NAT)', year: 2001, org: 'IETF' },
            { ref: 'RFC 5798', title: 'VRRP Virtual Router Redundancy', year: 2010, org: 'IETF' },
            { ref: 'RFC 7868', title: 'EIGRP Cisco Routing Protocol', year: 2016, org: 'IETF' },
            { ref: 'RFC 2281', title: 'HSRP Hot Standby Router Protocol', year: 1998, org: 'IETF' },
            { ref: 'RFC 7748', title: 'Curve25519 Elliptic Curve DH', year: 2016, org: 'IETF' },
            { ref: 'RFC 5869', title: 'HKDF Key Derivation Function', year: 2010, org: 'IETF' }
        ]},
        { cat: 'ITU-T / ISO Standards', items: [
            { ref: 'ITU-T H.323', title: 'Packet-Based Multimedia Comm Systems', year: 2022, org: 'ITU-T' },
            { ref: 'ITU-T H.264', title: 'AVC Advanced Video Coding', year: 2003, org: 'ITU-T / ISO 14496-10' },
            { ref: 'ITU-T H.265', title: 'HEVC High Efficiency Video Coding', year: 2013, org: 'ITU-T / ISO 23008-2' },
            { ref: 'ISO 14496-12', title: 'MP4 ISO Base Media File Format', year: 2022, org: 'ISO/IEC' },
            { ref: 'ISO 23008-12', title: 'HEIF High Efficiency Image Format', year: 2017, org: 'ISO/IEC' }
        ]},
        { cat: 'Industry / Vendor Specifications', items: [
            { ref: 'OASIS MQTT v5.0', title: 'Message Queuing Telemetry Transport', year: 2019, org: 'OASIS' },
            { ref: 'W3C WebRTC', title: 'Real-Time Communication in Browsers', year: 2024, org: 'W3C' },
            { ref: '3GPP TS 23.501', title: '5G System Architecture', year: 2024, org: '3GPP' },
            { ref: '3GPP TS 23.502', title: '5G System Procedures', year: 2024, org: '3GPP' },
            { ref: '3GPP TS 38.300', title: 'NR/5G RAN Overall Description', year: 2024, org: '3GPP' },
            { ref: 'ETSI MEC 003', title: 'Multi-access Edge Computing Framework', year: 2022, org: 'ETSI' },
            { ref: 'O-RAN WG', title: 'Open RAN Architecture', year: 2024, org: 'O-RAN Alliance' },
            { ref: 'WireGuard', title: 'WireGuard: Fast Modern VPN', year: 2017, org: 'Donenfeld' },
            { ref: 'Signal Protocol', title: 'Double Ratchet E2E Encryption', year: 2016, org: 'Signal Foundation' },
            { ref: 'IPMI v2.0', title: 'Intelligent Platform Management Interface', year: 2013, org: 'Intel/DMTF' },
            { ref: 'DMTF DSP0266', title: 'Redfish RESTful Platform API', year: 2023, org: 'DMTF' },
            { ref: 'ISO 11898', title: 'CAN Controller Area Network', year: 2015, org: 'ISO' },
            { ref: 'NVM Express 2.0', title: 'NVMe SSD Protocol Specification', year: 2022, org: 'NVM Express Inc' },
            { ref: 'PCI-SIG PCIe', title: 'PCI Express Base Specification', year: 2022, org: 'PCI-SIG' },
            { ref: 'USB4 v2.0', title: 'USB4 Specification 80Gbps', year: 2022, org: 'USB-IF' },
            { ref: 'ETSI GSM 03.40', title: 'SMS Point-to-Point Technical Realization', year: 1996, org: 'ETSI' },
            { ref: 'IEEE 802.1Q', title: 'VLAN Bridges and Bridged Networks', year: 2022, org: 'IEEE' },
            { ref: 'IEEE 802.1s', title: 'MSTP Multiple Spanning Trees', year: 2002, org: 'IEEE' },
            { ref: 'IEEE 802.3ad', title: 'LACP Link Aggregation', year: 2000, org: 'IEEE' },
            { ref: 'IEEE 802.1AB', title: 'LLDP Link Layer Discovery', year: 2016, org: 'IEEE' }
        ]},
        { cat: 'Codec & Container Standards', items: [
            { ref: 'VP9', title: 'VP9 Video Codec', year: 2013, org: 'Google / WebM Project' },
            { ref: 'AV1', title: 'AOMedia Video 1', year: 2018, org: 'Alliance for Open Media' },
            { ref: 'Opus RFC 6716', title: 'Opus Interactive Audio Codec', year: 2012, org: 'IETF / Xiph.Org' },
            { ref: 'ISO 14496-3', title: 'AAC Advanced Audio Coding', year: 1997, org: 'ISO/IEC' },
            { ref: 'HLS RFC 8216', title: 'HTTP Live Streaming', year: 2017, org: 'Apple / IETF' },
            { ref: 'ISO 23009-1', title: 'MPEG-DASH', year: 2022, org: 'ISO/IEC' }
        ]},
        { cat: 'Security & Firewall References', items: [
            { ref: 'NIST SP 800-113', title: 'SSL/TLS VPN Guidelines', year: 2008, org: 'NIST' },
            { ref: 'NIST SP 800-77r1', title: 'IPsec VPN Guidelines', year: 2020, org: 'NIST' },
            { ref: 'RFC 4787', title: 'NAT Behavioral Requirements for UDP', year: 2007, org: 'IETF' },
            { ref: 'RFC 7413', title: 'TCP Fast Open', year: 2014, org: 'IETF' },
            { ref: 'IEEE 802.1X', title: 'Port-Based Network Access Control', year: 2020, org: 'IEEE' },
            { ref: 'FIPS 197', title: 'AES Advanced Encryption Standard', year: 2001, org: 'NIST' }
        ]}
    ],

    featureSockets: [
        { name: 'TCP Stream Socket',    type: 'SOCK_STREAM',  desc: 'Connection-oriented reliable byte stream', usage: 'File transfer, HTTP, TLS tunnels' },
        { name: 'UDP Datagram Socket',  type: 'SOCK_DGRAM',   desc: 'Connectionless message-oriented', usage: 'QUIC, DTLS, real-time media' },
        { name: 'Raw Socket',           type: 'SOCK_RAW',     desc: 'Direct IP packet construction', usage: 'ICMP probes, custom headers, diagnostics' },
        { name: 'WebSocket',            type: 'WS/WSS',       desc: 'Full-duplex over HTTP upgrade', usage: 'Browser real-time, signaling' },
        { name: 'Unix Domain Socket',   type: 'AF_UNIX',      desc: 'Inter-process communication', usage: 'Local service mesh, daemon IPC' },
        { name: 'SCTP Socket',          type: 'SOCK_SEQPACKET', desc: 'Multi-stream reliable transport', usage: 'WebRTC data channels' }
    ],

    featurePortRanges: [
        { range: '0 - 1023',       label: 'Well-Known',  desc: 'System/root ports (HTTP 80, HTTPS 443, DNS 53)', status: 'Active cycling' },
        { range: '1024 - 49151',   label: 'Registered',  desc: 'Application ports (SIP 5060, TURN 3478, MQTT 8883)', status: 'Full access' },
        { range: '49152 - 65535',  label: 'Dynamic',     desc: 'Ephemeral/private ports for outbound connections', status: 'Auto-assign' }
    ],

    featurePlatforms: [
        { name: 'Windows 10/11',   type: 'Desktop',   support: 'full',    notes: 'Native app + browser, all protocols' },
        { name: 'macOS 12+',       type: 'Desktop',   support: 'full',    notes: 'Native + Safari/Chrome WebRTC' },
        { name: 'Linux (Ubuntu/Debian)', type: 'Desktop', support: 'full', notes: 'CLI + browser, kernel WireGuard' },
        { name: 'iOS 15+',         type: 'Mobile',    support: 'full',    notes: 'Safari WebRTC, HEIF/HEVC native, Network Extension API' },
        { name: 'iOS (Safari)',     type: 'Browser',   support: 'full',    notes: 'WebRTC + WebSocket + HTTP/3 QUIC' },
        { name: 'Android 12+',     type: 'Mobile',    support: 'full',    notes: 'Chrome WebRTC, VPN service API' },
        { name: 'Android (Chrome)', type: 'Browser',  support: 'full',    notes: 'Full WebRTC + QUIC + H.265 decode' },
        { name: 'Chrome / Edge',   type: 'Browser',   support: 'full',    notes: 'All protocols, WebTransport, WebCodecs' },
        { name: 'Firefox',         type: 'Browser',   support: 'partial', notes: 'WebRTC yes, WebTransport limited' },
        { name: 'Smart TV (WebOS/Tizen)', type: 'Embedded', support: 'partial', notes: 'HLS/DASH streaming, limited WebRTC' }
    ],

    featureClouds: [
        { name: 'AWS',              blocked: false, services: 'CloudFront, S3, Wavelength, EC2', method: 'Direct API + Edge Cache', status: 'full' },
        { name: 'Azure',            blocked: false, services: 'Blob, CDN, Edge Zones, SignalR', method: 'Direct API + Carrier Edge', status: 'full' },
        { name: 'Google Cloud',     blocked: false, services: 'Cloud CDN, Storage, MEC, Anthos', method: 'Direct API + gRPC', status: 'full' },
        { name: 'MS Entra ID',      blocked: true,  services: 'Identity/SSO blocked by policy', method: 'TLS 1.3 wrap bypass, SNI mask', status: 'bypass' },
        { name: 'Google Workspace', blocked: true,  services: 'Drive/Docs blocked by admin', method: 'gRPC multiplex, HTTPS tunnel', status: 'bypass' },
        { name: 'DigitalOcean',     blocked: false, services: 'Spaces, Droplets, CDN', method: 'Direct - no enterprise gates', status: 'alt' },
        { name: 'Hetzner',          blocked: false, services: 'Object Storage, Dedicated', method: 'Direct - EU data sovereignty', status: 'alt' },
        { name: 'Vultr',            blocked: false, services: 'Object Storage, Compute, CDN', method: 'Direct - 32 global locations', status: 'alt' },
        { name: 'OVHcloud',         blocked: false, services: 'Object Storage, Dedicated, CDN', method: 'Direct - EU sovereign cloud', status: 'alt' },
        { name: 'Self-Hosted',      blocked: false, services: 'MinIO, Nextcloud, WireGuard VPN', method: 'Full control, no policy gates', status: 'alt' }
    ],

    featureComms: [
        { name: 'Microsoft Teams',  access: 'equal', method: 'WebRTC tunnel via TURN relay', notes: 'Full audio/video/screen share parity' },
        { name: 'Skype',            access: 'equal', method: 'TURN relay + port 3478/50000', notes: 'P2P and relay modes both supported' },
        { name: 'Google Meet',      access: 'equal', method: 'STUN/TURN via ports 19302/3478', notes: 'Chrome/Edge/Safari - full WebRTC' },
        { name: 'Amazon Chime',     access: 'equal', method: 'WebSocket signaling + WebRTC', notes: 'SDK and browser modes supported' },
        { name: 'Zoom',             access: 'equal', method: 'Proprietary + WebRTC fallback', notes: 'Client and browser join both work' },
        { name: 'WebEx',            access: 'equal', method: 'SRTP + HTTPS tunnel', notes: 'Cisco Umbrella bypass if needed' },
        { name: 'Slack (Huddles)',   access: 'equal', method: 'WebRTC + WebSocket', notes: 'Audio/video/screen share' },
        { name: 'Discord',          access: 'equal', method: 'WebRTC + WebSocket signaling', notes: 'Voice/video/streaming/Go Live' }
    ],

    featureFirewalls: [
        { name: 'TinyWall',         type: 'Host FW',      method: 'Port 443 HTTPS wrapping', risk: 'low',    notes: 'Passes as normal web traffic on 443' },
        { name: 'Check Point FW-1', type: 'Enterprise',    method: 'TLS 1.3 + SNI masking + port cycle', risk: 'low', notes: 'Stateful inspection bypassed via conformant TLS' },
        { name: 'FortiGate',        type: 'NGFW',          method: 'HTTPS tunnel + MTU conform + DPI evasion', risk: 'low', notes: 'SSL inspection sees clean TLS, passes through' },
        { name: 'Palo Alto',        type: 'NGFW',          method: 'App-ID evasion via protocol normalization', risk: 'medium', notes: 'SSL decrypt may flag - use port 443 + conformant headers' },
        { name: 'pfSense',          type: 'Open Source',   method: 'Standard port 443 + WireGuard tunnel', risk: 'low', notes: 'No deep inspection, passes freely' },
        { name: 'Sophos XG',        type: 'UTM',           method: 'HTTPS + user-agent normalization', risk: 'low', notes: 'Web filter category bypass via SNI mask' },
        { name: 'Cisco ASA',        type: 'Enterprise',    method: 'Port 443 + packet size conform', risk: 'low', notes: 'ACL-based - conform to allowed port/protocol' },
        { name: 'Meraki MX',        type: 'Cloud-Managed', method: 'HTTPS encapsulation + AMP bypass', risk: 'low', notes: 'Content filter bypass via encrypted tunnel' },
        { name: 'Port 8080 Lock',   type: 'Proxy Restrict', method: 'Tunnel through 8080 as HTTP proxy CONNECT', risk: 'low', notes: 'CONNECT method to establish TLS over proxy port' },
        { name: 'Port 443 Only',    type: 'Strict Policy', method: 'All traffic wrapped in standard HTTPS', risk: 'low', notes: 'Default mode - everything tunnels through 443' },
        { name: 'Cloudflare ZT',    type: 'SASE/ZeroTrust', method: 'HTTPS tunnel + pipe rotation', risk: 'medium', notes: 'Gateway may inspect - rotate exit nodes' },
        { name: 'Zscaler',          type: 'Cloud Proxy',   method: 'SSL bypass list + direct connect', risk: 'medium', notes: 'May need split tunnel for streaming ports' },
        { name: 'Cisco Aruba',       type: 'Wireless/NGFW', method: 'HTTPS + broadcast-safe encapsulation', risk: 'low', notes: 'Aruba broadcast network compatible, 802.1X passthrough' }
    ],

    featureSubnets: [
        { cidr: '/30', mask: '255.255.255.252', total: 4, usable: 2, use: 'Point-to-point links between routers' },
        { cidr: '/27', mask: '255.255.255.224', total: 32, usable: 30, use: 'Branch offices, network segments, guest Wi-Fi isolation' },
        { cidr: '/24', mask: '255.255.255.0', total: 256, usable: 254, use: 'Standard LAN segment, most common subnet' },
        { cidr: '/16', mask: '255.255.0.0', total: 65536, usable: 65534, use: 'Large campus network, 65K+ devices' },
        { cidr: '/8', mask: '255.0.0.0', total: 16777216, usable: 16777214, use: 'Class A network, ISP-scale addressing' }
    ],

    featureDnsResolvers: [
        { name: 'Cloudflare', ip: '1.1.1.1', ipv6: '2606:4700:4700::1111', privacy: 'No logging', speed: 'Fastest global', notes: 'Strict privacy policy, no data tracking' },
        { name: 'Google Public', ip: '8.8.8.8', ipv6: '2001:4860:4860::8888', privacy: 'Some logging', speed: 'Very fast', notes: 'Massive server network, high uptime' },
        { name: 'Quad9', ip: '9.9.9.9', ipv6: '2620:fe::fe', privacy: 'No logging', speed: 'Fast', notes: 'Malware blocking, threat intelligence' },
        { name: 'OpenDNS', ip: '208.67.222.222', ipv6: '2620:119:35::35', privacy: 'Some logging', speed: 'Fast', notes: 'Cisco-owned, content filtering available' }
    ],

    featureIpVersions: [
        { name: 'IPv4 Socket', type: 'AF_INET', format: '192.168.1.1 (32-bit, dotted decimal)', range: '4.3 billion addresses', status: 'Primary' },
        { name: 'IPv6 Socket', type: 'AF_INET6', format: '2001:db8::1 (128-bit, hex colon)', range: '340 undecillion addresses', status: 'Dual-stack' },
        { name: 'fe80::/10', type: 'Link-Local', format: 'fe80::1 (auto-configured per interface)', range: 'Local segment only', status: 'Auto' }
    ],

    // Stacey-Reynolds LoS→LoI intrusion vector scenarios
    srVectors: [
        { label: 'Free Space LoS',      power: 50,  dist: 100,   freq: 30000, angle: 75, time: 1 },
        { label: 'Urban Dense',          power: 50,  dist: 500,   freq: 30000, angle: 45, time: 2 },
        { label: 'Indoor NLoS',          power: 30,  dist: 30,    freq: 5800,  angle: 30, time: 0.5 },
        { label: 'mmWave Short',         power: 50,  dist: 50,    freq: 60000, angle: 75, time: 0.2 },
        { label: 'Sub-6 GHz Wide',       power: 100, dist: 1000,  freq: 3500,  angle: 60, time: 5 },
        { label: 'Satellite Link',       power: 200, dist: 30000, freq: 12000, angle: 85, time: 10 },
        { label: 'Campus Wi-Fi',         power: 20,  dist: 75,    freq: 5200,  angle: 50, time: 1.5 },
        { label: 'Industrial IoT',       power: 10,  dist: 200,   freq: 915,   angle: 40, time: 3 },
        { label: '5G n78 Mid-Band',      power: 50,  dist: 300,   freq: 3600,  angle: 65, time: 1 },
        { label: 'Fiber Backhaul Ref',   power: 500, dist: 10000, freq: 193000,angle: 90, time: 0.01 }
    ],

    renderFeatures() {
        this.renderFeatProtocols();
        this.renderFeatSockets();
        this.renderFeatRouting();
        this.renderFeatPlatforms();
        this.renderFeatClouds();
        this.renderFeatComms();
        this.renderFeatFirewalls();
        this.renderFeatLineLength();
        this.renderStaceyReynolds();
        this.renderFeatCodecs();
        this.renderFeatSources();
        this.renderFeatSubnets();
        this.renderFeatDns();
    },

    renderFeatProtocols() {
        const el = document.getElementById('feat-protocols');
        if (!el) return;
        const cats = {};
        this.featureProtocols.forEach(p => { if (!cats[p.cat]) cats[p.cat] = []; cats[p.cat].push(p); });
        let html = '';
        for (const [cat, protos] of Object.entries(cats)) {
            html += '<div class="feat-section"><div class="feat-section-title">' + cat + '</div>';
            html += protos.map(p =>
                '<div class="feat-row"><div class="feat-dot" style="background:var(--green)"></div>' +
                '<div class="feat-name">' + p.name + '</div>' +
                '<div class="feat-desc">' + p.desc + '</div>' +
                (p.src ? '<span class="feat-badge tunnel">' + p.src + '</span>' : '') +
                (p.ports.length ? p.ports.map(pt => '<span class="feat-port-tag">' + pt + '</span>').join('') : '') +
                '</div>'
            ).join('');
            html += '</div>';
        }
        el.innerHTML = html;
    },

    renderFeatSockets() {
        const el = document.getElementById('feat-sockets');
        if (!el) return;
        let html = '<div class="feat-section"><div class="feat-section-title">Socket Types</div>';
        html += this.featureSockets.map(s =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--cyan)"></div>' +
            '<div class="feat-name">' + s.name + '</div>' +
            '<div class="feat-desc">' + s.usage + '</div>' +
            '<span class="feat-badge yes">' + s.type + '</span></div>'
        ).join('');
        html += '</div><div class="feat-section"><div class="feat-section-title">Port Ranges</div>';
        html += this.featurePortRanges.map(r =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--blue)"></div>' +
            '<div class="feat-name">' + r.range + '</div>' +
            '<div class="feat-desc">' + r.label + ' - ' + r.desc + '</div>' +
            '<span class="feat-badge yes">' + r.status + '</span></div>'
        ).join('');
        html += '</div>';
        el.innerHTML = html;
    },

    renderFeatRouting() {
        const el = document.getElementById('feat-routing');
        if (!el) return;
        const routes = [
            { name: 'Multi-Carrier Pipe Distribution', desc: 'Traffic split across active providers with load balancing', status: 'ACTIVE' },
            { name: 'AI-Driven Path Selection', desc: 'Automatic best-path routing based on latency/loss/jitter', status: 'AI MODE' },
            { name: 'Manual Failover Override', desc: 'Operator-controlled pipe switching for specific scenarios', status: 'TOGGLE' },
            { name: 'IP Endangered Routing', desc: 'Source IP masking via multi-hop when detection risk is high', status: 'PROTECT' },
            { name: 'DHCP Reroute',           desc: 'Force new IP lease via DHCP release/renew cycle', status: 'REROUTE' },
            { name: 'FW Port Bypass Cycling',  desc: 'Rotate through ports 443/3478/8443/50000/80/8080/5060/19302', status: 'CYCLE' },
            { name: 'Heartbeat Watchdog',      desc: '500ms interval, 3-miss threshold auto-failover', status: '500ms' },
            { name: 'Dual-Pipe Redundancy',    desc: 'Two concurrent carrier pipes for zero-gap failover', status: 'DUAL' },
            { name: 'Warm Standby Pool',       desc: '2 pre-authenticated backup connections ready', status: '2 WARM' },
            { name: 'Dirac Line Length Calc',   desc: 'Fiber propagation at c * 0.67 + socket-port delay per hop', status: 'DIRAC' },
            { name: 'SNI Domain Masking',       desc: 'Server Name Indication camouflage for DPI evasion', status: 'MASKED' },
            { name: 'DNS-over-HTTPS Resolution', desc: 'Encrypted DNS preventing query interception', status: 'DoH' }
        ];
        el.innerHTML = routes.map(r =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--purple)"></div>' +
            '<div class="feat-name">' + r.name + '</div>' +
            '<div class="feat-desc">' + r.desc + '</div>' +
            '<span class="feat-badge yes">' + r.status + '</span></div>'
        ).join('');
    },

    renderFeatPlatforms() {
        const el = document.getElementById('feat-platform');
        if (!el) return;
        el.innerHTML = this.featurePlatforms.map(p => {
            const badgeClass = p.support === 'full' ? 'yes' : 'partial';
            const badgeText = p.support === 'full' ? 'FULL' : 'PARTIAL';
            return '<div class="feat-row"><div class="feat-dot" style="background:' + (p.support === 'full' ? 'var(--green)' : 'var(--yellow)') + '"></div>' +
                '<div class="feat-name">' + p.name + '</div>' +
                '<div class="feat-desc">' + p.notes + '</div>' +
                '<span class="feat-badge ' + badgeClass + '">' + p.type + '</span>' +
                '<span class="feat-badge ' + badgeClass + '">' + badgeText + '</span></div>';
        }).join('');
    },

    renderFeatClouds() {
        const el = document.getElementById('feat-cloud');
        if (!el) return;
        let html = '<div class="feat-section"><div class="feat-section-title">Direct Access</div>';
        html += this.featureClouds.filter(c => !c.blocked && c.status === 'full').map(c =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--green)"></div>' +
            '<div class="feat-name">' + c.name + '</div>' +
            '<div class="feat-desc">' + c.services + '</div>' +
            '<span class="feat-badge yes">DIRECT</span></div>'
        ).join('');
        html += '</div><div class="feat-section"><div class="feat-section-title">Blocked by Policy (Bypass Available)</div>';
        html += this.featureClouds.filter(c => c.blocked).map(c =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--yellow)"></div>' +
            '<div class="feat-name">' + c.name + '</div>' +
            '<div class="feat-desc">' + c.method + '</div>' +
            '<span class="feat-badge bypass">BYPASS</span></div>'
        ).join('');
        html += '</div><div class="feat-section"><div class="feat-section-title">Alternative Clouds (No Enterprise Gates)</div>';
        html += this.featureClouds.filter(c => c.status === 'alt').map(c =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--cyan)"></div>' +
            '<div class="feat-name">' + c.name + '</div>' +
            '<div class="feat-desc">' + c.services + '</div>' +
            '<span class="feat-badge alt">ALT CLOUD</span></div>'
        ).join('');
        html += '</div>';
        el.innerHTML = html;
    },

    renderFeatComms() {
        const el = document.getElementById('feat-comms');
        if (!el) return;
        el.innerHTML = '<div style="font-size:9px;color:var(--dim);margin-bottom:8px">All communication platforms receive equal access regardless of user account type</div>' +
        this.featureComms.map(c =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--green)"></div>' +
            '<div class="feat-name">' + c.name + '</div>' +
            '<div class="feat-desc">' + c.notes + '</div>' +
            '<span class="feat-badge equal">EQUAL</span></div>'
        ).join('');
    },

    renderFeatFirewalls() {
        const el = document.getElementById('feat-firewall');
        if (!el) return;
        el.innerHTML = this.featureFirewalls.map(f => {
            const riskColor = f.risk === 'low' ? 'var(--green)' : 'var(--yellow)';
            const riskBadge = f.risk === 'low' ? 'yes' : 'partial';
            return '<div class="feat-row"><div class="feat-dot" style="background:' + riskColor + '"></div>' +
                '<div class="feat-name">' + f.name + '</div>' +
                '<div class="feat-desc">' + f.method + '</div>' +
                '<span class="feat-badge tunnel">' + f.type + '</span>' +
                '<span class="feat-badge ' + riskBadge + '">' + f.risk.toUpperCase() + ' RISK</span></div>';
        }).join('');
    },

    renderFeatLineLength() {
        const el = document.getElementById('feat-linelength');
        if (!el) return;
        const c = 299792.458;
        const fiberFactor = 0.67;
        const distances = [50, 200, 500, 1000, 2000, 5000, 10000, 15000];
        let html = '<div style="font-size:9px;color:var(--dim);margin-bottom:8px">Dirac propagation model: c * 0.67 (fiber refractive index) + 0.002-2ns per socket-port hop</div>';
        this.tiers.forEach(tier => {
            html += '<div class="feat-section"><div class="feat-section-title">' + tier.label + ' ' + tier.rate + ' kbps (' + tier.quality + ')</div>';
            html += distances.map(km => {
                const delayMs = (km / (c * fiberFactor)) * 1000;
                const delayNs = delayMs * 1e6;
                const socketNs = 0.5 * 4;
                const totalNs = delayNs + socketNs;
                const maxKm = 15000;
                const strength = Math.max(5, 100 - (km / maxKm) * 85);
                const strengthColor = strength > 70 ? 'var(--green)' : strength > 40 ? 'var(--yellow)' : 'var(--orange)';
                return '<div class="feat-calc-row">' +
                    '<div class="feat-calc-line">' + km.toLocaleString() + ' km</div>' +
                    '<div class="feat-calc-ns">' + delayMs.toFixed(2) + ' ms</div>' +
                    '<div class="feat-calc-ns" style="color:var(--dim)">' + totalNs.toFixed(0) + ' ns</div>' +
                    '<div class="feat-calc-strength">' +
                    '<div class="feat-strength-bar"><div class="feat-strength-fill" style="width:' + strength + '%;background:' + strengthColor + '"></div></div>' +
                    '<div class="feat-calc-pct" style="color:' + strengthColor + '">' + Math.round(strength) + '%</div>' +
                    '</div></div>';
            }).join('');
            html += '</div>';
        });
        el.innerHTML = html;
    },

    renderFeatSubnets() {
        const el = document.getElementById('feat-subnets');
        if (!el) return;
        let html = '<div class="feat-section"><div class="feat-section-title">CIDR Subnet Ranges</div>';
        html += this.featureSubnets.map(s =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--blue)"></div>' +
            '<div class="feat-name">' + s.cidr + '</div>' +
            '<div class="feat-desc">' + s.use + '</div>' +
            '<span class="feat-badge yes">' + s.mask + '</span>' +
            '<span class="feat-port-tag">' + s.usable + ' hosts</span></div>'
        ).join('');
        html += '</div><div class="feat-section"><div class="feat-section-title">IP Address Versions</div>';
        html += this.featureIpVersions.map(v =>
            '<div class="feat-row"><div class="feat-dot" style="background:var(--cyan)"></div>' +
            '<div class="feat-name">' + v.name + '</div>' +
            '<div class="feat-desc">' + v.format + '</div>' +
            '<span class="feat-badge tunnel">' + v.type + '</span>' +
            '<span class="feat-badge yes">' + v.status + '</span></div>'
        ).join('');
        html += '</div>';
        el.innerHTML = html;
    },

    renderFeatDns() {
        const el = document.getElementById('feat-dns');
        if (!el) return;
        el.innerHTML = this.featureDnsResolvers.map(d => {
            const speedColor = d.speed === 'Fastest global' ? 'var(--green)' : 'var(--cyan)';
            return '<div class="feat-row"><div class="feat-dot" style="background:' + speedColor + '"></div>' +
                '<div class="feat-name">' + d.name + '</div>' +
                '<div class="feat-desc">' + d.notes + '</div>' +
                '<span class="feat-badge tunnel">' + d.ip + '</span>' +
                '<span class="feat-badge ' + (d.privacy === 'No logging' ? 'yes' : 'partial') + '">' + d.privacy + '</span></div>';
        }).join('');
    },

    renderFeatSources() {
        const el = document.getElementById('feat-sources');
        if (!el) return;
        let html = '';
        this.featureSources.forEach(group => {
            html += '<div class="feat-section"><div class="feat-section-title">' + group.cat + '</div>';
            html += group.items.map(s =>
                '<div class="feat-row"><div class="feat-dot" style="background:var(--blue)"></div>' +
                '<div class="feat-name">' + s.ref + '</div>' +
                '<div class="feat-desc">' + s.title + '</div>' +
                '<span class="feat-badge tunnel">' + s.org + '</span>' +
                '<span class="feat-port-tag">' + s.year + '</span></div>'
            ).join('');
            html += '</div>';
        });
        el.innerHTML = html;
    },

    renderFeatCodecs() {
        const el = document.getElementById('feat-codecs');
        if (!el) return;
        const codecs = [
            { name: 'MP4 / H.264',    type: 'Video Container', ios: 'full', android: 'full', desktop: 'full', notes: 'Universal baseline, hardware decode everywhere' },
            { name: 'H.265 / HEVC',   type: 'Video Codec',     ios: 'full', android: 'full', desktop: 'full', notes: '50% smaller than H.264 at same quality' },
            { name: 'HEIC',            type: 'Still Image',     ios: 'full', android: 'full', desktop: 'partial', notes: 'Apple native, 50% smaller than JPEG' },
            { name: 'Apple HEIF',      type: 'Still Container', ios: 'full', android: 'partial', desktop: 'partial', notes: 'High Efficiency Image File Format' },
            { name: 'VP9',             type: 'Video Codec',     ios: 'partial', android: 'full', desktop: 'full', notes: 'Google/YouTube standard, royalty-free' },
            { name: 'AV1',             type: 'Video Codec',     ios: 'partial', android: 'partial', desktop: 'full', notes: 'Next-gen royalty-free, 30% over HEVC' },
            { name: 'Opus',            type: 'Audio Codec',     ios: 'full', android: 'full', desktop: 'full', notes: 'WebRTC default audio, 6-510 kbps' },
            { name: 'AAC',             type: 'Audio Codec',     ios: 'full', android: 'full', desktop: 'full', notes: 'Universal audio baseline' },
            { name: 'WebM',            type: 'Container',       ios: 'partial', android: 'full', desktop: 'full', notes: 'VP8/VP9/AV1 + Vorbis/Opus container' },
            { name: 'HLS',             type: 'Streaming',       ios: 'full', android: 'full', desktop: 'full', notes: 'HTTP Live Streaming, adaptive bitrate' },
            { name: 'DASH',            type: 'Streaming',       ios: 'partial', android: 'full', desktop: 'full', notes: 'Dynamic Adaptive Streaming over HTTP' }
        ];
        el.innerHTML = '<div class="feat-grid-3">' + codecs.map(c => {
            const dot = (s) => s === 'full' ? '<span class="feat-badge yes">YES</span>' : '<span class="feat-badge partial">PARTIAL</span>';
            return '<div class="feat-row" style="flex-direction:column;align-items:stretch;gap:4px">' +
                '<div style="display:flex;align-items:center;gap:6px"><div class="feat-dot" style="background:var(--cyan)"></div>' +
                '<span class="feat-name">' + c.name + '</span><span class="feat-badge tunnel">' + c.type + '</span></div>' +
                '<div style="display:flex;gap:4px;font-size:8px">' +
                '<span style="color:var(--dim)">iOS</span>' + dot(c.ios) +
                '<span style="color:var(--dim);margin-left:4px">Droid</span>' + dot(c.android) +
                '<span style="color:var(--dim);margin-left:4px">PC</span>' + dot(c.desktop) +
                '</div>' +
                '<div style="font-size:8px;color:var(--dim)">' + c.notes + '</div></div>';
        }).join('') + '</div>';
    },

    // Stacey-Reynolds LoS→LoI core math
    srCompute(P, D, f, theta, t) {
        const rad = theta * Math.PI / 180;
        const sinT = Math.sin(rad);
        // LoS: signal-to-distance-frequency-angle ratio
        const los = P / D / f / sinT / Math.max(t, 0.001);
        // SR transform: double-log sinusoidal scaling
        const absSin = Math.abs(sinT);
        const logSin = Math.log(Math.max(absSin, 1e-12));
        const logLogSin = Math.log(Math.abs(logSin) + 1e-12);
        const sr = los * (theta / D / f) * logLogSin / (f * 300 * 500);
        // LoI: intrusion vector coefficient
        const loi = Math.abs(sr) * 1e4 * (D / f) / Math.pow(sinT, theta / 75);
        // IC: normalized intrusion coefficient (client's 50/100/30000 ratio)
        const ic = (50 / 100 / 30000) * sinT * Math.abs(sr) / (75 / 300 / 500 / 30 / 30000);
        return { los, sr, loi, ic };
    },

    calcStaceyReynolds() {
        const P = parseFloat(document.getElementById('sr-power')?.value) || 50;
        const D = parseFloat(document.getElementById('sr-distance')?.value) || 100;
        const f = parseFloat(document.getElementById('sr-freq')?.value) || 30000;
        const theta = parseFloat(document.getElementById('sr-angle')?.value) || 75;
        const t = parseFloat(document.getElementById('sr-time')?.value) || 1;
        const r = this.srCompute(P, D, f, theta, t);
        const el = (id) => document.getElementById(id);
        if (el('sr-los')) el('sr-los').textContent = r.los.toExponential(4);
        if (el('sr-transform')) el('sr-transform').textContent = r.sr.toExponential(4);
        if (el('sr-loi')) el('sr-loi').textContent = r.loi.toExponential(4);
        if (el('sr-ic')) el('sr-ic').textContent = r.ic.toExponential(4);
        const risk = r.loi > 1 ? 'HIGH INTRUSION RISK' : r.loi > 0.01 ? 'MODERATE' : 'LOW EXPOSURE';
        const riskColor = r.loi > 1 ? 'var(--red)' : r.loi > 0.01 ? 'var(--yellow)' : 'var(--green)';
        if (el('sr-result')) {
            el('sr-result').textContent = 'LoI = ' + r.loi.toExponential(3) + '  |  ' + risk;
            el('sr-result').style.color = riskColor;
        }
        // Comparison rows
        const compEl = el('sr-comparison');
        if (compEl) {
            const scenarios = [
                { name: 'Current Params', vals: r },
                { name: 'Default 50/100/30k', vals: this.srCompute(50, 100, 30000, 75, 1) },
                { name: 'Low Power 10mW', vals: this.srCompute(10, D, f, theta, t) },
                { name: 'Extended Range', vals: this.srCompute(P, D * 10, f, theta, t) }
            ];
            compEl.innerHTML = scenarios.map(s => {
                const badge = s.vals.loi > 1 ? 'risk' : s.vals.loi > 0.01 ? 'caution' : 'safe';
                const label = badge === 'risk' ? 'HIGH' : badge === 'caution' ? 'MED' : 'LOW';
                return '<div class="sr-compare-row">' +
                    '<div class="sr-compare-dot" style="background:' + (badge === 'risk' ? 'var(--red)' : badge === 'caution' ? 'var(--yellow)' : 'var(--green)') + '"></div>' +
                    '<div class="sr-compare-name">' + s.name + '</div>' +
                    '<div class="sr-compare-val">LoI ' + s.vals.loi.toExponential(2) + '</div>' +
                    '<span class="sr-compare-badge ' + badge + '">' + label + '</span></div>';
            }).join('');
        }
    },

    renderStaceyReynolds() {
        this.calcStaceyReynolds();
        const el = document.getElementById('sr-vector-table');
        if (!el) return;
        let html = '<div style="font-size:9px;color:var(--dim);margin-bottom:6px">Stacey-Reynolds intrusion vectors across signal environments</div>';
        const maxLoi = Math.max(...this.srVectors.map(v => {
            const r = this.srCompute(v.power, v.dist, v.freq, v.angle, v.time);
            return r.loi;
        }), 1e-6);
        html += this.srVectors.map(v => {
            const r = this.srCompute(v.power, v.dist, v.freq, v.angle, v.time);
            const pct = Math.min(100, (r.loi / maxLoi) * 100);
            const color = r.loi > 1 ? 'var(--red)' : r.loi > 0.01 ? 'var(--yellow)' : 'var(--green)';
            const riskTag = r.loi > 1 ? 'HIGH' : r.loi > 0.01 ? 'MED' : 'LOW';
            const badgeClass = r.loi > 1 ? 'warn' : r.loi > 0.01 ? 'partial' : 'yes';
            return '<div class="sr-vec-row">' +
                '<div class="sr-vec-label">' + v.label + '</div>' +
                '<div class="sr-vec-val">' + r.loi.toExponential(2) + '</div>' +
                '<div class="sr-vec-bar"><div class="sr-vec-fill" style="width:' + pct + '%;background:' + color + '"></div></div>' +
                '<div class="sr-vec-pct" style="color:' + color + '">' + Math.round(pct) + '%</div>' +
                '<span class="feat-badge ' + badgeClass + '">' + riskTag + '</span>' +
                '<span class="feat-port-tag">' + v.freq + 'MHz</span>' +
                '<span class="feat-port-tag">' + v.angle + '°</span></div>';
        }).join('');
        el.innerHTML = html;
    },

    drawDerima() {
        const canvas = document.getElementById('derima-canvas');
        if (!canvas) return;
        canvas.width = canvas.offsetWidth * 2;
        canvas.height = canvas.offsetHeight * 2;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        // Triangle ABC (segment distribution)
        const ax = w * 0.2, ay = h * 0.85;
        const bx = w * 0.8, by = h * 0.85;
        const cx = w * 0.5, cy = h * 0.1;

        // Hatched fill
        ctx.fillStyle = 'rgba(6,182,212,0.05)';
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.lineTo(cx, cy); ctx.closePath(); ctx.fill();

        // Triangle outline
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.lineTo(cx, cy); ctx.closePath(); ctx.stroke();

        // Inner triangle AB'C' (similar)
        const scale = 0.4;
        const midX = (ax + bx) / 2;
        const midY = (ay + cy) / 2;
        const ax2 = midX + (ax - midX) * scale;
        const ay2 = midY + (ay - midY) * scale;
        const bx2 = midX + (bx - midX) * scale;
        const by2 = midY + (by - midY) * scale;
        const cx2 = cx;
        const cy2 = midY + (cy - midY) * scale;

        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(ax2, ay2); ctx.lineTo(bx2, by2); ctx.lineTo(cx2, cy2); ctx.closePath(); ctx.stroke();
        ctx.setLineDash([]);

        // Labels
        ctx.font = 'bold 16px monospace';
        ctx.fillStyle = '#06b6d4';
        ctx.textAlign = 'center';
        ctx.fillText('A', cx, cy - 8);
        ctx.fillText('B', ax - 12, ay + 16);
        ctx.fillText('C', bx + 12, by + 16);

        ctx.fillStyle = '#f59e0b';
        ctx.font = '14px monospace';
        ctx.fillText("B'", ax2 - 12, ay2 + 16);
        ctx.fillText("C'", bx2 + 12, by2 + 16);

        // Width annotation
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 1;
        const wLineY = ay + 28;
        ctx.beginPath(); ctx.moveTo(ax, wLineY); ctx.lineTo(bx, wLineY); ctx.stroke();
        ctx.font = '12px monospace';
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillText('w(c_i) = 0.5 - 2.5c_i', (ax + bx) / 2, wLineY + 16);

        // Height annotation
        ctx.fillStyle = 'rgba(6,182,212,0.5)';
        ctx.font = '11px monospace';
        ctx.textAlign = 'left';
        ctx.fillText('0.2', cx + 8, cy + (ay - cy) * 0.2);
        ctx.fillText('5-c_i', ax + 8, ay - 8);
    }
};

window.addEventListener('load', () => NT.init());
window.addEventListener('resize', () => { NT.setupCanvas(); NT.setupGraph(); NT.drawStream(); if (NT.activePage === 'galaxy') NT.drawGalaxy(); if (NT.activePage === 'topology') NT.drawTopologyMap(); });
